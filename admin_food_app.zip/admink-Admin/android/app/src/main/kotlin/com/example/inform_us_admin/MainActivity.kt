package com.informusksr.inform_us_admin

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
