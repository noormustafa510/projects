import 'package:get/get.dart';
import 'package:inform_us_admin/controller/accounts_controller.dart';
import 'package:inform_us_admin/controller/delivery_order_controller.dart';
import 'package:inform_us_admin/controller/take_order_controller.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../controller/auth_controller.dart';

Future<void> init() async {
SharedPreferences sharedPreferences = await SharedPreferences.getInstance();

Get.lazyPut(() => sharedPreferences);

  Get.lazyPut(() => AuthController(sharedPreferences: Get.find()));
  Get.lazyPut(() => DeliveryOrderController());
  Get.lazyPut(() => TakeOrderController());
  Get.lazyPut(() => AccountsController(sharedPreferences: Get.find()  ));

}