import 'package:firebase_app_check/firebase_app_check.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:inform_us_admin/firebase_options.dart';


import 'package:inform_us_admin/pages/sign_in_page.dart';
import 'package:inform_us_admin/utils/colors.dart';
import 'helper/dependencies.dart' as dep;


Future<void> _firbaseMessagingBackgroundHandler(RemoteMessage message) async{
//  print("Handling a background message ${message.messageId}");

}

 Future<void> requestPermissionForNotification() async {
FirebaseMessaging messaging = FirebaseMessaging.instance;
NotificationSettings tem = await messaging.getNotificationSettings();
//print("Status is:" + tem.authorizationStatus.toString());

NotificationSettings settings = await messaging.requestPermission(
alert: true,
announcement: false,
badge: true,
carPlay: false,
criticalAlert: false,
provisional: false,
sound: true,
);

if (settings.authorizationStatus == AuthorizationStatus.authorized) {
//print("AuthorizationStatus.authorized");
} else if (settings.authorizationStatus ==
AuthorizationStatus.provisional) {
//print("AuthorizationStatus.authorized2");
} else {
// print("AuthorizationStatus.authorized3");
}
await FirebaseMessaging.instance.getToken().then((value) {
//print("Our Token:" + value.toString());
});
}

Future<void> main() async {

 WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  await FirebaseMessaging.instance.getInitialMessage();

   FirebaseMessaging.onBackgroundMessage(_firbaseMessagingBackgroundHandler);
 await FirebaseAppCheck.instance.activate(
   webRecaptchaSiteKey: 'recaptcha-v3-site-key',
   // Default provider for Android is the Play Integrity provider. You can use the "AndroidProvider" enum to choose
   // your preferred provider. Choose from:
   // 1. Debug provider
   // 2. Safety Net provider
   // 3. Play Integrity provider
   androidProvider: AndroidProvider.playIntegrity,
   // Default provider for iOS/macOS is the Device Check provider. You can use the "AppleProvider" enum to choose
   // your preferred provider. Choose from:
   // 1. Debug provider
   // 2. Device Check provider
   // 3. App Attest provider
   // 4. App Attest provider with fallback to Device Check provider (App Attest provider is only available on iOS 14.0+, macOS 14.0+)
   appleProvider: AppleProvider.appAttest,
 );
 // await requestPermissionForNotification();
   await dep.init();



  runApp(const MyApp());
}

class MyApp extends StatelessWidget {

  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {





    return GetMaterialApp(
      theme: ThemeData(
        primaryColor: AppColors.mainColor,
      ),
      debugShowCheckedModeBanner: false,
      home: SignInPage(),
    );
  }
}