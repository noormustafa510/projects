import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:inform_us_admin/pages/accounts.dart';
import 'package:inform_us_admin/pages/cf_section.dart';




import 'package:inform_us_admin/pages/delivery.dart';
import 'package:inform_us_admin/pages/take.dart';
import 'package:inform_us_admin/utils/dimensions.dart';

import '../../utils/colors.dart';


class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int _selectedIndex = 0;

  // late PersistentTabController _controller;
  List pages = [


    DeliveryOrders(),
    TakeOrders(),
    AccountsPage(),
    CounterFeitSection(),
    //ExcelGenerator()



  ];

  void onTapNav(int index) {
    setState(() {
      _selectedIndex = index;
     // Get.find<AllProductController>().homeIndex = index;
    });
  }



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: pages[_selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
          selectedItemColor: AppColors.mainColor,
          unselectedItemColor: Colors.amberAccent,
          showSelectedLabels: false,
          showUnselectedLabels: false,
          selectedFontSize: 0.0,
          unselectedFontSize: 0.0,
          onTap: onTapNav,
          currentIndex: _selectedIndex,
          items:  [
            BottomNavigationBarItem(
                icon: Icon(
                  Icons.delivery_dining_outlined,size: Dimension.iconSize24*1.5,
                ),
                label: "Home"),
            BottomNavigationBarItem(

                icon: Icon(
                  Icons.takeout_dining_outlined, size: Dimension.iconSize24*1.5,
                ),
                label: "Home"),

            BottomNavigationBarItem(

                icon: Icon(
                  Icons.account_balance, size: Dimension.iconSize24*1.5,
                ),
                label: "Home"),
            BottomNavigationBarItem(

                icon: Icon(
                  Icons.security, size: Dimension.iconSize24*1.5,
                ),
                label: "CF"),




          ]),
    );
  }
}

