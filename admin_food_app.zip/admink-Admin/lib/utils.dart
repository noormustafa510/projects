import 'package:intl/intl.dart';

class Utils {
  static formatPrice(String price) => 'Rs. '+price;
  static formatDate(DateTime date) => DateFormat.yMd().format(date);
}
