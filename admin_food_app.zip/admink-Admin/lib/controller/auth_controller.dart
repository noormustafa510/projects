import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:get/get.dart';
import 'package:inform_us_admin/Modal/auth_modal.dart';
import 'package:inform_us_admin/controller/delivery_order_controller.dart';
import 'package:inform_us_admin/controller/take_order_controller.dart';
import 'package:inform_us_admin/home_page.dart';
import 'package:inform_us_admin/pages/sign_in_page.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../utils/app_constants.dart';

class AuthController extends GetxController implements GetxService{

  bool loaderStatus = false;
  bool logInStatus = false;
  bool postlogInStatus = false;


SharedPreferences sharedPreferences ;

AuthController({required this.sharedPreferences});

String dateUni = DateTime.now().day.toString()+DateTime.now().month.toString()+DateTime.now().toString();

  FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin =
  FlutterLocalNotificationsPlugin();
  final db = FirebaseFirestore.instance;
 String? token = "" ;

  bool dataInitialized = false;
   late String id;
   late String password ;
   late String deliveryCharge;

     AuthModal authModal = AuthModal() ;

   // = AuthModal(id: "", password: "", doc: "", col: "");


  Future<void> takeDatafromFireStore() async {


    bool proceedingStatus = sharedPreferences.getBool(AppConstants.BLOCKINGKEY+dateUni )??true;
    if(!dataInitialized && proceedingStatus){
      blockingModule();


      //final ref = db.collection("ecom").doc("products");

      final ref = db.collection("auth").doc("adminAuth").withConverter(
        fromFirestore: AuthModal.fromFireStore,
        toFirestore: (AuthModal authModal, _) =>
            authModal.toFireStore(),
      );







       ref.snapshots().listen(
            (event) {
          authModal = event.data()!;
          deliveryCharge = authModal.col??'70';





if(logInStatus && postlogInStatus){
  Get.offAll(()=>const SignInPage());
}



postlogInStatus = true;

        },
        onError: (error) {


        }

    );
     if(!logInStatus) { var docsnap = await ref.get();

    var data =  docsnap.data();


    authModal = data??AuthModal();
    logInStatus = true;

    }







      // final data = docSnap;
    //   authModal =  datum;






      dataInitialized = true;
    }
  }

  bool authentication(String id, String password){
    if(authModal.id == id && authModal.password == password ){

      return true;
    }else{


      Get.snackbar("Authentication", "Failed");
      return false;}


  }

  signUpProcess(String id, String password) async {

    bool proceedingSignal = sharedPreferences.getBool(AppConstants.BLOCKINGKEY+ dateUni+'Auth')??true;

    if(proceedingSignal){
      await takeDatafromFireStore();


    if(authentication(id, password)){
      await initialPerToken();
      await Get.find<DeliveryOrderController>().getDeliveryOrdersFromFireStore();
      await Get.find<TakeOrderController>().getDeliveryOrdersFromFireStore();



      //await initialPerToken();

      upDateLoaderStatus(false);
      
      Get.off(()=> HomePage() );
      // Get.off(()=> DeliveryOrders() );
    }
    else{
      upDateLoaderStatus(false);
      blockingModuleForAuthentication();

    }

    }

    upDateLoaderStatus(false);

  }

  initialPerToken() async {

    await requestPermission();
    await getToken();
   await intInfo();

  }

  Future<void>  requestPermission() async{

    FirebaseMessaging messaging = FirebaseMessaging.instance;
    NotificationSettings settings = await messaging.requestPermission(
      alert: true,
      announcement: false,
      badge: true,
      carPlay: false,
      criticalAlert: false,
      provisional: false,
      sound: true,
    );

    if(settings.authorizationStatus == AuthorizationStatus.authorized){

    }else if(settings.authorizationStatus == AuthorizationStatus.provisional){

    } else {

    }

  }

  Future<void> getToken() async {


    if(sharedPreferences.get(AppConstants.DEVICETOKEN)==null ){


      await FirebaseMessaging.instance.getToken().then((value){
        token = value;

      } );

      sharedPreferences.setString(AppConstants.DEVICETOKEN, token! );
      saveToken(token );




    }



  }
  
  Future<void> saveToken(String? token ) async
  {



    await db.collection("auth").doc("adToken").update({
  "allTokens": FieldValue.arrayUnion([token])



  });
    
  }

  intInfo() async {

    var androidInitialize = const AndroidInitializationSettings('@mipmap/ic_launcher');
    var iosInitialize = const IOSInitializationSettings();

    var initializationsSetting = InitializationSettings(android: androidInitialize, iOS: iosInitialize);

    await flutterLocalNotificationsPlugin.initialize(
      initializationsSetting, onSelectNotification: (String? payload)async {
        try{
          if(payload != null && payload.isNotEmpty){

          }else{}
        } catch(e){}
      return ;
    }
    );
    FirebaseMessaging.onMessage.listen((RemoteMessage message) async {



      BigTextStyleInformation bigTextStyleInformation = BigTextStyleInformation(message.notification!.body.toString(), htmlFormatBigText: true,
      contentTitle: message.notification!.title.toString(),
        htmlFormatContentTitle: true,
      );
      
      AndroidNotificationDetails androidPlatformChannelSpecifics = AndroidNotificationDetails("delivery", "delivery","This is Delivery", importance: Importance.high,
      styleInformation: bigTextStyleInformation, priority: Priority.high, playSound: true,
      );

      NotificationDetails platformChannelSpecifics = NotificationDetails(
        android: androidPlatformChannelSpecifics, iOS: const IOSNotificationDetails()
      );

      await flutterLocalNotificationsPlugin.show(0, message.notification?.title, message.notification?.body, platformChannelSpecifics,
      payload: message.data['body']);


    });
  }

  bool blockingModule()   {
    bool status = false;

    String key = dateUni + AppConstants.DAYKEY;


    int value = sharedPreferences.getInt(key)??0;
    if(value == 0){
      sharedPreferences.setInt(key, value+1);
      status = true;
    }
    else{

      value++;
      sharedPreferences.setInt(key, value);
      if(value <AppConstants.BLOCKINGACCOUNTFORFIREBASE){
        status = true;
      } else{
        sharedPreferences.setBool(AppConstants.BLOCKINGKEY+dateUni, false);
      }
    }

    return status;
  }
  bool blockingModuleForAuthentication()   {

    bool status = false;

    String key = dateUni + AppConstants.DAYKEY+"-Auth";


    int value = sharedPreferences.getInt(key)??0;
    if(value == 0){
      sharedPreferences.setInt(key, value+1);
      status = true;

    }
    else{

      value++;
      sharedPreferences.setInt(key, value);
      if(value <AppConstants.BLOCKINGACOUNTFORAUTTHENTICATON){
        status = true;
      } else{
        sharedPreferences.setBool(AppConstants.BLOCKINGKEY+dateUni+'Auth', false);
      }
    }

    return status;
  }

String? getUserIDfromShareResource()  {

  return sharedPreferences.getString(AppConstants.idByUser);
}

String? getUserPasswordfromShareResource()  {

  return sharedPreferences.getString(AppConstants.passwordByUser);
}
setUserIDinShareResource(String value)  {

  sharedPreferences.setString(AppConstants.idByUser, value);
}
setUserPasswordinShareResource(String value)  {

  sharedPreferences.setString(AppConstants.passwordByUser, value);
}

upDateLoaderStatus(bool status){
    loaderStatus = status;
    update();
}


}