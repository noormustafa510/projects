import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:get/get_state_manager/src/simple/get_controllers.dart';
import 'package:inform_us_admin/utils/app_constants.dart';
import 'package:inform_us_admin/utils/colors.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../Modal/billing_modal.dart';

class AccountsController extends GetxController implements GetxService
{

  Color cFColor = AppColors.mainColor;
  bool accountLoader = false;
  List<BillingModal> billsList = [];
  int totalProfit = 0;
  int totalBusiness = 0;

  int selectedCategory = 0;
  int selectedProfit = 9;
  int selectedShop = 0;
  int fromNumber=0;
  int toNumber=0;
  SharedPreferences sharedPreferences;
  AccountsController({required  this.sharedPreferences});

  bool accoutsLoggedInStatus = false;

  accountsLoggedIn(){
  accoutsLoggedInStatus =  sharedPreferences.getBool(AppConstants.ACCOUNTSLOGGEDIN)??false;
  }

  afterLoggedIn(){
    accoutsLoggedInStatus = true;
    sharedPreferences.setBool(AppConstants.ACCOUNTSLOGGEDIN, true);
    update();
  }
   Future<Uint8List>  buildImage() async {
    final ByteData image = await rootBundle.load('assets/images/asset1.png');

    Uint8List imageData =  (image).buffer.asUint8List();
    return imageData;
  }

 String invoiceGenerator({required int day, required int month, required int year,required
 int percentageRatio
  , required int percentage, required int sale, required int noOfItems

  }){



    int total = 0;

    if(noOfItems >0){
      int subFraction = 0;
      int issunaceDate = day+month+ year;
      subFraction = issunaceDate * 3 + noOfItems*101 + sale* 2 +percentageRatio*696+ percentage*22;
      total = issunaceDate * 693 -subFraction;

    }
    return total.toString();


  }

  setCFColor(Color color){
    cFColor = color;
    update();
  }



}