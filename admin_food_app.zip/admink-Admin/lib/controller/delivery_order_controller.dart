import 'package:flutter_ringtone_player/flutter_ringtone_player.dart';
import 'package:get/get.dart';
import 'package:inform_us_admin/controller/auth_controller.dart';

import '../Modal/order_modal.dart';

class DeliveryOrderController extends GetxController implements GetxService{

  AdminOrder adminOrder = AdminOrder();
  late int lengthOfList ;
    List<Orders> orderList = [];






  getDeliveryOrdersFromFireStore() async {

    var day  = DateTime.now().day.toString();
    var docRef = Get.find<AuthController>().db.collection("adminOrder").doc(day).withConverter(
      fromFirestore: AdminOrder.fromFirestore,
      toFirestore: (AdminOrder adminOrder, _) => adminOrder.toFirestore(),
    );

    docRef.snapshots().listen(
          (event){
            day  = DateTime.now().day.toString();
            docRef = Get.find<AuthController>().db.collection("adminOrder").doc(day).withConverter(
              fromFirestore: AdminOrder.fromFirestore,
              toFirestore: (AdminOrder adminOrder, _) => adminOrder.toFirestore(),
            );
            FlutterRingtonePlayer.play(
              android: AndroidSounds.ringtone,
              ios: IosSounds.glass,
              looping: true, // Android only - API >= 28
              volume: 1.0, // Android only - API >= 28
              asAlarm: false, // Android only - all APIs
            );



            if(event.data() != null)
            {
              adminOrder = event.data()!;


            orderList = adminOrder.orders!;

            }





        update();



       // print("object" + adminOrder.orders![0].name.toString() );
      } ,
      onError: (error)  {
          //  print("Listen failed: $error");
          }
    );



  }






   reInitializedOrderList(AdminOrder adminOrder){

    lengthOfList = adminOrder.orders!.length;
    orderList = adminOrder.orders!.reversed.toList();




   }



}