class MapModal{

  double lat;
  double lng;

  MapModal({required this.lat, required this.lng});


}