class BillingModal{
  String day;
  int bill;
  int percentage ;

  BillingModal({required this.day, required this.bill, required this.percentage});
}