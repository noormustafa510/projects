import 'package:cloud_firestore/cloud_firestore.dart';

class ShopOrderModel {
  List<Orders>? orders;

  ShopOrderModel({this.orders});

  ShopOrderModel.fromFirestore(DocumentSnapshot<Map<String, dynamic>> snapshot,
      SnapshotOptions? options,) {
    final json = snapshot.data();
    if (json!['orders'] != null) {
      orders = <Orders>[];
      json['orders'].forEach((v) {
        orders!.add(new Orders.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toFirestore() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.orders != null) {
      data['orders'] = this.orders!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Orders {
  List<ProductsS>? productsS;
  String? shopIdS;
  String? shopNameS;
  String? timeS;
  String? cNameSh;
  String? billS;
  String? note;

  Orders(
      {this.productsS,
        this.shopIdS,
        this.shopNameS,
        this.timeS,
        this.cNameSh,
        this.billS});

  Orders.fromJson(Map<String, dynamic> json) {
    if (json['productsS'] != null) {
      productsS = <ProductsS>[];
      json['productsS'].forEach((v) {
        productsS!.add(new ProductsS.fromJson(v));
      });
    }
    shopIdS = json['shopIdS'];
    shopNameS = json['shopNameS'];
    timeS = json['timeS'];
    cNameSh = json['cNameSh'];
    billS = json['billS'];
    note = json['note'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.productsS != null) {
      data['productsS'] = this.productsS!.map((v) => v.toJson()).toList();
    }
    data['shopIdS'] = this.shopIdS;
    data['shopNameS'] = this.shopNameS;
    data['timeS'] = this.timeS;
    data['cNameSh'] = this.cNameSh;
    data['billS'] = this.billS;
    data['note'] = this.note;
    return data;
  }
}

class ProductsS {
  String? nameS;
  String? priceS;
  String? quantityS;

  ProductsS({this.nameS, this.priceS, this.quantityS});

  ProductsS.fromJson(Map<String, dynamic> json) {
    nameS = json['nameS'];
    priceS = json['priceS'];
    quantityS = json['quantityS'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['nameS'] = this.nameS;
    data['priceS'] = this.priceS;
    data['quantityS'] = this.quantityS;
    return data;
  }
}