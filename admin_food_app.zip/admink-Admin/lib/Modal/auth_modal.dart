import 'package:cloud_firestore/cloud_firestore.dart';

class AuthModal {
  String? password;
  String? id;

  String? col;

  AuthModal({this.password, this.id,  this.col});

  AuthModal.fromFireStore( DocumentSnapshot<Map<String, dynamic>> snapshot,
      SnapshotOptions? options,) {
    var json = snapshot.data();

    password = json!['password'];
    id = json['id'];

    col = json['col'];
  }

  Map<String, dynamic> toFireStore() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['password'] = this.password;
    data['id'] = this.id;

    data['col'] = this.col;
    return data;
  }
}
