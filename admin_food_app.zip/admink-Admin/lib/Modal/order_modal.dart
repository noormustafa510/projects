import 'package:cloud_firestore/cloud_firestore.dart';




class AdminOrder {
  List<Orders>? orders;

  AdminOrder({this.orders});

  AdminOrder.fromFirestore(DocumentSnapshot<Map<String, dynamic>> snapshot,
      SnapshotOptions? options,) {
    var json = snapshot.data();
    if (json!['orders'] != null) {
      orders = <Orders>[];
      json['orders'].forEach((v) {
        orders!.add(new Orders.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toFirestore() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.orders != null) {
      data['orders'] = this.orders!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Orders {
  String? latlng;
  String? phone;
  String? note;
  String? address;
  String? price;
  List<Shops>? shops;
  String? time;
  String? addressType;
  String? name;
  String? deviceID;
  String? deviceInfo;


  Orders(
      {this.latlng,
        this.phone,
        this.note,
        this.address,
        this.price,
        this.shops,
        this.time,
        this.addressType,
        this.name,
this.deviceInfo,
        this.deviceID

      });

  Orders.fromJson(Map<String, dynamic> json) {
    latlng = json['latlng'];
    phone = json['phone'];
    note = json['note'];
    address = json['address'];
    price = json['price'];
    if (json['shops'] != null) {
      shops = <Shops>[];
      json['shops'].forEach((v) {
        shops!.add(new Shops.fromJson(v));
      });
    }
    time = json['time'];
    addressType = json['addressType'];
    name = json['name'];
    deviceID = json['deviceID'];
    deviceInfo = json['deviceInfo'];

  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['latlng'] = this.latlng;
    data['phone'] = this.phone;
    data['note'] = this.note;
    data['address'] = this.address;
    data['price'] = this.price;
    if (this.shops != null) {
      data['shops'] = this.shops!.map((v) => v.toJson()).toList();
    }
    data['time'] = this.time;
    data['addressType'] = this.addressType;
    data['name'] = this.name;

    data['deviceID'] = this.deviceID;
    data['deviceInfo'] = this.deviceInfo;



    return data;
  }
}

class Shops {
  String? shopID;
  String? shopName;
  List<Products>? products;

  Shops({this.shopID, this.shopName, this.products});

  Shops.fromJson(Map<String, dynamic> json) {
    shopID = json['shopID'];
    shopName = json['shopName'];
    if (json['products'] != null) {
      products = <Products>[];
      json['products'].forEach((v) {
        products!.add(new Products.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['shopID'] = this.shopID;
    data['shopName'] = this.shopName;
    if (this.products != null) {
      data['products'] = this.products!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Products {
  String? name;
  String? price;
  String? quantity;

  Products({this.name, this.price, this.quantity});

  Products.fromJson(Map<String, dynamic> json) {
    name = json['name'];
    price = json['price'];
    quantity = json['quantity'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['name'] = this.name;
    data['price'] = this.price;
    data['quantity'] = this.quantity;
    return data;
  }
}










//
//
// class AdminOrder {
//   List<Orders>? orders;
//
//   AdminOrder({this.orders});
//
//   AdminOrder.fromJson(Map<String, dynamic> json) {
//     if (json['orders'] != null) {
//       orders = <Orders>[];
//       json['orders'].forEach((v) {
//         orders!.add(new Orders.fromJson(v));
//       });
//     }
//   }
//
//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> data = new Map<String, dynamic>();
//     if (this.orders != null) {
//       data['orders'] = this.orders!.map((v) => v.toJson()).toList();
//     }
//     return data;
//   }
// }
//
// class Orders {
//   String? latlng;
//   String? phone;
//   String? note;
//   String? address;
//   String? price;
//   List<Shops>? shops;
//   String? time;
//   String? addressType;
//   String? name;
//   String? deviceID;
//   String? deviceInfo;
//
//   Orders(
//       {this.latlng,
//         this.phone,
//         this.note,
//         this.address,
//         this.price,
//         this.shops,
//         this.time,
//         this.addressType,
//         this.name,
//         this.deviceID,
//         this.deviceInfo});
//
//   Orders.fromJson(Map<String, dynamic> json) {
//     latlng = json['latlng'];
//     phone = json['phone'];
//     note = json['note'];
//     address = json['address'];
//     price = json['price'];
//     if (json['shops'] != null) {
//       shops = <Shops>[];
//       json['shops'].forEach((v) {
//         shops!.add(new Shops.fromJson(v));
//       });
//     }
//     time = json['time'];
//     addressType = json['addressType'];
//     name = json['name'];
//     deviceID = json['deviceID'];
//     deviceInfo = json['deviceInfo'];
//   }
//
//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> data = new Map<String, dynamic>();
//     data['latlng'] = this.latlng;
//     data['phone'] = this.phone;
//     data['note'] = this.note;
//     data['address'] = this.address;
//     data['price'] = this.price;
//     if (this.shops != null) {
//       data['shops'] = this.shops!.map((v) => v.toJson()).toList();
//     }
//     data['time'] = this.time;
//     data['addressType'] = this.addressType;
//     data['name'] = this.name;
//     data['deviceID'] = this.deviceID;
//     data['deviceInfo'] = this.deviceInfo;
//     return data;
//   }
// }
//
// class Shops {
//   String? shopID;
//   String? shopName;
//   List<Products>? products;
//
//   Shops({this.shopID, this.shopName, this.products});
//
//   Shops.fromJson(Map<String, dynamic> json) {
//     shopID = json['shopID'];
//     shopName = json['shopName'];
//     if (json['products'] != null) {
//       products = <Products>[];
//       json['products'].forEach((v) {
//         products!.add(new Products.fromJson(v));
//       });
//     }
//   }
//
//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> data = new Map<String, dynamic>();
//     data['shopID'] = this.shopID;
//     data['shopName'] = this.shopName;
//     if (this.products != null) {
//       data['products'] = this.products!.map((v) => v.toJson()).toList();
//     }
//     return data;
//   }
// }
//
// class Products {
//   String? name;
//   String? price;
//   String? quantity;
//
//   Products({this.name, this.price, this.quantity});
//
//   Products.fromJson(Map<String, dynamic> json) {
//     name = json['name'];
//     price = json['price'];
//     quantity = json['quantity'];
//   }
//
//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> data = new Map<String, dynamic>();
//     data['name'] = this.name;
//     data['price'] = this.price;
//     data['quantity'] = this.quantity;
//     return data;
//   }
// }

