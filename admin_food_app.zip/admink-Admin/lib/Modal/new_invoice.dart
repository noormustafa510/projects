import 'package:inform_us_admin/Modal/billing_modal.dart';

class NewInvoice{

  String shopName;
  String percentageRatio;
  String percentage;
  String sale;

  NInvoiceInfo nInvoiceInfo;

  List<BillingModal> billList ;

  NewInvoice({required this.billList,required this.shopName, required this.nInvoiceInfo
  , required this.percentage, required this.percentageRatio , required this.sale
  });



}

class NInvoiceInfo{

  String invoiceNumber;
  String issuanceDate;
  String dueDate;
  String paymentMethod;
  NInvoiceInfo({required this.invoiceNumber , required this.issuanceDate,
  required this.dueDate, required this.paymentMethod
  });

}