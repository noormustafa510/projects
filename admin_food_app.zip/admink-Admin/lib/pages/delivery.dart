import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_ringtone_player/flutter_ringtone_player.dart';
import 'package:get/get.dart';
import 'package:inform_us_admin/Modal/map_modal.dart';
import 'package:inform_us_admin/Modal/order_modal.dart';
import 'package:inform_us_admin/base/custom_loader.dart';
import 'package:inform_us_admin/base/fare_Calculator.dart';
import 'package:inform_us_admin/controller/auth_controller.dart';
import 'package:inform_us_admin/controller/delivery_order_controller.dart';
import 'package:inform_us_admin/utils/colors.dart';
import 'package:inform_us_admin/utils/dimensions.dart';
import 'package:inform_us_admin/widget/big_text.dart';
import 'package:inform_us_admin/widget/copy_side_button.dart';
import 'package:maps_launcher/maps_launcher.dart';
import 'package:url_launcher/url_launcher.dart'  ;

import '../widget/icon_and_text_widget.dart';


class DeliveryOrders extends StatelessWidget {
  const DeliveryOrders({Key? key}) : super(key: key);

  @override

  Widget build(BuildContext context) {




    List<Orders> orderList = [];

    return Scaffold(
      appBar: AppBar(title: GestureDetector(
          onTap: () async {
            await FlutterRingtonePlayer.stop();
          },
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text("Delivery Orders"),
              Text("U.D.C :  "+Get.find<AuthController>().deliveryCharge)
            ],
          )

         ), backgroundColor: AppColors.mainColor, ),


      body:
      GetBuilder<DeliveryOrderController>(builder: (dController){

       if(dController.orderList.isNotEmpty)
       { orderList = dController.orderList.reversed.toList();}

       else {

       //  print("Deli List is empty");
       }





        return orderList.isEmpty?const CustomLoader():  Column(


          children: [
            SizedBox(height: Dimension.height10*1.2,),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [


                //date
                Container(height: Dimension.height45, width: Dimension.width30*4,
                  decoration: BoxDecoration(
                    color: Colors.grey,
                    borderRadius: BorderRadius.circular(Dimension.radius20*0.7),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [ BigText(text: "Date:" , color: Colors.white, ),
                      BigText(text: " ${  DateTime.now().day}"),],),),
                //no of orders
                Container(
                  height: Dimension.height45, width: Dimension.width30*4, decoration: BoxDecoration(

                    borderRadius: BorderRadius.circular(Dimension.radius20*0.7),
                    border: Border.all(
                        color: Colors.grey,
                        width: Dimension.font16/5
                        , style: BorderStyle.solid,
                        strokeAlign: BorderSide.strokeAlignInside

                    )
                ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.delivery_dining_outlined , size: Dimension.font26*1.2,color: Colors.grey,),
                      BigText(text: " "+orderList.length.toString(), color: AppColors.mainColor, size: Dimension.font26*1,)


                    ],
                  ),


                ),



                // orders
                TextButton(onPressed: () async {
                 await FlutterRingtonePlayer.stop();













                  //final docSnap = await docRef.get();






                  //  final core = docSnap.data(); // Convert to City object
                  // AdminOrder adminOrder = AdminOrder();
                  //  adminOrder = core!;


                  //print("object" + adminOrder.orders![0].name.toString());




                }, child: Text("Silent"))


              ],),
            SizedBox(height: Dimension.height20,),





            Expanded(
              child: SingleChildScrollView(
                child: ListView.builder(
                    itemCount: orderList.length,
                    shrinkWrap: true,
                    physics: NeverScrollableScrollPhysics(),
                    itemBuilder: (context, index) {
                      return GestureDetector(
                        onTap: () async {
                          await FlutterRingtonePlayer.stop();

                          showModalBottomSheet(
                              backgroundColor: Colors.transparent,
                              context: context,
                              builder: (_) {
                                return Column(
                                  children: [
                                    Expanded(
                                      child: SingleChildScrollView(
                                        child: Container(

                                          height: MediaQuery
                                              .of(context)
                                              .size
                                              .height *
                                              6,

                                          decoration: BoxDecoration(
                                            color: Colors.white,
                                            borderRadius: BorderRadius.only(
                                              topLeft: Radius.circular(
                                                  Dimension.radius20),
                                              topRight: Radius.circular(
                                                  Dimension.radius20),
                                            ),
                                          ),
                                          child: Column(
                                            children: [
                                              Container(
                                                width: double.maxFinite,
                                                padding: EdgeInsets.only(
                                                    top: Dimension.height20,
                                                    right: Dimension.width20,
                                                    left: Dimension.width20),

                                                child: Column(
                                                  crossAxisAlignment:
                                                  CrossAxisAlignment
                                                      .start,
                                                  children: [



                                                    Center(
                                                      child: Text(
                                                        'Order Details',
                                                        style: TextStyle(
                                                            color: Colors.grey,
                                                            fontWeight:
                                                            FontWeight.bold,
                                                            fontSize: Dimension
                                                                .font26),
                                                      ),
                                                    ),


                                                    SizedBox(
                                                      height:
                                                      Dimension.height20,
                                                    ),

                                                    Container(

                                                      child: ListView.builder(itemCount: orderList[index].shops!.length,
                                                          shrinkWrap: true,
                                                          physics:
                                                          NeverScrollableScrollPhysics(),
                                                          itemBuilder: (context, sIndex){
                                                            List<Shops> shops = orderList[index].shops!;
                                                            return Container(


                                                              child: Column(
                                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                                children: [
                                                                  BigText(text: shops[sIndex].shopName.toString(), color: AppColors.mainColor,size: Dimension.font26, )

                                                                  , ListView.builder(
                                                                      itemCount:
                                                                      shops[sIndex].products!.length,
                                                                      shrinkWrap: true,
                                                                      physics:
                                                                      NeverScrollableScrollPhysics(),

                                                                      itemBuilder: (context, pIndex){
                                                                        List<Products> products = shops[sIndex].products!;
                                                                        return Container(

                                                                            child:
                                                                            Center(
                                                                              child: BigText(
                                                                                text:
                                                                                products[pIndex].name.toString() + " x " +products[pIndex].quantity.toString(), size: Dimension.font26,
                                                                              ),
                                                                            )
                                                                        );
                                                                      }),

                                                                  SizedBox(height: Dimension.height10,)

                                                                ],
                                                              ),

                                                            );

                                                          }),)


                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                );
                              });
                        },

                                // .whenComplete(() =>
                                // orderController
                                //     .setFoodNote(_noteController.text.trim())),
                        child: Container(
                          margin: EdgeInsets.only(
                              left: Dimension.width20,
                              right: Dimension.width20,
                              bottom: Dimension.width10),
                          child: Row(
                            children: [
                              //Image Section

                              Container(height:  Dimension.listViewTextContSize,width: Dimension.width10,
                              color: index.isEven? AppColors.yellowColor : Colors.grey  ),

                              //Text Container
                              Expanded(
                                child: Container(
                                  height: Dimension.listViewTextContSize,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.only(
                                      topRight:
                                      Radius.circular(Dimension.radius20),
                                      bottomRight:
                                      Radius.circular(Dimension.radius20),
                                    ),
                                    color: Colors.white,
                                  ),
                                  child: Padding(
                                    padding: EdgeInsets.only(
                                      left: Dimension.width10,
                                      right: Dimension.width10,
                                    ),
                                    child: Column(
                                      crossAxisAlignment:
                                      CrossAxisAlignment.start,
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      children: [
                                      //first row: Name
                                        Row(
                                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                          children: [

                                            GestureDetector(
                                        onTap: (){

                                          int bill = 0;
                                          int dCharges = BasicMethods.fareCalculator(orderList[index].latlng.toString());
                                          String totalBill = "";
                                          String details ="";


                                          bill = int.parse(orderList[index].price.toString());

                                          totalBill = (bill+dCharges).toString();

                                          details +="Name:  "+ orderList[index].name.toString()+
                                              "\nPhone:  "+  orderList[index].phone.toString()+
                                              "\nAddress:  "+orderList[index].address.toString() +

                                              "\n"+
                                              "\n_Sub-Bill:  "+ bill.toString()+"_"+

                                              "\n*_Delivery-Charges:  "+ dCharges.toString()+"_*"+
                                              "\n*_Total Bill:  "+ totalBill+"_*"+

                                              "\n\nNote: "+orderList[index].note.toString()+
                                              "\n"+ "Products";

                                          orderList[index].shops!.forEach((element) {
                                            details +="\n\n" + element.shopName.toString() + "\n" ;
                                            element.products!.forEach((element) {
                                              details += element.name.toString() +" x "+ element.quantity.toString()+" = "
                                                  + "${int.parse(element.quantity.toString())* int.parse(element.price.toString()) }" +
                                                  "\n\n" +
                                                  "\nLink: https://maps.google.com/?q=${orderList[index].latlng.toString()}" ;


                                            });



                                          });





                                          BasicMethods.goToWhatsApp(details);
                                        },
                                              child: IconAndTextWidget(iconSize: Dimension.iconSize24*1.1,
                                                fontSize: Dimension.font26,icon: Icons.person,
                                                text: orderList[index].name.toString(), iconColor: AppColors.mainColor,),

                                            ),

                                           Row(
                                             mainAxisAlignment: MainAxisAlignment.end,
                                             children: [
                                            CopySideButton(iconData: Icons.numbers, data:orderList[index].deviceID.toString(), type: "Device ID ",),

                                             SizedBox(width: Dimension.width10,),
                                             CopySideButton(iconData: Icons.phone_android_sharp, data:orderList[index].deviceInfo.toString() , type: "Deivce Infomation",),


                                             SizedBox(width: Dimension.width10,),


                                             GestureDetector(
                                                 onTap: () async {
                                                   int bill = 0;
                                                   int dCharges = BasicMethods.fareCalculator(orderList[index].latlng.toString());
                                                   String totalBill = "";
                                                   String details ="";


                                                   bill = int.parse(orderList[index].price.toString());

                                                   totalBill = (bill+dCharges).toString();

                                                   details +="Name:  "+ orderList[index].name.toString()+
                                                       "\nPhone:  "+  orderList[index].phone.toString()+
                                                       "\nAddress:  "+orderList[index].address.toString() +

                                                       "\n"+
                                                       "\n_Sub-Bill:  "+ bill.toString()+"_"+

                                                       "\n*_Delivery-Charges:  "+ dCharges.toString()+"_*"+
                                                       "\n*_Total Bill:  "+ totalBill+"_*"+

                                                       "\n\nNote: "+orderList[index].note.toString()+
                                                       "\n"+ "Products";

                                                   orderList[index].shops!.forEach((element) {
                                                     details +="\n\n" + element.shopName.toString() + "\n" ;
                                                     element.products!.forEach((element) {
                                                       details += element.name.toString() +" x "+ element.quantity.toString()+" = " 
                                                           + "${int.parse(element.quantity.toString())* int.parse(element.price.toString()) }" + 
                                                           "\n\n" +
                                                           "\nLink: https://maps.google.com/?q=${orderList[index].latlng.toString()}" ;


                                                     });



                                                   });





                                                   await Clipboard.setData(ClipboardData(text: details ));
                                                   Get.snackbar("Order","Selected order is Copied" );},
                                                 child: Icon(Icons.copy_all_outlined))
                                           ],),



                                          ],


                                        ),

                                        SizedBox(
                                          height: Dimension.height10,
                                        ),

                                        Row(children: [
                                          GestureDetector(

                                            child: IconAndTextWidget(icon: Icons.phone, text: orderList[index].phone!,
                                                iconColor: Colors.black87),
                                            onLongPress: () async { await Clipboard.setData(ClipboardData(text: orderList[index].phone! ));
                                            Get.snackbar("Phone","${orderList[index].phone!} is Copied" );},
                                            onTap: () async {






                                              launchUrl(Uri.parse('tel:${orderList[index].phone!}'));

                                            // launch('tel:+${orderList[index].phone!}');






                                            },
                                          ),
                                          BigText(text: " | ", size: Dimension.font16,),
                                          IconAndTextWidget(icon: Icons.money, text: orderList[index].price.toString()+"-"+
                                              BasicMethods.fareCalculator(orderList[index].latlng.toString()).toString()
                                              , iconColor: Colors.grey)
                                         , BigText(text: " | ", size: Dimension.font16,),
                                          IconAndTextWidget(icon: Icons.punch_clock, text: orderList[index].time.toString(), iconColor: Colors.red),

                                        ],),


                                        SizedBox(
                                          height: Dimension.height10,
                                        ),
                                       GestureDetector(
                                         onTap: () async {

                                           MapModal mapModal =
                                           BasicMethods.latLangExtractor(orderList[index].latlng.toString());


                                           MapsLauncher.launchCoordinates(mapModal.lat, mapModal.lng);
                                         },
                                         child: Row(children: [


                                           IconAndTextWidget(icon: Icons.location_city_outlined, text: orderList[index].address.toString(),
                                               iconColor: AppColors.yellowColor,longText: true,)
                                         ],),
                                       )
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    }),
              ),
            ),
          ],

        );
      },),

    ) ;
  }
}
