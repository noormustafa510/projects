import 'package:flutter/material.dart';
import 'package:get/get.dart';


import 'package:inform_us_admin/controller/accounts_controller.dart';
import 'package:inform_us_admin/utils/dimensions.dart';
import 'package:inform_us_admin/widget/app_text_field.dart';
import 'package:inform_us_admin/widget/big_text.dart';

import '../utils/colors.dart';

class CounterFeitSection extends StatelessWidget {
  const CounterFeitSection({super.key});


  @override
  Widget build(BuildContext context) {

    Get.find<AccountsController>().accountsLoggedIn();

    TextEditingController _dayController = TextEditingController();
    TextEditingController _monthController = TextEditingController();
    TextEditingController _yearController = TextEditingController();
    TextEditingController _saleController = TextEditingController();
    TextEditingController _profitController = TextEditingController();
    TextEditingController _profitRatioController = TextEditingController();
    TextEditingController _noOfItemsController = TextEditingController();
    TextEditingController _invoiceNumberController = TextEditingController();

    return
      GetBuilder<AccountsController>(builder: (_accountController){return Scaffold(
        appBar: AppBar(title: Text("CounterFeit Section"), backgroundColor: _accountController.cFColor, ),

        body:

        _accountController.accoutsLoggedInStatus?
        SingleChildScrollView(

          child: Container(
            child: Column(


              children: [

                SizedBox(height: Dimension.height30,),
                AppTextField(
                    textController: _dayController,
                    hintText: "Enter Day",
                    isObscure: false,
                    icon: Icons.date_range ),
                SizedBox(height: Dimension.height10,),

                AppTextField(
                    textController: _monthController,
                    hintText: "Enter Month",
                    isObscure: false,
                    icon: Icons.date_range ),
                SizedBox(height: Dimension.height10,),
                AppTextField(
                    textController: _yearController,
                    hintText: "Enter Year",
                    isObscure: false,
                    icon: Icons.date_range ),
                SizedBox(height: Dimension.height10,),
                AppTextField(
                    textController: _noOfItemsController,
                    hintText: "Enter Number of Items",
                    isObscure: false,
                    icon: Icons.numbers ),
                SizedBox(height: Dimension.height10,),
                AppTextField(
                    textController: _profitRatioController,
                    hintText: "Enter Percentage Ratio",
                    isObscure: false,
                    icon: Icons.percent ),
                SizedBox(height: Dimension.height10,),
                AppTextField(
                    textController:_saleController,
                    hintText: "Enter Total Sale",
                    isObscure: false,
                    icon: Icons.money_off ),
                SizedBox(height: Dimension.height10,),
                AppTextField(
                    textController: _profitController,
                    hintText: "Enter Net Fees",
                    isObscure: false,
                    icon: Icons.money ),
                SizedBox(height: Dimension.height10,),
                AppTextField(
                    textController: _invoiceNumberController,
                    hintText: "Enter Your Invoice",
                    isObscure: false,
                    icon: Icons.confirmation_number_outlined ),
                SizedBox(height: Dimension.height30,),


                Container(
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(Dimension.radius15),
                      border: Border.all(
                          color: Colors.grey
                      )

                  ),
                  child: TextButton(onPressed: (){

                    String day = _dayController.text.isEmpty ?'0' : _dayController.text;
                    String month = _monthController.text.isEmpty?'0':_monthController.text;
                    String year = _yearController.text.isEmpty?'0':_yearController.text;
                    String percentageRatio = _profitRatioController.text.isEmpty?'0':_profitRatioController.text;
                    String percentage = _profitController.text.isEmpty?'0':_profitController.text;
                    String sale = _saleController.text.isEmpty?'0':_saleController.text;
                    String noOfItems = _noOfItemsController.text.isEmpty?'0':_noOfItemsController.text;

                    String com =
                    _accountController.invoiceGenerator
                      (day: int.parse(day),
                        month: int.parse(month),
                        year: int.parse(year),
                        percentageRatio: int.parse(percentageRatio),
                        percentage: int.parse(percentage),
                        sale: int.parse(sale),
                        noOfItems: int.parse(noOfItems));

                    String inVoiceNumber = _invoiceNumberController.text.isEmpty?'0':_invoiceNumberController.text;

                    if(com == inVoiceNumber){
                      _accountController.setCFColor(Colors.green) ;
                    }else{
                      _accountController.setCFColor(Colors.red) ;
                    }

                  }, child: BigText(text: "Check", color: Colors.blue,
                    size: Dimension.font26,)),
                ),
                SizedBox(height: Dimension.height30,),


              ],

            ),
          ),
        ): Center(
          child: Text("You are not authorized!", style: TextStyle(
              fontSize: Dimension.font26, color: Colors.grey
          ),),
        ),


      ); });

  }
}

