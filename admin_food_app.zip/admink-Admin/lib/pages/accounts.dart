
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:inform_us_admin/Modal/billing_modal.dart';
import 'package:inform_us_admin/Modal/new_invoice.dart';
import 'package:inform_us_admin/Modal/shop_order_model.dart';
import 'package:inform_us_admin/base/custom_loader.dart';
import 'package:inform_us_admin/controller/accounts_controller.dart';
import 'package:inform_us_admin/controller/auth_controller.dart';
import 'package:inform_us_admin/pages/excel_generate.dart';
import 'package:inform_us_admin/utils/app_constants.dart';
import 'package:inform_us_admin/utils/colors.dart';
import 'package:inform_us_admin/utils/dimensions.dart';
import 'package:inform_us_admin/widget/big_text.dart';

import '../api/pdf_api.dart';
import '../api/pdf_invoice_api.dart';
import '../base/excel_generate_Method.dart';
import '../widget/app_text_field.dart';
import '../widget/icon_and_text_widget.dart';

class AccountsPage extends StatefulWidget {
  const AccountsPage({super.key});

  @override
  State<AccountsPage> createState() => _AccountsPageState();
}

class _AccountsPageState extends State<AccountsPage> {

  void _showDialog(Widget child) {
    showCupertinoModalPopup<void>(
      context: context,
      builder: (BuildContext context) => Container(
        height: 216,
        padding: const EdgeInsets.only(top: 6.0),
        // The Bottom margin is provided to align the popup above the system navigation bar.
        margin: EdgeInsets.only(
          bottom: MediaQuery.of(context).viewInsets.bottom,
        ),
        // Provide a background color for the popup.
        color: CupertinoColors.systemBackground.resolveFrom(context),
        // Use a SafeArea widget to avoid system overlaps.
        child: SafeArea(
          top: false,
          child: child,
        ),
      ),
    );
  }

  @override

  Widget build(BuildContext context) {
    List<BillingModal> billsList = [];
    TextEditingController accountID = TextEditingController();
    Get.find<AccountsController>().accountsLoggedIn();

    return Scaffold(
      appBar: AppBar(title: GestureDetector(
          onTap: () async {

            String minute = (DateTime.now().minute +2 ).toString();

            String day = (DateTime.now().day *4 ).toString();

            String password =minute+ AppConstants.ACCOUNTSPASSWORDPART + day;



           // print("invoked");
            if(password == accountID.text || AppConstants.PasswordForGoogle ==  accountID.text  ){
              Get.find<AccountsController>().accoutsLoggedInStatus == true;
              Get.find<AccountsController>().afterLoggedIn();

            }








          },
          child: Text("Accounts Section")), backgroundColor: AppColors.mainColor, ),


      body: GetBuilder<AccountsController>(builder: (_accountsController){



        return !_accountsController.accoutsLoggedInStatus? Center(
          child: AppTextField(
              textController: accountID,
              hintText: "Do not use me!",
              isObscure: true,
              icon: Icons.account_balance),

        ) : 
       Stack(
         children: [
           Positioned(child:  Column(
             mainAxisAlignment: MainAxisAlignment.start,
             children: [

               SizedBox(height: Dimension.height20,),

               Row(
                 children: [
                   BigText(text: "  Category:" , color: AppColors.mainColor,
                     size: Dimension.font20,),
                   CupertinoButton(
                       padding: EdgeInsets.zero,
                       child: BigText( text:"  "+ AppConstants.CATEOGORY[_accountsController.selectedCategory],
                         size: Dimension.font20*1.2,
                         color: Colors.grey,

                       ),onPressed: (){




                     _showDialog(CupertinoPicker(
                       magnification: 1.22,
                       squeeze: 1.2,
                       useMagnifier: true,
                       itemExtent: Dimension.kItemExtent,
                       // This sets the initial item.
                       scrollController: FixedExtentScrollController(
                         initialItem: _accountsController.selectedCategory,
                       ),
                       // This is called when selected item is changed.
                       onSelectedItemChanged: (int selectedItem) {
                         setState(() {
                           _accountsController.selectedCategory = selectedItem;
                         }
                         );
                       },
                       children:
                       List<Widget>.generate(AppConstants.CATEOGORY.length, (int index) {
                         return Center(child: Text(AppConstants.CATEOGORY[index]));
                       }),
                     ),);
                   })
                 ],
               ),
               Row(
                 children: [
                   BigText(text: "  S. Name:" , color: AppColors.mainColor,
                     size: Dimension.font20,),
                   CupertinoButton(
                       padding: EdgeInsets.zero,
                       child: BigText( text:"  "+ AppConstants.shopsByCategory[_accountsController.selectedCategory][_accountsController.selectedShop],
                         size: Dimension.font20*1.2,
                         color: Colors.grey,

                       ),onPressed: (){


                     _showDialog(CupertinoPicker(
                       magnification: 1.22,
                       squeeze: 1.2,
                       useMagnifier: true,
                       itemExtent: Dimension.kItemExtent,
                       // This sets the initial item.
                       scrollController: FixedExtentScrollController(
                         initialItem: _accountsController.selectedShop,
                       ),
                       // This is called when selected item is changed.
                       onSelectedItemChanged: (int selectedItem) {
                         setState(() {
                           _accountsController.selectedShop = selectedItem;
                         }
                         );
                       },
                       children:
                       List<Widget>.generate(AppConstants.shopsByCategory[_accountsController.selectedCategory].length, (int index) {
                         return Center(child: Text(AppConstants.shopsByCategory[_accountsController.selectedCategory][index]));
                       }),
                     ),);
                   })
                 ],
               ),
               Row(
                 mainAxisAlignment: MainAxisAlignment.spaceAround,
                 children: [
                   BigText(text: "From:" , color: Colors.green,
                     size: Dimension.font20,),
                   CupertinoButton(
                       padding: EdgeInsets.zero,
                       child: BigText( text:
                       AppConstants.Numbers[_accountsController.fromNumber],
                         size: Dimension.font20*1.2,
                         color: Colors.grey,

                       ),onPressed: (){


                     _showDialog(CupertinoPicker(
                       magnification: 1.22,
                       squeeze: 1.2,
                       useMagnifier: true,
                       itemExtent: Dimension.kItemExtent,
                       // This sets the initial item.
                       scrollController: FixedExtentScrollController(
                         initialItem: _accountsController.fromNumber,
                       ),
                       // This is called when selected item is changed.
                       onSelectedItemChanged: (int selectedItem) {
                         setState(() {
                           _accountsController.fromNumber = selectedItem;
                         }
                         );
                       },
                       children:
                       List<Widget>.generate(AppConstants.Numbers.length, (int index) {
                         return Center(child: Text(AppConstants.Numbers[index]));
                       }),
                     ),);
                   }),
                   BigText(text: "To:" , color: Colors.red,
                     size: Dimension.font20,),
                   CupertinoButton(
                       padding: EdgeInsets.zero,
                       child: BigText( text:
                       AppConstants.Numbers[_accountsController.toNumber],
                         size: Dimension.font20*1.2,
                         color: Colors.grey,

                       ),onPressed: (){


                     _showDialog(CupertinoPicker(
                       magnification: 1.22,
                       squeeze: 1.2,
                       useMagnifier: true,
                       itemExtent: Dimension.kItemExtent,
                       // This sets the initial item.
                       scrollController: FixedExtentScrollController(
                         initialItem: _accountsController.toNumber,
                       ),
                       // This is called when selected item is changed.
                       onSelectedItemChanged: (int selectedItem) {
                         setState(() {
                           _accountsController.toNumber = selectedItem;
                         }
                         );
                       },
                       children:
                       List<Widget>.generate(AppConstants.Numbers.length, (int index) {
                         return Center(child: Text(AppConstants.Numbers[index]));
                       }),
                     ),);
                   }),
                   BigText(text: "P:" , color: Colors.orange,
                     size: Dimension.font20,),
                   CupertinoButton(
                       padding: EdgeInsets.zero,
                       child: BigText( text:
                       AppConstants.Numbers[_accountsController.selectedProfit],
                         size: Dimension.font20*1.2,
                         color: Colors.grey,

                       ),onPressed: (){


                     _showDialog(CupertinoPicker(
                       magnification: 1.22,
                       squeeze: 1.2,
                       useMagnifier: true,
                       itemExtent: Dimension.kItemExtent,
                       // This sets the initial item.
                       scrollController: FixedExtentScrollController(
                         initialItem: _accountsController.selectedProfit,
                       ),
                       // This is called when selected item is changed.
                       onSelectedItemChanged: (int selectedItem) {
                         setState(() {
                           _accountsController.selectedProfit = selectedItem;
                         }
                         );
                       },
                       children:
                       List<Widget>.generate(AppConstants.Numbers.length, (int index) {
                         return Center(child: Text(AppConstants.Numbers[index]));
                       }),
                     ),);
                   }),

                 ],
               ),

               Row(
                 mainAxisAlignment: MainAxisAlignment.spaceAround,
                 children: [

                   IconButton(onPressed: () async {

                     await ExcelGenerateMethod.dataFetcher(AppConstants.Numbers[_accountsController.fromNumber],);


                   }, icon: Icon(Icons.data_object,
                     color: Colors.grey,
                     size: Dimension.iconSize24*1.3,
                   )),

                   TextButton(
                       onPressed: () async {



                         setState(() {
                           _accountsController.accountLoader = true;
                         });





                         _accountsController.totalProfit = 0;
                         _accountsController.totalBusiness = 0;
                         int shopID = 100*_accountsController.selectedShop + 10000*_accountsController.selectedCategory;
                         int frDays = int.parse(AppConstants.Numbers[_accountsController.fromNumber]);
                         int toDays = int.parse(AppConstants.Numbers[_accountsController.toNumber]);
                         List<String> daysList = [];

                         while(frDays<=toDays){
                           daysList.add(frDays.toString());
                           frDays++;
                         }
                         String mainDoc = shopID.toString() + '--'+ AppConstants.shopsByCategory[_accountsController.selectedCategory][_accountsController.selectedShop].removeAllWhitespace.toString();

                         billsList = [];

                      //   print("Shop ID is:" + mainDoc.toString());
                         int counter = 0;
                         for(String element in daysList)
                         {

                           int dailyBills = 0;

                           var docRef =
                           Get.find<AuthController>().db.collection(AppConstants.shopOrderCollection)
                               .doc(mainDoc ).collection(element).doc("delivery")

                               .withConverter(
                             fromFirestore: ShopOrderModel.fromFirestore,
                             toFirestore: (ShopOrderModel shopOrderModel, _) => shopOrderModel.toFirestore(),
                           );


                           final docSnap = await docRef.get();
                           var data = docSnap.data(); // Convert to City object
                           if (data != null) {
                             data.orders!.forEach((element) {
                               dailyBills += int.parse(element.billS!);

                             });

                             double percentage = dailyBills/100*
                                 int.parse(AppConstants.Numbers[_accountsController.selectedProfit]);

                             _accountsController.totalBusiness += dailyBills;
                             _accountsController.totalProfit += percentage.round();
                             final date = DateTime.now();
                             String dateToSend = element + "/" + date.month.toString()+ '/'+ date.year.toString();

                             billsList.add(BillingModal(day: dateToSend, bill: dailyBills ,
                                 percentage: percentage.round()
                             ));

                           } else {
                             final date = DateTime.now();
                             String dateToSend = element + "/" + date.month.toString()+ '/'+ date.year.toString();

                             billsList.add(BillingModal(day: dateToSend, bill: dailyBills, percentage:  0 ));

                           }

                        //   print("Bill for-${billsList[counter].day}:${billsList[counter].bill}");
                           counter++;

                         }


                         setState(() {
                           _accountsController.billsList = billsList;


                         });
                         _accountsController.accountLoader = false;





                       }
                       , child: Text("Calculate", style: TextStyle(
                       fontSize: Dimension.font26
                   ),)
                   ),
                   IconButton(onPressed: () async {


                     Uint8List spImage = await _accountsController.buildImage();


                     //final date = DateTime.now();
                     //final dueDate = date.add(Duration(days: 7));

                     // final invoice = Invoice(
                     //   supplier: Supplier(
                     //     name: 'Sarah Field',
                     //     address: 'Sarah Street 9, Beijing, China',
                     //     paymentInfo: 'https://paypal.me/sarahfieldzz',
                     //   ),
                     //   customer: Customer(
                     //     name: 'Apple Inc.',
                     //     address: 'Apple Street, Cupertino, CA 95014',
                     //   ),
                     //   info: InvoiceInfo(
                     //     date: date,
                     //     dueDate: dueDate,
                     //     description: 'My description...',
                     //     number: '${DateTime.now().year}-9999',
                     //   ),
                     //   items: [
                     //     InvoiceItem(
                     //       description: 'Coffee',
                     //       date: DateTime.now(),
                     //       quantity: 3,
                     //       vat: 0.19,
                     //       unitPrice: 5.99,
                     //     ),
                     //     InvoiceItem(
                     //       description: 'Water',
                     //       date: DateTime.now(),
                     //       quantity: 8,
                     //       vat: 0.19,
                     //       unitPrice: 0.99,
                     //     ),
                     //     InvoiceItem(
                     //       description: 'Orange',
                     //       date: DateTime.now(),
                     //       quantity: 3,
                     //       vat: 0.19,
                     //       unitPrice: 2.99,
                     //     ),
                     //     InvoiceItem(
                     //       description: 'Apple',
                     //       date: DateTime.now(),
                     //       quantity: 8,
                     //       vat: 0.19,
                     //       unitPrice: 3.99,
                     //     ),
                     //     InvoiceItem(
                     //       description: 'Mango',
                     //       date: DateTime.now(),
                     //       quantity: 1,
                     //       vat: 0.19,
                     //       unitPrice: 1.59,
                     //     ),
                     //     InvoiceItem(
                     //       description: 'Blue Berries',
                     //       date: DateTime.now(),
                     //       quantity: 5,
                     //       vat: 0.19,
                     //       unitPrice: 0.99,
                     //     ),
                     //     InvoiceItem(
                     //       description: 'Lemon',
                     //       date: DateTime.now(),
                     //       quantity: 4,
                     //       vat: 0.19,
                     //       unitPrice: 1.29,
                     //     ),
                     //   ],
                     // );




                     String shopName = AppConstants.shopsByCategory[_accountsController.selectedCategory][_accountsController.selectedShop];
                    final date = DateTime.now();
                     String issueanceDate = date.day.toString()+"/"+date.month.toString()+"/"+date.year.toString();
                     String dueDate = dueDateGenerator(DateTime.now(), 7);


                     NInvoiceInfo nInvoiceInfo = NInvoiceInfo
                       (invoiceNumber: _accountsController.invoiceGenerator
                       (day: date.day, month: date.month,
                         year: date.year,
                         percentageRatio: int.parse(AppConstants.Numbers[_accountsController.selectedProfit]),
                         percentage: _accountsController.totalProfit,
                         sale: _accountsController.totalBusiness, noOfItems: _accountsController.billsList.length),
                         issuanceDate: issueanceDate, dueDate: dueDate,
                         paymentMethod: 'Cash');



                  //   print("Special length is:"+ billsList.length.toString());


                     billsList.forEach((element) {
                   //    print("Checking spe:" + element.day.toString());
                     });

                     var invoice = NewInvoice(shopName:shopName, nInvoiceInfo:  nInvoiceInfo,
                         billList:  _accountsController.billsList,
                       sale: _accountsController.totalBusiness.toString(),
                       percentage: _accountsController.totalProfit.toString(),
                       percentageRatio: AppConstants.Numbers[_accountsController.selectedProfit]


                     );





                     final pdfFile = await PdfInvoiceApi.generate(invoice, spImage);
                     bool exist = await pdfFile.exists();

                //     print("object"+ exist.toString() );


                    await PdfApi.openFile(pdfFile);




                   }, icon: Icon(Icons.receipt,
                   color: Colors.grey,
                     size: Dimension.iconSize24*1.3,
                   )

                   )
                 ],
               ),


               !_accountsController.billsList.isEmpty?Expanded(
                 child: Padding(

                   padding:  EdgeInsets.only(top: Dimension.height10,),
                   child: SingleChildScrollView(

                     child: ListView.builder(
                         itemCount: _accountsController.billsList.length,
                         shrinkWrap: true,
                         physics: const NeverScrollableScrollPhysics(),
                         itemBuilder: (context, index){

                           return Padding(
                             padding: const EdgeInsets.all(8.0),
                             child: Row(
                               mainAxisAlignment: MainAxisAlignment.spaceAround,

                               children: [
                                 IconAndTextWidget(icon: Icons.history_toggle_off,

                                   text: _accountsController.billsList[index].day,
                                   //text: test[index],

                                   iconColor: AppColors.yellowColor,
                                   iconSize: Dimension.iconSize24*1.2, fontSize: Dimension.font20*1.1,
                                 ) ,
                                 IconAndTextWidget(icon: Icons.money_off,

                                   text: _accountsController.billsList[index].bill.toString(),
                                   //text: test[index],

                                   iconColor: AppColors.yellowColor,
                                   iconSize: Dimension.iconSize24*1.2, fontSize: Dimension.font20*1.1,
                                 ) ,
                                 IconAndTextWidget(icon: Icons.money,

                                   text: _accountsController.billsList[index].percentage.toString(),
                                   //text: test[index],

                                   iconColor: AppColors.yellowColor,
                                   iconSize: Dimension.iconSize24*1.2, fontSize: Dimension.font20*1.1,
                                 ) ,
                               ],
                             ),
                           );

                         }),

                   ),
                 ),
               ):
               Container(child: BigText(text: "There is no query!",
                 color: AppColors.mainColor,size: Dimension.font26*1.2,)

                 ,



               ),




               !_accountsController.billsList.isEmpty?Container(
                 margin: EdgeInsets.only(
                     top: Dimension.height10,
                     left: Dimension.height20
                 ),
                 child: Row(
                   mainAxisAlignment: MainAxisAlignment.spaceAround,
                   children: [
                     BigText(text: "Total:", color: Colors.grey,
                       size: Dimension.font26*1.2,),
                     IconAndTextWidget(icon: Icons.money_off,

                       text: _accountsController.totalBusiness.toString(),
                       //text: test[index],

                       iconColor: AppColors.yellowColor,
                       iconSize: Dimension.iconSize24*1.5, fontSize: Dimension.font26*1.1,
                     ) ,
                     IconAndTextWidget(icon: Icons.money,

                         text: _accountsController.totalProfit.toString(),
                         //text: test[index],

                         iconColor: AppColors.yellowColor,
                         iconSize: Dimension.iconSize24*1.5, fontSize: Dimension.font26*1.1
                     ) ,

                   ],
                 ),

               ):Container(),



             ],
           )),
           _accountsController.accountLoader?Positioned(child: CustomLoader()):Container(),
         ],
       );






      }
      ),

    );



  }
}

String dueDateGenerator(DateTime dateTime, int due){

  int dueInt = dateTime.day + due ;
  int month = dateTime.month;
int year = dateTime.year;



  if(dueInt > 30){
    dueInt -=30;
    month +=1;
    if(month >12){
      month = 1;
      year +=1;
    }
  }
  String dueReturn = dueInt.toString() + '/' + month.toString() + '/'+ year.toString();

  return dueReturn;
}