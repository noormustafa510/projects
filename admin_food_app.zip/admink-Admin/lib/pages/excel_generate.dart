import 'package:flutter/material.dart';
import 'package:inform_us_admin/utils/colors.dart';
import 'package:inform_us_admin/utils/dimensions.dart';

import '../widget/app_text_field.dart';

class ExcelGenerator extends StatelessWidget {
  const ExcelGenerator({super.key});
  

  @override
  Widget build(BuildContext context) {
    TextEditingController accountID = TextEditingController();
    return Scaffold(
      appBar: AppBar(title: Text("Authorization"), backgroundColor: AppColors.mainColor, ),
      body: Column(

        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          SizedBox(
            height: Dimension.height45*6,
          ),

          AppTextField(
              textController: accountID,
              hintText: "Enter Authorization Pin",
              isObscure: true,
              icon: Icons.password),
          SizedBox(
            height: Dimension.height45,
          ),

          ElevatedButton(onPressed: (){}, child: Padding(
            padding:  EdgeInsets.all(Dimension.height10*0.8),
            child: Text("Get Full Control.", style: TextStyle(
              fontSize: Dimension.font20
            ),),
          ) ,style: ButtonStyle(
            backgroundColor: MaterialStateProperty.all(AppColors.mainColor)
          ),)
        ],
      ),
    );
  }
}
