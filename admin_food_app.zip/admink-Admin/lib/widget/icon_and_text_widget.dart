import 'package:flutter/material.dart';
import 'package:inform_us_admin/widget/big_text.dart';

import 'package:inform_us_admin/widget/small_text.dart';

import '../utils/dimensions.dart';

class IconAndTextWidget extends StatelessWidget {
  final IconData icon;
  final String text;

  final double? fontSize ;
  final double? iconSize ;

  final Color iconColor;
  final bool? longText ;

  const IconAndTextWidget(
      {Key? key,
      required this.icon,
      required this.text,
        this.fontSize,
      required this.iconColor, this.iconSize, this.longText = false})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Icon(
          icon,
          color: iconColor,
         size: iconSize ?? Dimension.iconSize16,
        ),
        const SizedBox(width: 5),

        longText!?
        Text( text.length > 33 ? '${text.substring(0,33)}...' :text,  style: TextStyle(color: Colors.grey, fontSize: Dimension.font16,



        ), ):


        BigText(text: text, color: Colors.grey,

          size: fontSize ?? Dimension.font16),
      ],
    );
  }
}
//text.length > 25 ? '${text.substring(0,25)}...' :