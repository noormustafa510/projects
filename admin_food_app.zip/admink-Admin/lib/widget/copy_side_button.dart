import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:inform_us_admin/base/show_custom_snackbar.dart';

class CopySideButton extends StatelessWidget {
  IconData iconData;
  String data;
  String type;

   CopySideButton({super.key,  required this.iconData , required this.data, required this.type});




  @override
  Widget build(BuildContext context) {
    return  GestureDetector
      (
      onLongPress: () async {
        await Clipboard.setData(ClipboardData(text: data.toString() ));
      },
      onTap: ( ){
    Get.snackbar(data.toString(),"$type is mentioned." );

    },
       // showCustomSnackBar( data.toString() );


      child: Icon( iconData),
    );
  }
}
