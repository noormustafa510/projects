// import 'package:flutter/cupertino.dart';
// import 'package:flutter/material.dart';
// import 'package:inform_us_admin/utils/dimensions.dart';
// import 'package:inform_us_admin/widget/big_text.dart';
//
// class ShowDialog extends StatefulWidget {
//   const ShowDialog({super.key});
//
//   @override
//   State<ShowDialog> createState() => _ShowDialogState();
// }
//
// class _ShowDialogState extends State<ShowDialog> {
//
//   _showDialog(Widget child) {
//     showCupertinoModalPopup<void>(
//       context: context,
//       builder: (BuildContext context) => Container(
//         height: 216,
//         padding: const EdgeInsets.only(top: 6.0),
//         // The Bottom margin is provided to align the popup above the system navigation bar.
//         margin: EdgeInsets.only(
//           bottom: MediaQuery.of(context).viewInsets.bottom,
//         ),
//         // Provide a background color for the popup.
//         color: CupertinoColors.systemBackground.resolveFrom(context),
//         // Use a SafeArea widget to avoid system overlaps.
//         child: SafeArea(
//           top: false,
//           child: child,
//         ),
//       ),
//     );
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return  Row(
//       children: [
//         BigText(text: "  Category:" , color: AppColors.mainColor,
//           size: Dimension.font26,),
//         CupertinoButton(
//             padding: EdgeInsets.zero,
//             child: Text(
//
//               "Hello",
//               style: const TextStyle(
//                 fontSize: 22.0,
//               ),
//             ),onPressed: (){
//
//           print("object");
//           _showDialog(CupertinoPicker(
//             magnification: 1.22,
//             squeeze: 1.2,
//             useMagnifier: true,
//             itemExtent: Dimension.kItemExtent,
//             // This sets the initial item.
//             scrollController: FixedExtentScrollController(
//               initialItem: _accountsController.selectedCategory,
//             ),
//             // This is called when selected item is changed.
//             onSelectedItemChanged: (int selectedItem) {
//               setState(() {
//                 _accountsController.selectedCategory = selectedItem;
//               }
//               );
//             },
//             children:
//             List<Widget>.generate(AppConstants.fruitNames.length, (int index) {
//               return Center(child: Text(AppConstants.fruitNames[index]));
//             }),
//           ),);
//         })
//       ],
//     );
//   }
// }
