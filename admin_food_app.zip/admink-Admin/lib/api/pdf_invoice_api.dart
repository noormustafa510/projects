import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:inform_us_admin/Modal/new_invoice.dart';
import 'package:inform_us_admin/api/pdf_api.dart';
import 'package:inform_us_admin/utils.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:pdf/widgets.dart';

import '../Modal/customer.dart';
import '../Modal/invoice.dart';
import '../Modal/supplier.dart';

class PdfInvoiceApi {

  static Future<File> generate(NewInvoice invoice , Uint8List spImage) async {
    final pdf = Document();

    pdf.addPage(MultiPage(
      build: (context) => [
        buildHeader(invoice, spImage),
        SizedBox(height: 2.5 * PdfPageFormat.cm),
         buildTitle(),
         buildInvoice(invoice),
         Divider(),
         buildTotal(invoice),
      ],
     // footer: (context) => buildFooter(invoice),
    ));

    return PdfApi.saveDocument(name: 'my_invoice.pdf', pdf: pdf);
  }

  static Widget buildHeader(NewInvoice invoice, Uint8List spImage) => Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          //SizedBox(height: 1 * PdfPageFormat.cm),

          Container(
            height: PdfPageFormat.cm*2.5,
            child: pw.Image(pw.MemoryImage( spImage)),
          ),



          SizedBox(height: 1 * PdfPageFormat.cm),
          Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              buildCustomerAddress(invoice.shopName),
              buildInvoiceInfo(invoice.nInvoiceInfo),
            ],
          ),
        ],
      );

  static Widget buildCustomerAddress(String shopName) => Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(shopName, style: TextStyle(fontWeight: FontWeight.bold)),
          Text("City Kasur."),
        ],
      );

  static Widget buildInvoiceInfo(NInvoiceInfo info) {
    final paymentTerms = info.paymentMethod;
    final titles = <String>[
      'Invoice Number:',
      'Invoice Date:',
      'Payment Method:',
      'Due Date:'
    ];
    final data = <String>[
      info.invoiceNumber,
      info.issuanceDate,
      paymentTerms,
      info.dueDate,
    ];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: List.generate(titles.length, (index) {
        final title = titles[index];
        final value = data[index];

        return buildText(title: title, value: value, width: 200);
      }),
    );
  }

  static Widget buildSupplierAddress(Supplier supplier) => Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(supplier.name, style: TextStyle(fontWeight: FontWeight.bold)),
          SizedBox(height: 1 * PdfPageFormat.mm),
          Text(supplier.address),
        ],
      );

  static Widget buildTitle() => Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'INVOICE',
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
          ),


          SizedBox(height: 0.8 * PdfPageFormat.cm),
        ],
      );

  static Widget buildInvoice(NewInvoice invoice) {
    final headers = [
      'Date',
      'Sale',
      'Fees',

    ];
    final data = invoice.billList.map((item) {


      return [
        item.day,
        Utils.formatPrice(item.bill.toString()),


       Utils.formatPrice(item.percentage.toString()),

      ];
    }).toList();

    return Table.fromTextArray(
      headers: headers,
      data: data,
      border: null,
      headerStyle: TextStyle(fontWeight: FontWeight.bold),
      headerDecoration: BoxDecoration(color: PdfColors.grey300),
      cellHeight: 30,
      cellAlignments: {
        0: Alignment.centerLeft,
        1: Alignment.center,
        2: Alignment.centerRight,

      },
    );
  }

  static Widget buildTotal(NewInvoice invoice) {


    return Container(
      alignment: Alignment.centerRight,
      child: Row(
        children: [
          Spacer(flex: 6),
          Expanded(
            flex: 4,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                buildText(
                  title: 'Net Sale:',
                  value: Utils.formatPrice(invoice.sale),
                  unite: true,
                ),
                buildText(
                  title: 'Percentage',
                  value: invoice.percentageRatio +' %',
                  unite: true,
                ),
                Divider(),
                buildText(
                  title: 'Total Fees:',
                  titleStyle: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                  ),
                  value: Utils.formatPrice(invoice.percentage),
                  unite: true,
                ),
                SizedBox(height: 2 * PdfPageFormat.mm),
                Container(height: 1, color: PdfColors.grey400),
                SizedBox(height: 0.5 * PdfPageFormat.mm),
                Container(height: 1, color: PdfColors.grey400),
              ],
            ),
          ),
        ],
      ),
    );
  }

  static Widget buildFooter(Invoice invoice) => Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Divider(),
          SizedBox(height: 2 * PdfPageFormat.mm),
          buildSimpleText(title: 'Address', value: invoice.supplier.address),
          SizedBox(height: 1 * PdfPageFormat.mm),
          buildSimpleText(title: 'Paypal', value: invoice.supplier.paymentInfo),
        ],
      );

  static buildSimpleText({
    required String title,
    required String value,
  }) {
    final style = TextStyle(fontWeight: FontWeight.bold);

    return Row(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: pw.CrossAxisAlignment.end,
      children: [
        Text(title, style: style),
        SizedBox(width: 2 * PdfPageFormat.mm),
        Text(value),
      ],
    );
  }

  static buildText({
    required String title,
    required String value,
    double width = double.infinity,
    TextStyle? titleStyle,
    bool unite = false,
  }) {
    final style = titleStyle ?? TextStyle(fontWeight: FontWeight.bold);

    return Container(
      width: width,
      child: Row(
        children: [
          Expanded(child: Text(title, style: style)),
          Text(value, style: unite ? style : null),
        ],
      ),
    );
  }


}
