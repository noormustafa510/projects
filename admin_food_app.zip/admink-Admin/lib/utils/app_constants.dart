class AppConstants{

  static const int unitCharge  = 80;


  static const double Latitude = 31.121761;
  static const double Longitude = 74.451983;





  static const String DEVICETOKEN = "dtoken";
  static const String ACCOUNTSLOGGEDIN = "accounts-loggedIn-6";
  static const String ACCOUNTSPASSWORDPART = "@Rs";
  static const String PasswordForGoogle = "sdfQAadag143as63QSga322452asdfvbta3ad4as";


  static const String shopOrderCollection = "shopsOrder";
  static const String BLOCKINGKEY = "blockingkeyInAdmin-9";
  static const String DAYKEY = "Day-Key-9";
  static const int BLOCKINGACOUNTFORAUTTHENTICATON = 2;
  static const int BLOCKINGACCOUNTFORFIREBASE = 200;
  static const String idByUser = "userID";
  static const String passwordByUser = "userPassword";


  static const List<String> CATEOGORY = <String>[
    'Fast Food',
    'Restaurants',
    'Sweets',
    'Live Stock',
    'Nashta',
    'Dairy Prod',
    'Cheska',
    'Quick Res',

  ];
  static const List<List<String>> shopsByCategory = [
    FastFood,
    Restaurnats,
    Sweets,
    LiveStock,
    Nashta,
    DairyProd,
    Cheska,
    QuickRes


  ];

  static const List<String> FastFood = <String>[
    'Top Taste',
    'Arab',
    'Hot Chicks',
    'Top Hit',
    'A1',
    'Grill Hacks',
    'Cherry Wood',
    'Zubair Fast Food',
    'Khalil Bakers',
    'Pizza Shed',
    'Chick Boss',
    'Turkish Cafe',

  ];
  static const List<String> Restaurnats = <String>[
    'Diwan',
    'Al-Wali',
    'Driver Hotel',
    'Manu Karahi',
    'Shafqat RST',
    'Islam Paratha',
    'Hamza KB Beef Palao',
    'Karachi Naseeb Biryani',
    'Jutt Jenjoa BBQ',
    'Rehman Taka Tek',
    'Asif Ghulam Nabi Karahi',
    'Iqbal Pakore Wala',
    'Ali Ahmed Charga',
  ];
  static const List<String> Sweets = <String>[
    'Asgher Sweets',
    'Nafees Faloda',
    'Ayoub Faloda',
    'Noor Milk Products',
    'Russian Salad',
    'Anayet Kulfi',
    'Thend Program',
    'Sheikh Milk Product',

  ];
  static const List<String> LiveStock = <String>[
    'Chicken Shop',
    'Muttton Shop',
    'Beef Shop',
  ];
  static const List<String> Nashta = <String>[
    'Sai Booti',
    'Makkah Chanay',
    'Madina Chanay',
    'Billa Chanay Wala',
    'Majeed Helva Pori',
    'Sheikh Pori Helva',

  ];
  static const List<String> DairyProd = <String>[
    'Ashrif Milk Shop',
    'Jutt Milk Shop',

  ];
  static const List<String> Cheska = <String>[
    'Gol Gappay Shop',
    'Bulleh Shah Pathore',
    'Qetli Samosa',
    'Remzan Samose',
    'Hayat Finger Chips',
  ];
  static const List<String> QuickRes = <String>[
    'Break Fast',
    'Drinks',
    'Khokha Shop',
  ];
  static const List<String> Numbers = <String>[
    '1',
    '2',
    '3',
    '4',
    '5',
    '6',
    '7',
    '8',
    '9',
    '10',
    '11',
    '12',
    '13',
    '14',
    '15',
    '16',
    '17',
    '18',
    '19',
    '20',
    '21',
    '22',
    '23',
    '24',
    '25',
    '26',
    '27',
    '28',
    '29',
    '30',
    '31',


  ];





}