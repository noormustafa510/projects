import 'dart:io';

import 'package:geolocator/geolocator.dart';
import 'package:get/get.dart';
import 'package:inform_us_admin/Modal/map_modal.dart';
import 'package:inform_us_admin/controller/auth_controller.dart';
import 'package:inform_us_admin/utils/app_constants.dart';
import 'package:url_launcher/url_launcher.dart';

class BasicMethods{

  static MapModal latLangExtractor(String customerAddress){
    String tempString = customerAddress.removeAllWhitespace.toString();
    int index  = tempString.indexOf(',');
    double cusLat = double.parse(tempString.substring(0,index));
    double cusLang = double.parse( tempString.substring(index+1));
    MapModal mapModal = MapModal(lat: cusLat, lng: cusLang);

    return mapModal;



  }

  static int fareCalculator(String customerAddress) {

   MapModal mapModal = latLangExtractor(customerAddress);


    double cusLat = mapModal.lat;
    double cusLang = mapModal.lng;





    int tempFare = int.parse(Get.find<AuthController>().deliveryCharge);

    int fare = 0;
    int dis = Geolocator.distanceBetween(cusLat, cusLang,
        AppConstants.Latitude, AppConstants.Longitude)
        .round();

    print("Distance: " + dis.toString());

    if (dis < 650) {
      fare = (tempFare * 0.9).round();
    } else if (dis < 850) {
      fare = (tempFare * 1.2).round();
    } else if (dis < 1100) {
      fare = (tempFare * 1.3).round();
    } else if (dis < 1500) {
      fare = (tempFare * 1.4).round();
    } else if (dis < 1800) {
      fare = (tempFare * 1.5).round();
    } else {
      fare = (tempFare * 1.6).round();
    }
   print("Fare: " + fare.toString());

    return fare;
  }
  static Future<void> goToWhatsApp(String message) async {
    var contact = "";
    var androidUrl = "whatsapp://send?phone=$contact&text=$message";
    var iosUrl = "https://wa.me/$contact?text=${Uri.parse(message)}";

    try {
      if (Platform.isAndroid) {
        await launchUrl(Uri.parse(androidUrl));
      }
      else {
        await launchUrl(Uri.parse(iosUrl));
      }
    } on Exception {
      //EasyLoading.showError('WhatsApp is not installed.');
    }
  }
}