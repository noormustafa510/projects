import 'dart:io';
import 'package:get/get.dart';
import 'package:open_filex/open_filex.dart';

import 'package:syncfusion_flutter_xlsio/xlsio.dart';
import 'package:path_provider/path_provider.dart';

import '../Modal/order_modal.dart';
import '../controller/auth_controller.dart';

class ExcelGenerateMethod{

  static dataFetcher(String day) async {

    List<Orders> deliveryOrders;
    List<Orders> takeAwayOrders;

    //for delivery orders
    var deliveryRef = Get.find<AuthController>().db.collection("adminOrder").doc(day).withConverter(
      fromFirestore: AdminOrder.fromFirestore,
      toFirestore: (AdminOrder adminOrder, _) => adminOrder.toFirestore(),
    );
    var docSnapforDelivery = await deliveryRef.get();
    var dataForDelivery = docSnapforDelivery.data();
    deliveryOrders = dataForDelivery?.orders ?? [];


//for take away orders
    var takeAwayRef = Get.find<AuthController>().db.collection("adminOrderTake").doc(day).withConverter(
      fromFirestore: AdminOrder.fromFirestore,
      toFirestore: (AdminOrder adminOrder, _) => adminOrder.toFirestore(),
    );
    var docSnapforTakeAway = await takeAwayRef.get();
    var dataForTakeAway = docSnapforTakeAway.data();
    takeAwayOrders = dataForTakeAway?.orders ?? [];




    await excelGenerator(deliveryOrders, takeAwayOrders, day);









  }




  static excelGenerator( List<Orders> deliveryOrders,  List<Orders> takeAwayOrders, String day ) async {
    int marker = 3;
    final dateRef =  DateTime.now();
    String date = day+'-' + dateRef.month.toString()  +'-' + dateRef.year.toString();
    final Workbook workbook = new Workbook();
    final Worksheet sheet = workbook.worksheets[0];



    sheet.getRangeByName('A1').setText('Phoneُ');
    sheet.getRangeByName('B1').setText('Name');
    sheet.getRangeByName('C1').setText('LatLng');
    sheet.getRangeByName('D1').setText('Address');
    sheet.getRangeByName('E1').setText('Price');
    sheet.getRangeByName('F1').setText('Deive Info');
    sheet.getRangeByName('G1').setText('Deive-ID');
    sheet.getRangeByName('H1').setText('Address-Type');


    deliveryOrders.forEach((element) {

      sheet.getRangeByName('A$marker').setText(element.phone);
      sheet.getRangeByName('B$marker').setText(element.name);
      sheet.getRangeByName('C$marker').setText(element.latlng);
      sheet.getRangeByName('D$marker').setText(element.address);
      sheet.getRangeByName('E$marker').setText(element.price);
      sheet.getRangeByName('F$marker').setText(element.deviceInfo);
      sheet.getRangeByName('G$marker').setText(element.deviceID);
      sheet.getRangeByName('H$marker').setText(element.addressType);

      marker++;


    });

    marker = marker +4 ;

    takeAwayOrders.forEach((element) {

      sheet.getRangeByName('A$marker').setText(element.phone);
      sheet.getRangeByName('B$marker').setText(element.name);
      sheet.getRangeByName('C$marker').setText(element.latlng);
      sheet.getRangeByName('D$marker').setText(element.address);
      sheet.getRangeByName('E$marker').setText(element.price);
      sheet.getRangeByName('F$marker').setText(element.deviceInfo);
      sheet.getRangeByName('G$marker').setText(element.deviceID);
      sheet.getRangeByName('H$marker').setText(element.addressType);

      marker++;


    });





    final List<int> bytes = workbook.saveAsStream();

//Dispose the workbook.
    workbook.dispose();
    final String path = (await getApplicationDocumentsDirectory()).path;

    final String fileName = '$path/$date.xlsx';
    final File  file = File(fileName);

    file.writeAsBytes(bytes);
    OpenFilex.open(fileName);







  }
}