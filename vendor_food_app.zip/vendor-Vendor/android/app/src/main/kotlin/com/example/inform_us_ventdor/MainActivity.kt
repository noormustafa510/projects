package com.example.inform_us_ventdor

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
