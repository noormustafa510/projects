import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_ringtone_player/flutter_ringtone_player.dart';

import 'package:get/get.dart';
import 'package:inform_us_ventdor/main.dart';

import '../base/custom_loader.dart';
import '../controller/auth_controller.dart';
import '../controller/delivery_order_controller.dart';
import '../model/shop_order_model.dart';
import '../utils/colors.dart';
import '../utils/dimensions.dart';

import '../widgets/big_text.dart';
import '../widgets/icon_and_text_widget.dart';

class DeliveryOrders extends StatelessWidget {
  const DeliveryOrders({Key? key}) : super(key: key);

  @override

  Widget build(BuildContext context) {




    List<Orders> orderList = [];

    return Scaffold(
      appBar: AppBar(title: GestureDetector(
          onTap: () async {await FlutterRingtonePlayer.stop();},
          child: Text(Get.find<AuthController>().vendorShopName +"--Delivery Orders")), backgroundColor: AppColors.mainColor, ),
      body:
      GetBuilder<DeliveryOrderController>(builder: (dController){

       if(dController.orderList.isNotEmpty)
       { orderList = dController.orderList.reversed.toList();}

       else {


       }





        return orderList.isEmpty?const CustomLoader():  Column(


          children: [
            SizedBox(height: Dimension.height10*1.2,),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [


                //date
                Container(height: Dimension.height45, width: Dimension.width30*4,
                  decoration: BoxDecoration(
                    color: Colors.grey,
                    borderRadius: BorderRadius.circular(Dimension.radius20*0.7),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [ BigText(text: "Date:" , color: Colors.white, ),
                      BigText(text: " ${  DateTime.now().day}"),],),),
                //no of orders
                Container(
                  height: Dimension.height45, width: Dimension.width30*4, decoration: BoxDecoration(

                    borderRadius: BorderRadius.circular(Dimension.radius20*0.7),
                    border: Border.all(
                        color: Colors.grey,
                        width: Dimension.font16/5
                        , style: BorderStyle.solid,
                        strokeAlign: BorderSide.strokeAlignInside

                    )
                ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.delivery_dining_outlined , size: Dimension.font26*1.2,color: Colors.grey,),
                      BigText(text: " "+orderList.length.toString(), color: AppColors.mainColor, size: Dimension.font26*1,)


                    ],
                  ),


                ),
                TextButton(onPressed: () async {
                  await FlutterRingtonePlayer.stop();













                  //final docSnap = await docRef.get();






                  //  final core = docSnap.data(); // Convert to City object
                  // AdminOrder adminOrder = AdminOrder();
                  //  adminOrder = core!;


                  //print("object" + adminOrder.orders![0].name.toString());




                }, child: Text("Silent"))


              ],),
            SizedBox(height: Dimension.height20,),
            Expanded(
              child: SingleChildScrollView(
                child: ListView.builder(
                    itemCount: orderList.length,
                    shrinkWrap: true,
                    physics: NeverScrollableScrollPhysics(),
                    itemBuilder: (context, index) {

                      return GestureDetector(
                        onTap: () async {
                          await FlutterRingtonePlayer.stop();
                          showModalBottomSheet(
                              backgroundColor: Colors.transparent,
                              context: context,
                              builder: (_) {
                                return Column(
                                  children: [
                                    Expanded(
                                      child: SingleChildScrollView(
                                        child: Container(

                                          height: MediaQuery
                                              .of(context)
                                              .size
                                              .height *
                                              6,

                                          decoration: BoxDecoration(
                                            color: Colors.white,
                                            borderRadius: BorderRadius.only(
                                              topLeft: Radius.circular(
                                                  Dimension.radius20),
                                              topRight: Radius.circular(
                                                  Dimension.radius20),
                                            ),
                                          ),
                                          child: Column(
                                            children: [
                                              Container(
                                                width: double.maxFinite,
                                                padding: EdgeInsets.only(
                                                    top: Dimension.height20,
                                                    right: Dimension.width20,
                                                    left: Dimension.width20),

                                                child: Column(
                                                  crossAxisAlignment:
                                                  CrossAxisAlignment
                                                      .start,
                                                  children: [



                                                    Center(
                                                      child: Text(
                                                        'Order Details',
                                                        style: TextStyle(
                                                            color: Colors.grey,
                                                            fontWeight:
                                                            FontWeight.bold,
                                                            fontSize: Dimension
                                                                .font26*1.2),
                                                      ),
                                                    ),


                                                    SizedBox(
                                                      height:
                                                      Dimension.height20,
                                                    ),
                                                    //   BigText(text: orderList[index].note!),

                                                    BigText(text: "Note:-", size: Dimension.font26, color: Colors.red,) ,

                                                    Text(orderList[index].note!,style: TextStyle(
                                                        fontSize: Dimension.font26

                                                    ),),
                                                    SizedBox(height: Dimension.height20),
                                                    BigText(text: "Products Details:", size: Dimension.font26, color: Colors.grey, ),

                                                    SizedBox(height: Dimension.height10,),

                                                    Container(

                                                      child: ListView.builder(itemCount: orderList[index].productsS!.length,
                                                          shrinkWrap: true,
                                                          physics:
                                                          NeverScrollableScrollPhysics(),
                                                          itemBuilder: (context, sIndex){

                                                            var product = orderList[index].productsS![sIndex];



                                                            return Container(


                                                              child: Column(
                                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                                children: [
                                                                  Text( product.nameS.toString() +" x " +
                                                                      product.quantityS.toString()+" =   "
                                                                      + (int.parse(product.priceS.toString())*int.parse(product.quantityS.toString())).
                                                                      toString(), style: TextStyle(
                                                                      color: AppColors.mainColor,
                                                                      fontSize: Dimension.font26
                                                                  ),


                                                                  )

                                                                  // , ListView.builder(
                                                                  //     itemCount:
                                                                  //     shops[sIndex].products!.length,
                                                                  //     shrinkWrap: true,
                                                                  //     physics:
                                                                  //     NeverScrollableScrollPhysics(),
                                                                  //
                                                                  //     itemBuilder: (context, pIndex){
                                                                  //   List<Products> products = shops[sIndex].products!;
                                                                  //   return Container(
                                                                  //
                                                                  //     child:
                                                                  //     Center(
                                                                  //       child: BigText(
                                                                  //           text:
                                                                  //           products[pIndex].name.toString() + " x " +products[pIndex].quantity.toString(), size: Dimension.font26,
                                                                  //       ),
                                                                  //     )
                                                                  //   );
                                                                  //  }),

                                                                  ,SizedBox(height: Dimension.height10,)

                                                                ],
                                                              ),

                                                            );

                                                          }),)


                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                );
                              });
                        }
                            ,
                                // .whenComplete(() =>
                                // orderController
                                //     .setFoodNote(_noteController.text.trim())),
                        child: Container(
                          margin: EdgeInsets.only(
                              left: Dimension.width20,
                              right: Dimension.width20,
                              bottom: Dimension.width10),
                          child: Row(
                            children: [
                              //Image Section

                              Container(height:  Dimension.listViewTextContSize,width: Dimension.width10,
                              color: index.isEven? AppColors.yellowColor : Colors.grey  ),

                              //Text Container
                              Expanded(
                                child: Container(
                                  height: Dimension.listViewTextContSize,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.only(
                                      topRight:
                                      Radius.circular(Dimension.radius20),
                                      bottomRight:
                                      Radius.circular(Dimension.radius20),
                                    ),
                                    color: Colors.white,
                                  ),
                                  child: Padding(
                                    padding: EdgeInsets.only(
                                      left: Dimension.width10,
                                      right: Dimension.width10,
                                    ),
                                    child: Column(
                                      crossAxisAlignment:
                                      CrossAxisAlignment.start,
                                      mainAxisAlignment: MainAxisAlignment.start,
                                      children: [
                                      //first row: Name
                                        SizedBox(height: Dimension.height10,),
                                        IconAndTextWidget(iconSize: Dimension.iconSize24*1.1,
                                          fontSize: Dimension.font26,icon: Icons.person,
                                          text: orderList[index].cNameSh.toString(), iconColor: AppColors.mainColor,),

                                        SizedBox(
                                          height: Dimension.height10,
                                        ),

                                        Row(children: [


                                          IconAndTextWidget(icon: Icons.money, text: orderList[index].billS.toString(), iconColor: Colors.grey
                                          ,iconSize: Dimension.iconSize24, fontSize: Dimension.font26,
                                          )
                                         , BigText(text: " | ", size: Dimension.font20,),
                                          IconAndTextWidget(icon: Icons.punch_clock, text: orderList[index].timeS.toString(),
                                              iconColor: Colors.red,iconSize: Dimension.iconSize24, fontSize: Dimension.font26,),

                                          BigText(text: " | ", size: Dimension.font20,),
                                          IconAndTextWidget(icon: Icons.format_list_numbered_sharp,
                                              text: orderList[index].productsS!.length.toString(), iconColor: Colors.indigo,iconSize: Dimension.iconSize24, fontSize: Dimension.font26, )

                                        ],),




                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    }),
              ),
            ),
          ],

        );
      },),

    ) ;
  }
}
