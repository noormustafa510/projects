

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:inform_us_ventdor/base/custom_loader.dart';




import '../../utils/colors.dart';


import '../controller/auth_controller.dart';
import '../utils/dimensions.dart';
import '../widgets/app_text_field.dart';
import '../widgets/big_text.dart';


class SignInPage extends StatelessWidget {
  const SignInPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {


    var idController = TextEditingController();
    var passwordController = TextEditingController();
    idController.text =  Get.find<AuthController>().getUserIDfromShareResource()??'';
    passwordController.text = Get.find<AuthController>().getUserPasswordfromShareResource() ??'';

    //idController.text =

    // se(){
    //
    //
    //
    //
    // }





    return Scaffold(
        backgroundColor: Colors.white,
        body: GetBuilder<AuthController>(builder: (authController) {

          return Stack(
            children: [
              Positioned(child: SingleChildScrollView(
                physics: BouncingScrollPhysics(),
                child: Column(
                  children: [
                    SizedBox(
                      height: Dimension.screenHeight * 0.05,
                    ),
                    //Your logo
                    Container(
                      height: Dimension.screenHeight * 0.25,
                      child: Center(
                        child: Image.asset("assets/images/asset1.png", scale: 3
                          ,),
                      ),
                    ),

                    //welcome
                    Container(
                      margin: EdgeInsets.only(left: Dimension.width20),
                      width: double.maxFinite,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Hello',
                            style: TextStyle(
                                fontSize:
                                Dimension.font20 * 3 + Dimension.font20 / 2,
                                fontWeight: FontWeight.bold),
                          ),
                          Text(
                            'Vendor',
                            style: TextStyle(
                                fontSize: Dimension.font20,
                                color: Colors.grey[500]),
                          )
                        ],
                      ),
                    ),
                    SizedBox(
                      height: Dimension.height20,
                    ),
                    //Your Email
                    AppTextField(
                        textController: idController,
                        hintText: "ID",
                        icon: Icons.perm_identity_outlined),
                    SizedBox(
                      height: Dimension.height20,
                    ),
                    //Your password
                    AppTextField(
                        textController: passwordController,
                        hintText: "Password",
                        isObscure: true,
                        icon: Icons.password_sharp),
                    SizedBox(
                      height: Dimension.height20,
                    ),

                    //Tag line
                    Row(
                      children: [
                        Expanded(child: Container()),
                        RichText(
                          text: TextSpan(
                            text: 'Sign into your account',
                            style: TextStyle(
                              color: Colors.grey[500],
                              fontSize: Dimension.font20,
                            ),
                          ),
                        ),
                        SizedBox(
                          width: Dimension.width20,
                        )
                      ],
                    ),
                    SizedBox(
                      height: Dimension.screenHeight * 0.05,
                    ),
                    //Sign Up Button

                    GestureDetector(
                      onTap: () async {
                        // await authController.initialPerToken();
                        authController.updateLoaderStatus(true);

                        authController.setUserIDinShareResource(idController.text);
                        authController.setUserPasswordinShareResource(passwordController.text);
                        await authController.signUpProcess(idController.text, passwordController.text);



                      },
                      child: Container(
                        width: Dimension.screenWidth / 2,
                        height: Dimension.screenHeight / 13,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(Dimension.radius30),
                          color: AppColors.mainColor,
                        ),
                        child: Center(
                            child: BigText(
                              text: 'Sign in',
                              color: Colors.white,
                              size: Dimension.font20 + Dimension.font20 / 2,
                            )),
                      ),
                    ),
                    SizedBox(
                      height: Dimension.screenHeight * 0.05,
                    ),
                    //Sign Up options

                  ],
                ),
              ))
              ,authController.customLoaderStatus? Positioned(child: CustomLoader()):Container(),
            ],
          );
        }));
  }
}

// else if (!GetUtils.isEmail(email)) {
// showCustomSnackBar("Type in valid email address",
// title: 'Valid Email Address');
// }