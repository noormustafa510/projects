import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../controller/auth_controller.dart';
import '../controller/delivery_order_controller.dart';
import '../controller/take_order_controller.dart';

Future<void> init() async {
  SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
  Get.lazyPut(() => sharedPreferences);
  Get.lazyPut(() => AuthController(sharedPreferences: Get.find() ));
   Get.lazyPut(() => DeliveryOrderController());
   Get.lazyPut(() => TakeOrderController());

}