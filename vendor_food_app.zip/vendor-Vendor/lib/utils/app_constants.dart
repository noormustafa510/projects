class AppConstants{
  static const String DEVICETOKEN = "dtoken";
  //Revenue List
  static const String revenueListKey = "rkey";
  static const String blockingKey = "block-key-12";
  static const String idByUser = "userID";
  static const String passwordByUser = "userPassword";

  static const int FIREBASECOUNT = 20;
  static const int WRONGATTEMPT = 4;
  static const String subFraction = '1';


}