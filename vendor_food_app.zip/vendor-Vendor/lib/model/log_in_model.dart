import 'package:cloud_firestore/cloud_firestore.dart';

class LogIn {
  List<VendorInfo>? vendorInfo;

  LogIn({this.vendorInfo});

  LogIn.fromFirestore(DocumentSnapshot<Map<String, dynamic>> snapshot,
      SnapshotOptions? options,) {
    final json = snapshot.data();
    if (json!['vendorInfo'] != null) {
      vendorInfo = <VendorInfo>[];
      json['vendorInfo'].forEach((v) {
        vendorInfo!.add(new VendorInfo.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toFirestore() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.vendorInfo != null) {
      data['vendorInfo'] = this.vendorInfo!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class VendorInfo {
  String? password;
  String? id;
  String? shopName;
  String? shopId;

  VendorInfo({this.password, this.id, this.shopName, this.shopId});

  VendorInfo.fromJson(Map<String, dynamic> json) {
    password = json['password'];
    id = json['id'];
    shopName = json['shopName'];
    shopId = json['shopId'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['password'] = this.password;
    data['id'] = this.id;
    data['shopName'] = this.shopName;
    data['shopId'] = this.shopId;
    return data;
  }
}
