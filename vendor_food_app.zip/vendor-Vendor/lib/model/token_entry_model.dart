import 'package:cloud_firestore/cloud_firestore.dart';

class TokenEntryModel {
  List<Tokens>? tokens;

  TokenEntryModel({this.tokens});

  TokenEntryModel.fromFirestore(DocumentSnapshot<Map<String, dynamic>> snapshot,
      SnapshotOptions? options,) {
    final json = snapshot.data();
    if (json!['tokens'] != null) {
      tokens = <Tokens>[];
      json['tokens'].forEach((v) {
        tokens!.add(new Tokens.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toFirestore() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.tokens != null) {
      data['tokens'] = this.tokens!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Tokens {
  String? token;
  String? shopId;

  Tokens({this.token, this.shopId});

  Tokens.fromJson(Map<String, dynamic> json) {
    token = json['token'];
    shopId = json['shopId'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['token'] = this.token;
    data['shopId'] = this.shopId;
    return data;
  }
}
