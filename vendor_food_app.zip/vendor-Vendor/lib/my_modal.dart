import 'package:cloud_firestore/cloud_firestore.dart';

class AllProductModel {
  int? deliveryCharges;
  String? martNumber;

  List<Deals>? deals;
  List<Mart>? mart;
  List<Categories>? categories;

  AllProductModel(
      {this.deals,
        this.mart,
        this.categories,
        this.deliveryCharges,
        this.martNumber});

  AllProductModel.fromFireStore(
      DocumentSnapshot<Map<String, dynamic>> snapshot,
      SnapshotOptions? options,
      ) {
    final json = snapshot.data();
    if (json!['deals'] != null) {
      deals = <Deals>[];
      json['deals'].forEach((v) {
        deals!.add(new Deals.fromJson(v));
      });
    }
    if (json['mart'] != null) {
      mart = <Mart>[];
      json['mart'].forEach((v) {
        mart!.add(new Mart.fromJson(v));
      });
    }
    if (json['categories'] != null) {
      categories = <Categories>[];
      json['categories'].forEach((v) {
        categories!.add(new Categories.fromJson(v));
      });
    }

    this.deliveryCharges = json['delivery-charges'];
    this.martNumber = json['mart-number'];
  }

  Map<String, dynamic> toFireStore() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.deals != null) {
      data['deals'] = this.deals!.map((v) => v.toJson()).toList();
    }
    if (this.mart != null) {
      data['mart'] = this.mart!.map((v) => v.toJson()).toList();
    }
    if (this.categories != null) {
      data['categories'] = this.categories!.map((v) => v.toJson()).toList();
    }
    data['delivery-charges'] = this.deliveryCharges;
    data['mart-number'] = this.martNumber;
    return data;
  }
}

class Deals {
  String? price;
  String? rName;
  String? time;
  String? name;
  String? desc;
  String? distance;

  Deals(
      {this.price, this.rName, this.time, this.name, this.desc, this.distance});

  Deals.fromJson(Map<String, dynamic> json) {
    price = json['price'];
    rName = json['rName'];
    time = json['time'];
    name = json['name'];
    desc = json['desc'];
    distance = json['distance'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['price'] = this.price;
    data['rName'] = this.rName;
    data['time'] = this.time;
    data['name'] = this.name;
    data['desc'] = this.desc;
    data['distance'] = this.distance;
    return data;
  }
}

class Mart {
  String? cname;
  List<Collection>? collection;

  Mart({this.cname, this.collection});

  Mart.fromJson(Map<String, dynamic> json) {
    cname = json['cname'];
    if (json['collection'] != null) {
      collection = <Collection>[];
      json['collection'].forEach((v) {
        collection!.add(new Collection.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['cname'] = this.cname;
    if (this.collection != null) {
      data['collection'] = this.collection!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Collection {
  String? ccname;
  List<Products>? products;

  Collection({this.ccname, this.products});

  Collection.fromJson(Map<String, dynamic> json) {
    ccname = json['ccname'];
    if (json['products'] != null) {
      products = <Products>[];
      json['products'].forEach((v) {
        products!.add(new Products.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['ccname'] = this.ccname;
    if (this.products != null) {
      data['products'] = this.products!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Products {
  String? name;
  String? price;

  Products({this.name, this.price});

  Products.fromJson(Map<String, dynamic> json) {
    name = json['name'];
    price = json['price'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['name'] = this.name;
    data['price'] = this.price;
    return data;
  }
}

class Categories {
  String? name;
  List<Shops>? shops;

  Categories({this.name, this.shops});

  Categories.fromJson(Map<String, dynamic> json) {
    name = json['name'];
    if (json['shops'] != null) {
      shops = <Shops>[];
      json['shops'].forEach((v) {
        shops!.add(new Shops.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['name'] = this.name;
    if (this.shops != null) {
      data['shops'] = this.shops!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Shops {
  String? name;
  String? phone;
  List<Products>? products;

  Shops({this.name, this.phone, this.products});

  Shops.fromJson(Map<String, dynamic> json) {
    name = json['name'];
    phone = json['phone'];
    if (json['products'] != null) {
      products = <Products>[];
      json['products'].forEach((v) {
        products!.add(new Products.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['name'] = this.name;
    data['phone'] = this.phone;
    if (this.products != null) {
      data['products'] = this.products!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}
