
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_ringtone_player/flutter_ringtone_player.dart';
import 'package:get/get.dart';
import 'package:inform_us_ventdor/model/shop_order_model.dart';

import 'auth_controller.dart';


class TakeOrderController extends GetxController implements GetxService{
  List<Orders> orderList = [];


  var db = Get.find<AuthController>().db;
  late int lengthOfList ;







  getDeliveryOrdersFromFireStore() async {
    ShopOrderModel shopOrder = ShopOrderModel();

    var day  = DateTime.now().day.toString();
    String delivery = "take";
    String mainCollection = "shopsOrder";
    String shopID = Get.find<AuthController>().vendorShopId;
    String shopName = Get.find<AuthController>().vendorShopName;

    String docId =

        "${shopID}--${shopName
        .toString()
        .capitalize
        .toString()
        .removeAllWhitespace}";









    var docRef = db.collection(mainCollection).doc(docId).collection(day).doc(delivery)

        .withConverter(
      fromFirestore: ShopOrderModel.fromFirestore,
      toFirestore: (ShopOrderModel shopOrderModel, _) => shopOrderModel.toFirestore(),
    );


    docRef.snapshots().listen(
          (event){
        day  = DateTime.now().day.toString();
        var docRef = db.collection(mainCollection).doc(docId).collection(day).doc(delivery).withConverter(
          fromFirestore: ShopOrderModel.fromFirestore,
          toFirestore: (ShopOrderModel shopOrderModel, _) => shopOrderModel.toFirestore(),
        );

        if(event.data() != null)
        {
          shopOrder = event.data()!;


          orderList = shopOrder.orders!;


        }
        else{
          Get.snackbar("Error", "Occurred");
        }

        update();




        FlutterRingtonePlayer.play(
          android: AndroidSounds.ringtone,
          ios: IosSounds.glass,
          looping: true, // Android only - API >= 28
          volume: 0.1, // Android only - API >= 28
          asAlarm: false, // Android only - all APIs
        );



      } ,


      onError: (error) {
          //  print("Listen failed: $error");
          }
    );



  }






// reInitializedOrderList(AdminOrder adminOrder){
//
//  lengthOfList = adminOrder.orders!.length;
//  orderList = adminOrder.orders!.reversed.toList();
//
//
//
//
// }



}