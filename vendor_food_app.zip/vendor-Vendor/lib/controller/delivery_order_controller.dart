
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_ringtone_player/flutter_ringtone_player.dart';
import 'package:get/get.dart';
import 'package:inform_us_ventdor/model/shop_order_model.dart';
import 'package:inform_us_ventdor/utils/app_constants.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'auth_controller.dart';


class DeliveryOrderController extends GetxController implements GetxService{
  late SharedPreferences sharedPreferences;
  List<Orders> orderList = [];
  List<String> revenueHistory = [];


  var db = Get.find<AuthController>().db;
  late int lengthOfList ;







  getDeliveryOrdersFromFireStore() async {
    ShopOrderModel shopOrder = ShopOrderModel();

    var dateRef = DateTime.now();


    var day  = dateRef.day.toString();
    var date = day +"-" +dateRef.month.toString()+"-"+ dateRef.year.toString() ;

    String delivery = "delivery";
    String mainCollection = "shopsOrder";
    String shopID = Get.find<AuthController>().vendorShopId;
    String shopName = Get.find<AuthController>().vendorShopName;

    String docId =

        "${shopID}--${shopName
        .toString()
        .capitalize
        .toString()
        .removeAllWhitespace}";









    var docRef = db.collection(mainCollection).doc(docId).collection(day).doc(delivery)

        .withConverter(
      fromFirestore: ShopOrderModel.fromFirestore,
      toFirestore: (ShopOrderModel shopOrderModel, _) => shopOrderModel.toFirestore(),
    );


    docRef.snapshots().listen(
          (event){

             dateRef = DateTime.now();


             day  = dateRef.day.toString();
             date = day +"-" +dateRef.month.toString()+"-"+ dateRef.year.toString() ;

            var docRef = db.collection(mainCollection).doc(docId).collection(day).doc(delivery).withConverter(
              fromFirestore: ShopOrderModel.fromFirestore,
              toFirestore: (ShopOrderModel shopOrderModel, _) => shopOrderModel.toFirestore(),
            );

            if(event.data() != null)
            {
              shopOrder = event.data()!;


            orderList = shopOrder.orders!;


            }
            else{
              Get.snackbar("Error", "Occurred");}

             updateRevenueHistoryList( date, orderList  );
             getRevenueHistoryList();

            update();




            FlutterRingtonePlayer.play(
              android: AndroidSounds.ringtone,
              ios: IosSounds.glass,
              looping: true, // Android only - API >= 28
              volume: 0.1, // Android only - API >= 28
              asAlarm: false, // Android only - all APIs
            );



      } ,


      onError: (error) {
          //  print("Listen failed: $error");
          }

    );



  }

   updateRevenueHistoryList(String date  ,List<Orders> orders) async {
    sharedPreferences = await SharedPreferences.getInstance();
    if(!sharedPreferences.containsKey(date)){
      List<String> tempKey = sharedPreferences.getStringList(AppConstants.revenueListKey)??[];
      tempKey.add(date);
      sharedPreferences.setStringList(AppConstants.revenueListKey, tempKey );
    }

    int totalRevenue = 0;

    orders.forEach((element) {
     totalRevenue =  totalRevenue +  int.parse(element.billS.toString()) ;

    });

    String value = date + "   Total: Rs. " + totalRevenue.toString();
  //  print("Values are"+ value.toString());

    sharedPreferences.setString(date, value);










  }

   getRevenueHistoryList() async {
    sharedPreferences = await SharedPreferences.getInstance();
   List<String> keyList = [];
   List<String> revTempHistory = [];
    keyList =   sharedPreferences.getStringList(AppConstants.revenueListKey)??[];

    keyList.forEach((element) async {

      String tempS = sharedPreferences.getString(element)?? "";
      if(tempS != ""){  revTempHistory.add(tempS) ;}



    });


    revenueHistory = revTempHistory.reversed.toList() ;
    update();
  }

}

