import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:inform_us_ventdor/home_pager.dart';





import 'package:inform_us_ventdor/pages/delivery.dart';
import 'package:inform_us_ventdor/pages/take.dart';
import 'package:inform_us_ventdor/utils/dimensions.dart';

import '../../utils/colors.dart';


class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int _selectedIndex = 0;

  // late PersistentTabController _controller;
  List pages = [


    DeliveryOrders(),
    TakeOrders(),
    OrderHistory()



  ];

  void onTapNav(int index) {
    setState(() {
      _selectedIndex = index;
     // Get.find<AllProductController>().homeIndex = index;
    });
  }



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: pages[_selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
          selectedItemColor: AppColors.mainColor,
          unselectedItemColor: Colors.amberAccent,
          showSelectedLabels: false,
          showUnselectedLabels: false,
          selectedFontSize: 0.0,
          unselectedFontSize: 0.0,
          onTap: onTapNav,
          currentIndex: _selectedIndex,
          items:  [
            BottomNavigationBarItem(
                icon: Icon(
                  Icons.delivery_dining_outlined,size: Dimension.iconSize24*1.5,
                ),
                label: "Home"),
            BottomNavigationBarItem(

                icon: Icon(
                  Icons.takeout_dining_outlined, size: Dimension.iconSize24*1.5,
                ),
                label: "Home"),
            BottomNavigationBarItem(

                icon: Icon(
                  Icons.work_history, size: Dimension.iconSize24*1.5,
                ),
                label: "Home"),


          ]),
    );
  }
}

