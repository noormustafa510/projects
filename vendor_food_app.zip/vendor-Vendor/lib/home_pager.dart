

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:inform_us_ventdor/controller/delivery_order_controller.dart';

import 'package:inform_us_ventdor/utils/colors.dart';
import 'package:inform_us_ventdor/utils/dimensions.dart';
import 'package:inform_us_ventdor/widgets/big_text.dart';
import 'package:inform_us_ventdor/widgets/icon_and_text_widget.dart';

class OrderHistory extends StatelessWidget {
  const OrderHistory({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context)  {
    List<String> list =  Get.find<DeliveryOrderController>().revenueHistory ;


     return Scaffold(
      appBar: AppBar(
        backgroundColor: AppColors.mainColor,

        title: Text("Order Revenue List"),
      ),
      body: list.isEmpty? Center(child: BigText(text: "Your history is empty"),)
          :GetBuilder<DeliveryOrderController>(builder: (controller){

            List<String> test = controller.revenueHistory;



        return Padding(

          padding:  EdgeInsets.only(top: Dimension.height10,),
          child: SingleChildScrollView(
            child: ListView.builder(
                itemCount: list.length,
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemBuilder: (context, index){

              return ListTile(



                title: IconAndTextWidget(icon: Icons.history_toggle_off, text: test[index], iconColor: AppColors.yellowColor,
                iconSize: Dimension.iconSize24*1.2, fontSize: Dimension.font20*1.1,
                ) ,

              );

            }),

          ),
        );
      }),





    );
  }
}


