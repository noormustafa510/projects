package com.informustech.pos.mob.pos_mobile_f_net

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
