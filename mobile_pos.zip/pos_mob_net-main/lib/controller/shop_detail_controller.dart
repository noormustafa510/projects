import 'dart:convert';

import 'package:get/get.dart';
import 'package:pos_mobile_f/controller/panel_controller.dart';
import 'package:pos_mobile_f/main.dart';
import 'package:pos_mobile_f/modal/shop_detail_modal.dart';
import 'package:pos_mobile_f/utils/app_constants.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'admin_panel_controller.dart';

class ShopDetailController extends GetxController implements GetxService{

  AdminPanelController adminPanelController;


  ShopDetailController({required this.adminPanelController});
  late ShopDetailModel shopDetailModel;

   int soundLevel = 5 ;
   bool isNetwork = false;
   bool isDecimal = false;
   String paperSize = '58mm';

  shopDetailsInitialization(){

   // String details =  sharedPreferences.getString(AppConstants.shopDetailPoint)??'';
    String details =  shopDetailPointer.get(0)??'';
    if(details != ''){
      shopDetailModel = ShopDetailModel.fromJson(jsonDecode(details));
    }
    else{
      shopDetailModel = ShopDetailModel(
          shopMoto: "Enter Shop Moto",
          shopAddress: "Enter Shop Address",
          shopPhone: "Enter Shop Phone",
          shopDiscount: 0,
          currency: "Rs.",
          shopTax: 0, copies: 1,kCopies: 0,
        spaces: 0,
        delay: 0,
        soundLevel: 0,
        isNetwork: false,
        isFinalDecimal: false,
        mainIp: '0.0.0.0',
        kIp: '0.0.0.0',
        mainPort: '9100',
        kPort: '9100',
        paperSize: '58mm'

      );
    }

    Get.find<PanelController>().wDiscountEditingController.text = shopDetailModel.shopDiscount.toString();
  }

  saveShopDetail(ShopDetailModel shopDetailModel) async {
    Get.find<PanelController>().wDiscountEditingController.text = shopDetailModel.shopDiscount.toString();
   await shopDetailPointer.put(0, jsonEncode(shopDetailModel));
    //sharedPreferences.setString(AppConstants.shopDetailPoint, jsonEncode(shopDetailModel));

    update();
  }

  setInvoiceNumber() async {
   await invoiceNumberPointer.put(0, 0);
  }

}