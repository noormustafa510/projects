import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pos_mobile_f/main.dart';
import 'package:pos_mobile_f/modal/log_in_modal.dart';

import '../utils/dimensions.dart';

class AdminPanelController extends GetxController implements GetxService{


  AdminPanelController();

  int keyToEditUser = 0;
  int marker = 0;
  late int wrongInputs ;


 bool isAddMode = false;
 bool isEditMode = false;
 bool adminValueForForm = false;
 bool isLogIn = false;
 bool isAdminLogIn = false;
 String logInUserName = '';
 String previousUserName = '';
 TextEditingController userNameEditingController =TextEditingController();
  TextEditingController passwordEditingController =TextEditingController();

  List<LogInModal> userList = [];

 changeAddMode(bool mode){
   isAddMode = mode;
   update();
 }

 saveUser() async {

   if(!checkUserNameRepetition())
   {
     LogInModal sendModal = LogInModal(username: userNameEditingController.text,
         password: passwordEditingController.text,
         isAdmin: adminValueForForm);

   await  usersListPointer.add(jsonEncode(sendModal));

   userNameEditingController.text = '';
   passwordEditingController.text = '';
   adminValueForForm = false;
   initializeUserList();
   changeAddMode(false);
   }

   else{
     Get.snackbar("Restriction", 'Same User Name already exist !',
         backgroundColor: Colors.redAccent , maxWidth: Dimension.width30*22,colorText: Colors.white);


   }

 }

 checkUserNameRepetition(){
 return userList.map((e) => e.username).toList().contains(userNameEditingController.text);
 }

 initializingWrongInputs(){
   wrongInputs = wrongAttemptPointer.get(0)??0;
 }

 initializeUserList() async {
   userList = [];
   if(usersListPointer.keys.isEmpty){
     LogInModal userModal = LogInModal(username: '', password: '', isAdmin: true);

    await usersListPointer.add(jsonEncode(userModal));
     initializeUserList();
   }
   else{
     usersListPointer.keys.forEach((element) {
       LogInModal temModal =LogInModal.fromJson(jsonDecode(usersListPointer.get(element)!));
       userList.add(LogInModal(
           username: temModal.username, password: temModal.password, isAdmin: temModal.isAdmin, key: element));
     });
   }

 }

  changeEditMode(bool mode){
   isEditMode = mode;
   update();
  }

  enterInEditMode(String userName, String password, bool isAdmin, int key){
   userNameEditingController.text = userName;
   previousUserName = userName;
   passwordEditingController.text = password;
   adminValueForForm = isAdmin;
   keyToEditUser = key;
   changeEditMode(true);

  }

  closeEditMode(){
   userNameEditingController.text = '';
   passwordEditingController.text = '';
   adminValueForForm = false;
   changeEditMode(false);
  }

  updateUser() async {
   if(userNameEditingController.text == previousUserName || !checkUserNameRepetition()){
   await  usersListPointer.put(keyToEditUser, jsonEncode(LogInModal
       (username: userNameEditingController.text, password: passwordEditingController.text, isAdmin: adminValueForForm)));
   initializeUserList();
   closeEditMode();


   }
   else{
     Get.snackbar("Restriction", 'Same User Name already exist !',
         backgroundColor: Colors.redAccent , maxWidth: Dimension.width30*22,colorText: Colors.white);

   }

  }

  loggingIn(String userName , String password) async {

   if(checkingCredentials(userName, password)){

     marker = 1;
     update();
   }

   else{
     wrongInputs = wrongAttemptPointer.get(0)  ??0;
     wrongInputs +=1;
     await wrongAttemptPointer.put(0, wrongInputs);
     update();
     Get.snackbar("Authentication Failed", 'You entered wrong password !',
         backgroundColor: Colors.redAccent , maxWidth: Dimension.width30*22,colorText: Colors.white);


   }


  }

  loggingOut(){
   isAdminLogIn = false;
   isLogIn = false;
   logInUserName = '';
   update();
  }

 bool checkingCredentials(String userName, String password){
   for(LogInModal element in userList)  {
      if(element.username == userName && element.password == password){
        isLogIn = true;
        isAdminLogIn = element.isAdmin;
        logInUserName = element.username;
        return true;
      }

    };
    return false;
  }

}