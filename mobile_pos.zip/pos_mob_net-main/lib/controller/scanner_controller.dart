import 'package:flutter/services.dart';
import 'dart:async';

import 'package:flutter_barcode_scanner/flutter_barcode_scanner.dart';
import 'package:flutter_beep/flutter_beep.dart';
import 'package:get/get.dart';
import 'package:get/get_state_manager/src/rx_flutter/rx_disposable.dart';
import 'package:get/get_state_manager/src/simple/get_controllers.dart';
import 'package:vibration/vibration.dart';

class ScannerController extends GetxController implements GetxService{


  String scanBarcode = 'Unknown';
  List<String> barStreams = [];

  delayedFunction() async {
    print("delayed");
   await Future.delayed(Duration(seconds: 10));
  }

  Future<void> startBarcodeScanStream() async {
    barStreams = [];
    FlutterBarcodeScanner.getBarcodeStreamReceiver(
        '#ff6666', 'Cancel', true, ScanMode.BARCODE)!.

    listen( (barcode)   async {







          barStreams.add(barcode);
          FlutterBeep.beep(false);
          Vibration.vibrate();
          print("i am there");
          print(barcode);

          update();












    },  );
  }



  Future<void> scanBarcodeNormal() async {
    await SystemSound.play(SystemSoundType.alert);

    String barcodeScanRes;
    // Platform messages may fail, so we use a try/catch PlatformException.
    try {
      barcodeScanRes = await FlutterBarcodeScanner.scanBarcode(
          '#ff6666', 'Cancel', true, ScanMode.BARCODE);
      print(barcodeScanRes);
      FlutterBeep.beep(false);
      Vibration.vibrate();
      SystemSound.play(SystemSoundType.alert);

      //update();
    } on PlatformException {
      barcodeScanRes = 'Failed to get platform version.';
    }

    // If the widget was removed from the tree while the asynchronous platform
    // message was in flight, we want to discard the reply rather than calling
    // setState to update our non-existent appearance.

    FlutterBeep.beep(false);
    Vibration.vibrate();

      scanBarcode = barcodeScanRes;


    update();

  }
  soundProducer() async {

    bool  status = await Vibration.hasVibrator()?? false;

    if (status) {

    }
  }

}