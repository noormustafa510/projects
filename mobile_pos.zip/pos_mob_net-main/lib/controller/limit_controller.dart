
import 'package:flutter/cupertino.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:get/get.dart';
import 'package:pos_mobile_f/controller/product_controller.dart';
import 'package:pos_mobile_f/modal/product_modal.dart';

import 'admin_panel_controller.dart';

class LimitController extends GetxController implements GetxService {

  ProductController productController ;
  AdminPanelController adminPanelController;

  LimitController({required this.productController, required this.adminPanelController});

  TextEditingController shortProductNameEditingController = TextEditingController();

  List<ProductModal> shortList = [];
  List<ProductModal> searchShortList = [];

  final FlutterLocalNotificationsPlugin _flutterLocalNotificationsPlugin = FlutterLocalNotificationsPlugin();
  final AndroidInitializationSettings _androidInitializationSettings = const AndroidInitializationSettings('logo');

  Future<void> initializeNotification() async {



    InitializationSettings initializationSettings = InitializationSettings(android: _androidInitializationSettings);

   await _flutterLocalNotificationsPlugin.initialize(initializationSettings);

  }

  Future<void> sendNotification (int id, String title, String body) async {

    AndroidNotificationDetails androidNotificationDetails = const AndroidNotificationDetails("posNAIuId", "posNAIuName" , importance: Importance.max, priority: Priority.max);

    NotificationDetails notificationDetails = NotificationDetails(
      android: androidNotificationDetails
    );

    await _flutterLocalNotificationsPlugin.show(id, title, body, notificationDetails);


  }


  initializedShortList(){
    shortList = [];
    for(ProductModal product in productController.productList){
      product.warLimit> product.count ? shortList.add(product) : null;
    }
    searchShortListProducer();
    update();
  }


  searchShortListProducer() {
    String value = shortProductNameEditingController.text;

    searchShortList = [];

    if (value.isNotEmpty) {
      for (var element in shortList) {
        if (element.name
            .toLowerCase()
            .toString()
            .contains(value.toLowerCase().toString())) {
          searchShortList.add(element);
        }
      }
    } else {
      searchShortList = shortList;
    }
  }





}