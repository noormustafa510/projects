import 'package:blue_thermal_printer/blue_thermal_printer.dart';
import 'package:esc_pos_utils/esc_pos_utils.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:pos_mobile_f/modal/product_modal.dart';

import 'admin_panel_controller.dart';
import 'panel_controller.dart';

class BarcodeController extends GetxController implements GetxService{

  PanelController panelController;
  AdminPanelController adminPanelController;

  BarcodeController({ required this.panelController, required this.adminPanelController});
  TextEditingController productNameEditingController = TextEditingController();
  TextEditingController barcodeEditingController = TextEditingController();
  TextEditingController priceEditingController = TextEditingController();
  TextEditingController noOfCopiesEditingController = TextEditingController();


  setterMethodForProduct(String str){

  int index =  panelController.productController.productList.map((e) => e.name).toList().indexOf(str);
    if(index>-1){
      ProductModal product = panelController.productController.productList[index];
      productNameEditingController.text = product.name;
      barcodeEditingController.text = product.code;
      priceEditingController.text = product.price.toString();

      update();

    }
  }

  printModule() async {
    {

      int copies = noOfCopiesEditingController.text.isNum ? int.parse(noOfCopiesEditingController.text):0;


      final profile = await CapabilityProfile.load();
      final generator = Generator(PaperSize.mm58, profile);

      const MethodChannel _channel = MethodChannel('blue/methods');

      List<int> barcodeList = [];

      String barcodeString =  barcodeEditingController.text.isNum? barcodeEditingController.text: '0000000000';

      for(int i= 0 ; i<barcodeString.length ; i++){
        barcodeList.add(int.parse(barcodeString[i]));
      }

      BlueThermalPrinter bluetooth = BlueThermalPrinter.instance;

      final List<int> barData = [1, 2, 3, 4, 5, 6, 7, 8, 9, 0, 4];



      for (int i = 0; i < copies; i++) {
        List<int> bytes = [];


        bytes += generator.text(productNameEditingController.text +'   '+
            panelController.shopDetailController.shopDetailModel.currency+' '+ priceEditingController.text.toString(),
        styles: PosStyles(align: PosAlign.center)
        );

       // bytes += generator.barcode(Barcode.upcA(barcodeList));
        //bytes += generator.barcode(Barcode.upcE(barcodeList));
        // bytes += generator.barcode(Barcode.codabar(barcodeList));
        // bytes += generator.barcode(Barcode.code39(barcodeList));
        // bytes += generator.barcode(Barcode.code128(barcodeList));
       // bytes += generator.barcode(Barcode.ean8(barcodeList));
       //  bytes += generator.barcode(Barcode.ean13(barcodeList));
         bytes += generator.barcode(Barcode.itf(barcodeList));

         

       // bytes +=  generator.barcode(Barcode.upcA(barData));

        bluetooth.writeBytes(Uint8List.fromList(bytes));
        bluetooth.paperCut();
      }
























    }
  }

}