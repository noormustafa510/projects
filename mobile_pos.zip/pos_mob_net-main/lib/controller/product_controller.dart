import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_barcode_scanner/flutter_barcode_scanner.dart';
import 'package:flutter_beep/flutter_beep.dart';
import 'package:get/get.dart';
import 'package:pos_mobile_f/main.dart';
import 'package:pos_mobile_f/modal/category_modal.dart';
import 'package:pos_mobile_f/modal/product_modal.dart';

import '../utils/dimensions.dart';
import 'admin_panel_controller.dart';
import 'limit_controller.dart';

class ProductController extends GetxController implements GetxService {

  AdminPanelController adminPanelController;


  ProductController({required this.adminPanelController });

  bool isEditMode = false;
  bool isAddMode = false;
  bool isAddModeForCat = false;
  bool isAddModeForTable = false;
  bool expirySelectionStatus = false;
  List<CategoryModal> categoriesList = [];
  List<CategoryModal> tableList = [];
  List<ProductModal> productList = [];
  List<ProductModal> searchList = [];
  String restaurantName = '';
  Map<String, List<ProductModal>> productsListByCategory = {};
  List<String> rawItems = [];
  late ProductModal editingProductModal;
  DateTimeRange dateTimeRange =
      DateTimeRange(start: DateTime.now(), end: DateTime(2124));

  TextEditingController nameOfProductEditingController =
      TextEditingController();
  TextEditingController codeOfProductEditingController =
      TextEditingController();
  TextEditingController priceOfProductEditingController =
      TextEditingController();
  TextEditingController costOfProductEditingController =
      TextEditingController();
  TextEditingController itemsInInventoryEditingController =
      TextEditingController();
  TextEditingController limitSetterEditingController = TextEditingController();
  TextEditingController categoryEditingController = TextEditingController();
  TextEditingController tableEditingController = TextEditingController();
  TextEditingController discountEditingController = TextEditingController();
  TextEditingController selectedCategoryEditingController =
      TextEditingController();

  TextEditingController searchEditingController = TextEditingController();
  //TextEditingController expiryOfProduct = TextEditingController();

  modeSetter() {
    isAddMode = !isAddMode;
    update();
  }

  modeSetterForCat() {
    isAddModeForCat = !isAddModeForCat;
    update();
  }

  modeSetterForTable() {
    isAddModeForTable = !isAddModeForTable;
    update();
  }

  saveCategory() async {
    if (categoryEditingController.text != '') {
      if (!categoryNameRepetitionChecker()) {
        categoryBoxPointer
            .add(categoryEditingController.text.capitalize.toString());

        categoryEditingController.text = '';
        await initializingCategoriesList();
        modeSetterForCat();
      } else {
        Get.snackbar("Error", 'Category with same name already exist!',
            backgroundColor: Colors.redAccent,
            maxWidth: Dimension.width30 * 22,
            colorText: Colors.white);
      }
    } else {
      Get.snackbar("Error", 'Text field is empty!',
          backgroundColor: Colors.redAccent,
          maxWidth: Dimension.width30 * 22,
          colorText: Colors.white);
    }
  }

  saveTable() async {
    if (tableEditingController.text != '') {
      if (!tableNameRepetitionChecker()) {
       await  tableBoxPointer.add(tableEditingController.text.capitalize.toString());

        tableEditingController.text = '';
        await initializingTableList();
        modeSetterForTable();
      } else {
        Get.snackbar("Error", 'Table with same name already exist!',
            backgroundColor: Colors.redAccent,
            maxWidth: Dimension.width30 * 22,
            colorText: Colors.white);
      }
    } else {
      Get.snackbar("Error", 'Text field is empty!',
          backgroundColor: Colors.redAccent,
          maxWidth: Dimension.width30 * 22,
          colorText: Colors.white);
    }
  }

  cancelCategory() {
    categoryEditingController.text = '';
    modeSetterForCat();
  }

  cancelTable() {
    tableEditingController.text = '';
    modeSetterForTable();
  }

  initializingCategoriesList() async {
    categoriesList = [];

    print("invoked");
    if (categoryBoxPointer.keys.length > 0) {
      categoriesList = [];

      for (var element in categoryBoxPointer.keys) {
        categoriesList.add(CategoryModal(
            key: int.parse(element.toString()),
            categoryName: categoryBoxPointer.get(element).toString()));
      }



      bool isReIni = false;
      List<String> temListForCat = [];
      for (var element in productList) {
        if(element.category != '' ){

         if(!temListForCat.contains(element.category)){

           if( ! categoriesList.map((e) =>
           e.categoryName).toList().contains(element.category)){
             await categoryBoxPointer.add(element.category);

             temListForCat.add(element.category);
             print("I am category:"+ element.category);

             isReIni = true;
           }
         }



        }
      }
      print("I am tester2");
      if(isReIni){
    categoriesList = [];

    for (var element in categoryBoxPointer.keys) {
    categoriesList.add(CategoryModal(
    key: int.parse(element.toString()),
    categoryName: categoryBoxPointer.get(element).toString()));
    }

    }

    } else {
     await categoryBoxPointer.add('Others');

     await initializingCategoriesList();
    }
  }

  initializingTableList() async {
    tableList = [];

    if (tableBoxPointer.keys.length > 0) {
      tableList = [];

      for (var element in tableBoxPointer.keys) {
        tableList.add(CategoryModal(
            key: int.parse(element.toString()),
            categoryName: tableBoxPointer.get(element).toString()));
      }
    } else {
     await tableBoxPointer.add('Take Away');
     await   tableBoxPointer.add('Home Delivery');

        await      initializingTableList();
    }
  }

  initializingProductList() {
    productList = [];
    if (productBoxPointer.keys.isNotEmpty) {
      for (var element in productBoxPointer.keys) {
        productList.add(
            ProductModal.fromJson(jsonDecode(productBoxPointer.get(element)!))
              ..key = element);
      }
      searchListProducer();
    } else {
      searchList = [];
    }

    Get.find<LimitController>().initializedShortList();


  }



  bool categoryNameRepetitionChecker() {
    return categoriesList
        .map((e) =>
            e.categoryName.capitalize.toString().removeAllWhitespace.toString())
        .toString()
        .contains(categoryEditingController.text.capitalize
            .toString()
            .removeAllWhitespace
            .toString());
  }

  bool tableNameRepetitionChecker() {
    return tableList
        .map((e) =>
            e.categoryName.capitalize.toString().removeAllWhitespace.toString())
        .toString()
        .contains(tableEditingController.text.capitalize
            .toString()
            .removeAllWhitespace
            .toString());
  }

  deleteCategory(int key) async {
    categoryBoxPointer.delete(key);
    await initializingCategoriesList();
    update();
  }

  deleteTable(int key) async {
    tableBoxPointer.delete(key);
    await initializingTableList();
    update();
  }

  dateTimeRangeSetter(DateTimeRange pDateTimeRange) {
    dateTimeRange = pDateTimeRange;
  }

  expirySelectionStatusUpdate(bool status) {
    expirySelectionStatus = status;
    update();
  }

  String dateTimeToString(DateTime dateTime) {
    String date = '';
    date = dateTime.month.toString() +
        '/' +
        dateTime.day.toString() +
        '/' +
        dateTime.year.toString();

    return date;
  }

  int dateTimeToInt(DateTime dateTime) {
    String date = '';
    date = dateTime.year.toString() +
        dateTime.month.toString() +
        dateTime.day.toString();

    return int.parse(date);
  }

  Future<void> scanBarcodeNormal() async {
    String barcodeScanRes;
    // Platform messages may fail, so we use a try/catch PlatformException.
    try {
      barcodeScanRes = await FlutterBarcodeScanner.scanBarcode(
          '#ff6666', 'Cancel', true, ScanMode.BARCODE);
      FlutterBeep.beep(false);
    } on PlatformException {
      barcodeScanRes = 'Failed to get platform version.';
    }

    // If the widget was removed from the tree while the asynchronous platform
    // message was in flight, we want to discard the reply rather than calling
    // setState to update our non-existent appearance.

    codeOfProductEditingController.text = barcodeScanRes;

    update();
  }

  saveProduct() async {
    if (!productNameRepChecker()) {
      if (!productCodeRepChecker()) {
        !priceOfProductEditingController.text.isNum
            ? priceOfProductEditingController.text = '0'
            : null;
        !costOfProductEditingController.text.isNum
            ? costOfProductEditingController.text = '0'
            : null;
        !discountEditingController.text.isNum
            ? discountEditingController.text = '0'
            : null;
        !itemsInInventoryEditingController.text.isNum
            ? itemsInInventoryEditingController.text = '0'
            : null;
        !limitSetterEditingController.text.isNum
            ? limitSetterEditingController.text = '0'
            : null;
        selectedCategoryEditingController.text == ''
            ? selectedCategoryEditingController.text == 'Others'
            : null;
        ProductModal productModal = ProductModal(
            name: nameOfProductEditingController.text,
            code: codeOfProductEditingController.text,
            price: double.parse(priceOfProductEditingController.text),
            cost: double.parse(costOfProductEditingController.text),
            count: double.parse(itemsInInventoryEditingController.text),
            discount: double.parse(discountEditingController.text),
            warLimit: double.parse(limitSetterEditingController.text),
            category: selectedCategoryEditingController.text,
            expiryRange: dateTimeRange.toString(),
            rawItems: rawItems);

        await productBoxPointer.add(jsonEncode(productModal));

        print("object" + jsonEncode(productModal));
        initializingProductList();

        nameOfProductEditingController.text = '';
        codeOfProductEditingController.text = '';
        priceOfProductEditingController.text = '0';
        costOfProductEditingController.text = '0';
        discountEditingController.text = '0';
        itemsInInventoryEditingController.text = '0';
        limitSetterEditingController.text = '0';
        selectedCategoryEditingController.text = 'Others';
        rawItems = [];
        dateTimeRange =
            DateTimeRange(start: DateTime.now(), end: DateTime(2124));

        modeSetter();
      } else {
        Get.snackbar("Error", 'Product with same code already exist!',
            backgroundColor: Colors.redAccent,
            maxWidth: Dimension.width30 * 22,
            colorText: Colors.white);
      }
    } else {
      Get.snackbar("Error", 'Product with same name already exist!',
          backgroundColor: Colors.redAccent,
          maxWidth: Dimension.width30 * 22,
          colorText: Colors.white);
    }
  }

  cancelProduct() {
    modeSetter();
  }

  bool productNameRepChecker() {
    return productList
        .map((e) => e.name.capitalize.toString().removeAllWhitespace.toString())
        .toList()
        .contains(nameOfProductEditingController.text.capitalize
            .toString()
            .removeAllWhitespace
            .toString());
  }

  bool productCodeRepChecker() {
    return productList
        .map((e) => e.code.capitalize.toString().removeAllWhitespace.toString())
        .toList()
        .contains(codeOfProductEditingController.text.capitalize
            .toString()
            .removeAllWhitespace
            .toString());
  }

  priceAndCostUpdater(int index, ProductModal product) async {
   await productBoxPointer.put(index, jsonEncode(product));
    initializingProductList();
    update();
  }

  editModeInit(ProductModal product) {
    editingProductModal = product;
    isEditMode = true;
    nameOfProductEditingController.text = product.name;
    codeOfProductEditingController.text = product.code;
    priceOfProductEditingController.text = product.price.toString();
    costOfProductEditingController.text = product.cost.toString();
    discountEditingController.text = product.discount.toString();
    itemsInInventoryEditingController.text = product.count.toString();
    limitSetterEditingController.text = product.warLimit.toString();
    selectedCategoryEditingController.text =
        product.category == '' ? 'Others' : product.category;
    rawItems = product.rawItems;
    dateTimeRange = DateTimeRange(
        start: DateTime.parse(product.expiryRange
            .substring(0, product.expiryRange.indexOf(' - '))),
        end: DateTime.parse(product.expiryRange
            .substring(product.expiryRange.indexOf(' - ') + 3)));

    update();
  }

  updateProduct() async {
    if (!productNameRepChecker() ||
        nameOfProductEditingController.text.capitalize
                .toString()
                .removeAllWhitespace
                .toString() ==
            editingProductModal.name.capitalize
                .toString()
                .removeAllWhitespace
                .toString()) {
      if (!productCodeRepChecker() ||
          codeOfProductEditingController.text.removeAllWhitespace.toString() ==
              editingProductModal.code.removeAllWhitespace.toString()) {
        !priceOfProductEditingController.text.isNum
            ? priceOfProductEditingController.text = '0'
            : null;
        !costOfProductEditingController.text.isNum
            ? costOfProductEditingController.text = '0'
            : null;
        !discountEditingController.text.isNum
            ? discountEditingController.text = '0'
            : null;
        !itemsInInventoryEditingController.text.isNum
            ? itemsInInventoryEditingController.text = '0'
            : null;

        !limitSetterEditingController.text.isNum
            ? limitSetterEditingController.text = '0'
            : null;
        ProductModal productModal = ProductModal(
            name: nameOfProductEditingController.text,
            code: codeOfProductEditingController.text,
            price: double.parse(priceOfProductEditingController.text),
            cost: double.parse(costOfProductEditingController.text),
            discount: double.parse(discountEditingController.text),
            count: double.parse(itemsInInventoryEditingController.text),
            warLimit: double.parse(limitSetterEditingController.text),
            category: selectedCategoryEditingController.text,
            expiryRange: dateTimeRange.toString(),
            rawItems: rawItems);

      await  productBoxPointer.put(
            editingProductModal.key, jsonEncode(productModal));
        initializingProductList();

        nameOfProductEditingController.text = '';
        codeOfProductEditingController.text = '';
        priceOfProductEditingController.text = '0';
        costOfProductEditingController.text = '0';
        discountEditingController.text = '0';
        itemsInInventoryEditingController.text = '0';
        limitSetterEditingController.text = '0';
        selectedCategoryEditingController.text = 'Others';
        rawItems = [];
        dateTimeRange =
            DateTimeRange(start: DateTime.now(), end: DateTime(2124));

        isEditMode = false;
        update();
      } else {
        Get.snackbar("Error", 'Product with same code already exist!',
            backgroundColor: Colors.redAccent,
            maxWidth: Dimension.width30 * 22,
            colorText: Colors.white);
      }
    } else {
      Get.snackbar("Error", 'Product with same name already exist!',
          backgroundColor: Colors.redAccent,
          maxWidth: Dimension.width30 * 22,
          colorText: Colors.white);
    }
  }

  deleteProduct({int? index}) {
    productBoxPointer.delete(index ?? editingProductModal.key);
    initializingProductList();
    isEditMode = false;
    update();
  }

  cancelUpdateProduct() {
    nameOfProductEditingController.text = '';
    codeOfProductEditingController.text = '';
    priceOfProductEditingController.text = '0';
    costOfProductEditingController.text = '0';
    discountEditingController.text = '0';
    itemsInInventoryEditingController.text = '0';
    limitSetterEditingController.text = '0';
    selectedCategoryEditingController.text = 'Others';
    rawItems = [];
    dateTimeRange = DateTimeRange(start: DateTime.now(), end: DateTime(2124));

    isEditMode = false;
    update();
  }

  searchListProducer() {
    String value = searchEditingController.text;

    searchList = [];

    if (value.length > 0) {
      productList.forEach((element) {
        if (element.name
            .toLowerCase()
            .toString()
            .contains(value.toLowerCase().toString())) {
          searchList.add(element);
        }
      });
    } else {
      searchList = productList;
    }
  }

  productsListByCategoryProducer() {
    productsListByCategory = {};

    for (var element in categoriesList) {
      productsListByCategory[element.categoryName] = [];
    }
    for (var element in productList) {
      if (element.category == '') {
        productsListByCategory['Others']!.add(element);
      } else {
        productsListByCategory[element.category]!.add(element);
      }
    }
  }

  autoGenerateBarCode() async {

    String barcode = lastBarCodeGenPointer.get(0)?? '900000000000';
    List<String> codeList =  productList.map((e) => e.code).toList();

    for(int i=0; i<codeList.length; i++){
      if(codeList[i] == barcode){
        barcode = (int.parse(barcode) +1).toString();
       await lastBarCodeGenPointer.put(0,  barcode);
       i=codeList.length;

       autoGenerateBarCode();
      }
    }
    codeOfProductEditingController.text = barcode;

  }



}
