import 'dart:convert';
import 'dart:io';

import 'package:blue_thermal_printer/blue_thermal_printer.dart';
import 'package:drago_usb_printer/drago_usb_printer.dart';
import 'package:esc_pos_printer/esc_pos_printer.dart';
import 'package:esc_pos_utils/esc_pos_utils.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_barcode_scanner/flutter_barcode_scanner.dart';
import 'package:flutter_beep/flutter_beep.dart';
import 'package:get/get.dart';
import 'package:hive/hive.dart';
import 'package:pos_mobile_f/controller/admin_panel_controller.dart';
import 'package:pos_mobile_f/controller/product_controller.dart';
import 'package:pos_mobile_f/main.dart';
import 'package:pos_mobile_f/modal/discount_model.dart';
import 'package:pos_mobile_f/modal/invoice_modal.dart';
import 'package:pos_mobile_f/modal/product_modal.dart';
import 'package:pos_mobile_f/modal/return_modal.dart';
import 'package:pos_mobile_f/utils/app_constants.dart';
import 'package:pos_mobile_f/utils/constants.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:unique_identifier/unique_identifier.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:vibration/vibration.dart';

import '../utils/dimensions.dart';
import 'limit_controller.dart';
import 'shop_detail_controller.dart';

class PanelController extends GetxController implements GetxService {
  ProductController productController;

  ShopDetailController shopDetailController;
  LimitController limitController;
  AdminPanelController adminPanelController;

  PanelController(
      {required this.productController,
      required this.shopDetailController,
      required this.limitController,
      required this.adminPanelController});

  TextEditingController wDiscountEditingController = TextEditingController();
  TextEditingController remarksEditingController = TextEditingController();
  TextEditingController balanceEditingController = TextEditingController();
  TextEditingController taxEditingController = TextEditingController();
  TextEditingController mainPanelSearchEditingController =
      TextEditingController();

  DragoUsbPrinter dragoUsbPrinter = DragoUsbPrinter();

  bool isSearchEnables = false;
  bool thermalConnection = false;
  bool usbThermalConnection = false;

  bool isAccountActive = false;
  String selectedTableString = 'Take Away';
  String decodedStr = '';
  List<String> tableList = [];
  List<String> barStreams = [];
  List<ReturnModal> returnList = [];
  List<DiscountModel> discountList = [];

  Map<String, int> holdNumber = {};
  Map<String, List<SubProductsModal>> productListMap = {};
  Map<String, RestInvoiceModal> restProductDetailsMap = {};
  Map<String, Map<String, double>> bottomListQuantityMap = {};

  String uniqueId = '';

  String restaurantName = AppConstants.restNameByDefault;

  late String currentDateTimeStr;
  initializeTableList() {
    tableList = productController.tableList.map((e) => e.categoryName).toList();
  }

  initializeCurrentDateTime() {
    currentDateTimeStr = dateTimeIntoString(DateTime.now());
  }

  searchEnablingSetter() {
    isSearchEnables = !isSearchEnables;
    update();
  }

  addHold() {
    if (!selectedTableString.contains('Hold')) {
      if (holdNumber.containsKey(selectedTableString)) {
        holdNumber[selectedTableString] = holdNumber[selectedTableString]! + 1;
      } else {
        holdNumber[selectedTableString] = 1;
      }

      String newTable =
          '$selectedTableString Hold ${holdNumber[selectedTableString]}';
      productListMap[newTable] = productListMap[selectedTableString] ?? [];
      bottomListQuantityMap[newTable] =
          bottomListQuantityMap[selectedTableString] ?? {};
      restProductDetailsMap[newTable] =
          restProductDetailsMap[selectedTableString] ??
              RestInvoiceModal(
                  pSale: 0,
                  wDiscount: wDiscountEditingController.text.isNum
                      ? double.parse(wDiscountEditingController.text)
                      : 0,
                  wTax: shopDetailController.shopDetailModel.shopTax,
                  totalSale: 0,
                  balance: 0);
      productListMap[selectedTableString] = [];
      bottomListQuantityMap[selectedTableString] = {};
      restProductDetailsMap[selectedTableString] = RestInvoiceModal(
          pSale: 0,
          wDiscount: wDiscountEditingController.text.isNum
              ? double.parse(wDiscountEditingController.text)
              : 0,
          wTax: shopDetailController.shopDetailModel.shopTax,
          totalSale: 0,
          balance: 0);

      balanceEditingController.text = '';
      //selectedTableString =newTable;
      tableList.add(newTable);

      update();
    } else {
      Get.snackbar("Restriction", 'Hold can not be further held!',
          backgroundColor: Colors.redAccent,
          maxWidth: Dimension.width30 * 22,
          colorText: Colors.white);
    }
  }

  deleteHolds() {
    for (var element in tableList) {
      if (element.contains("Hold")) {
        productListMap[element] = [];
        restProductDetailsMap.remove(element);
        bottomListQuantityMap[element] = {};
      }
    }
    balanceEditingController.text = '';

    initializeTableList();
    selectedTableString = tableList[0];
    holdNumber = {};
    update();
  }

  addProductFromPopUp(ProductModal productP, bool plus) {
    SubProductsModal subProductsModal;
    if (productListMap[selectedTableString] == null) {
      productListMap[selectedTableString] = [];
    }

    if (productListMap[selectedTableString]!.isNotEmpty) {
      int index = productListMap[selectedTableString]!
          .indexWhere((element) => element.name == productP.name);

      if (index < 0) {
        subProductsModal = SubProductsModal(
            key: productP.key,
            name: productP.name,
            code: productP.code,
            price: productP.price,
            cost: productP.cost,
            discount: productP.discount,
            quantity: plus ? 1 : -1,
            total: totalReturner(
                price: productP.price,
                discount: productP.discount,
                quantity: plus ? 1 : -1));

        productListMap[selectedTableString]!.add(subProductsModal);

        mapQuantitySetter(subProductsModal.name, subProductsModal.quantity);
      } else {
        plus
            ? productListMap[selectedTableString]![index].quantity += 1
            : productListMap[selectedTableString]![index].quantity -= 1;
        SubProductsModal temForTotalProduct =
            productListMap[selectedTableString]![index];
        productListMap[selectedTableString]![index].total = totalReturner(
            price: temForTotalProduct.price,
            discount: temForTotalProduct.discount,
            quantity: temForTotalProduct.quantity);

        mapQuantitySetter(temForTotalProduct.name, temForTotalProduct.quantity);
      }
    } else {
      //productListMap[selectedTableString] = [];
      subProductsModal = SubProductsModal(
          key: productP.key,
          name: productP.name,
          code: productP.code,
          price: productP.price,
          cost: productP.cost,
          discount: productP.discount,
          quantity: plus ? 1 : -1,
          total: totalReturner(
              price: productP.price,
              discount: productP.discount,
              quantity: plus ? 1 : -1));
      productListMap[selectedTableString]!.add(subProductsModal);

      mapQuantitySetter(subProductsModal.name, subProductsModal.quantity);
    }

    restProductDetailSetter(productListMap[selectedTableString]!);

    update();
  }

  addProductFromPopUpKey(ProductModal productP, double quantityP) {
    SubProductsModal subProductsModal;
    if (productListMap[selectedTableString] == null) {
      productListMap[selectedTableString] = [];
    }

    if (productListMap[selectedTableString]!.isNotEmpty) {
      int index = productListMap[selectedTableString]!
          .indexWhere((element) => element.name == productP.name);

      if (index < 0) {
        subProductsModal = SubProductsModal(
            key: productP.key,
            name: productP.name,
            code: productP.code,
            price: productP.price,
            cost: productP.cost,
            discount: productP.discount,
            quantity: quantityP,
            total: totalReturner(
                price: productP.price,
                discount: productP.discount,
                quantity: quantityP));

        productListMap[selectedTableString]!.add(subProductsModal);

        mapQuantitySetter(subProductsModal.name, subProductsModal.quantity);
      } else {
        productListMap[selectedTableString]![index].quantity = quantityP;
        SubProductsModal temForTotalProduct =
            productListMap[selectedTableString]![index];
        productListMap[selectedTableString]![index].total = totalReturner(
            price: temForTotalProduct.price,
            discount: temForTotalProduct.discount,
            quantity: temForTotalProduct.quantity);

        mapQuantitySetter(temForTotalProduct.name, temForTotalProduct.quantity);
      }
    } else {
      //productListMap[selectedTableString] = [];
      subProductsModal = SubProductsModal(
          key: productP.key,
          name: productP.name,
          code: productP.code,
          price: productP.price,
          cost: productP.cost,
          discount: productP.discount,
          quantity: quantityP,
          total: totalReturner(
              price: productP.price,
              discount: productP.discount,
              quantity: quantityP));
      productListMap[selectedTableString]!.add(subProductsModal);

      mapQuantitySetter(subProductsModal.name, subProductsModal.quantity);
    }

    restProductDetailSetter(productListMap[selectedTableString]!);

    update();
  }

  mapQuantitySetter(String name, double quantity) {
    if (bottomListQuantityMap[selectedTableString] == null) {
      bottomListQuantityMap[selectedTableString] = {};
    }
    bottomListQuantityMap[selectedTableString]?[name] = quantity;
  }

  addASProductFromMainList(int index, bool plus) {
    plus
        ? productListMap[selectedTableString]![index].quantity += 1
        : productListMap[selectedTableString]![index].quantity -= 1;
    SubProductsModal tempSubProduct =
        productListMap[selectedTableString]![index];
    productListMap[selectedTableString]![index].total = totalReturner(
        price: tempSubProduct.price,
        discount: tempSubProduct.discount,
        quantity: tempSubProduct.quantity);

    mapQuantitySetter(productListMap[selectedTableString]![index].name,
        productListMap[selectedTableString]![index].quantity);
    restProductDetailSetter(productListMap[selectedTableString]!);
    update();
  }

  addASProductViaKeyFromMainList(int index, double quantity) {
    productListMap[selectedTableString]![index].quantity = quantity;
    SubProductsModal tempSubProduct =
        productListMap[selectedTableString]![index];
    productListMap[selectedTableString]![index].total = totalReturner(
        price: tempSubProduct.price,
        discount: tempSubProduct.discount,
        quantity: tempSubProduct.quantity);
    mapQuantitySetter(productListMap[selectedTableString]![index].name,
        productListMap[selectedTableString]![index].quantity);
    restProductDetailSetter(productListMap[selectedTableString]!);
    update();
  }

  discountASProductViaKeyFromMainList(int index, double discount) {
    productListMap[selectedTableString]![index].discount = discount;
    double quantity = productListMap[selectedTableString]![index].quantity;
    restProductDetailSetter(productListMap[selectedTableString]!);
    addASProductViaKeyFromMainList(index, quantity);
  }

  totalCalculatorForProduct(int index, double total) {
    SubProductsModal subProduct = productListMap[selectedTableString]![index];
    double price = subProduct.price;
    double discount = subProduct.discount;

    double quantity = total / (price * (1 - discount * 0.01));
    addASProductViaKeyFromMainList(index, quantity);
    mapQuantitySetter(productListMap[selectedTableString]![index].name,
        productListMap[selectedTableString]![index].quantity);
  }

  removeItemsFromList(int index) {
    mapQuantitySetter(productListMap[selectedTableString]![index].name, 0);

    productListMap[selectedTableString]!.removeAt(index);
    restProductDetailSetter(productListMap[selectedTableString]!);
    update();
  }

  double totalReturner(
      {required double price,
      required double discount,
      required double quantity}) {
    return price * quantity - (price * 0.01 * discount) * quantity;
  }

  resetHold() {
    productListMap[selectedTableString] = [];
    restProductDetailsMap.remove(selectedTableString);
    bottomListQuantityMap[selectedTableString] = {};

    update();
  }

  resetAll() {
    tableList.forEach((element) {
      productListMap[element] = [];
      restProductDetailsMap.remove(selectedTableString);

      bottomListQuantityMap[element] = {};
    });

    update();
  }

  restProductDetailSetter(List<SubProductsModal> productList) {
    double subTotal = 0;
    double discount = 0;
    double tax = 0;
    double netBill = 0;
    double balance = 0;

    if (wDiscountEditingController.text.isNum) {
      if (double.parse(wDiscountEditingController.text) < 100) {
        discount = double.parse(wDiscountEditingController.text);
      }
    }

    tax = shopDetailController.shopDetailModel.shopTax;

    productList.forEach((element) {
      subTotal += element.total;
    });
    netBill = subTotal;

    netBill = netBill - (discount * 0.01 * netBill);

    netBill = netBill + (tax * 0.01 * netBill);

    if (balanceEditingController.text.isNum) {
      balance = double.parse(balanceEditingController.text) - netBill;
    }

    restProductDetailsMap[selectedTableString] = RestInvoiceModal(
        pSale: subTotal,
        wDiscount: discount,
        wTax: tax,
        totalSale: netBill,
        balance: balance);
  }

  streamScanner() {}

  Future<void> startBarcodeScanStream() async {
    FlutterBarcodeScanner.getBarcodeStreamReceiver(
            '#ff6666', 'Cancel', true, ScanMode.BARCODE)!
        .listen(
      (barcode) async {
        if (barcode.toString().isNum) {
          if (productListMap[selectedTableString] == null) {
            productListMap[selectedTableString] = [];
          }
          for (int i = 0; i < productController.productList.length; i++) {
            ProductModal product = productController.productList[i];
            if (barcode.toString().removeAllWhitespace.toString() ==
                product.code.removeAllWhitespace.toString()) {
              int i = productListMap[selectedTableString]!
                  .map((e) => e.name)
                  .toList()
                  .indexOf(product.name);

              if (i == -1) {
                addProductFromPopUp(product, true);
                FlutterBeep.beep(false);
              } else {
                Vibration.vibrate();
              }

              i = productController.productList.length;
            }
          }
        }
        // FlutterBeep.beep(false);
        //Vibration.vibrate();
        //print("i am there");
        //print(barcode);

        update();
      },
    );
  }

  printModule(bool isPrint) async {

    shopDetailController.shopDetailModel.isFinalDecimal;

    String tb = selectedTableString;
    if (tb.contains(' Hold')) {
      tb = selectedTableString.substring(
          0, selectedTableString.indexOf(' Hold'));
    }
    DateTime cDataTime = DateTime.now();
    String disDate = '${cDataTime.day}-${cDataTime.month}-${cDataTime.year}';
    String disTime = '${cDataTime.hour}:${cDataTime.minute}';
    final profile = await CapabilityProfile.load();
    List profilesList = await CapabilityProfile.getAvailableProfiles();
    print("Profiles Length:" + profilesList.length.toString());
    profilesList.forEach((element) {
      print("Data of Profile:" + element.toString());
    });
    final generator = Generator(
        shopDetailController.shopDetailModel.paperSize == '58mm'
            ? PaperSize.mm58
            : PaperSize.mm80,
        profile);

    const MethodChannel _channel = MethodChannel('blue/methods');

    BlueThermalPrinter bluetooth = BlueThermalPrinter.instance;

    int invoiceNumber = invoiceNumberPointer.get(0) ?? 0;

    await invoiceNumberPointer.put(0, invoiceNumber + 1);
    PaperSize paper = shopDetailController.shopDetailModel.paperSize == '58mm'
        ? PaperSize.mm58
        : PaperSize.mm80;

    final printer = NetworkPrinter(paper, profile);

    if (isPrint) {
      if (isAccountActive) {
        for (int i = 0; i < shopDetailController.shopDetailModel.copies; i++) {
          List<int> bytes = [];
          if (shopDetailController.shopDetailModel.soundLevel > 0) {
            bytes += generator.beep();
          }
          bytes += generator.text(restaurantName,
              styles: const PosStyles(
                height: PosTextSize.size2,
                width: PosTextSize.size2,
                align: PosAlign.center,
              ));
          // bytes += generator.clearStyle();
          bytes += generator.text(shopDetailController.shopDetailModel.shopMoto,
              styles: const PosStyles(align: PosAlign.center));
          bytes += generator.emptyLines(1);
          bytes += generator.text(
              'Address: ${shopDetailController.shopDetailModel.shopAddress}',
              styles: const PosStyles(align: PosAlign.center));
          bytes += generator.text(
              'Ph# ${shopDetailController.shopDetailModel.shopPhone}',
              styles: const PosStyles(align: PosAlign.center));
          bytes += generator.text('D & T: ${disDate} ${disTime}',
              styles: const PosStyles(align: PosAlign.center));
          bytes += generator.text('IN# $invoiceNumber',
              styles: const PosStyles(align: PosAlign.center));

          bytes += generator.text(
              'Cashier: ${adminPanelController.logInUserName} - M: ${tb}',
              styles: const PosStyles(align: PosAlign.center));

          remarksEditingController.text != ''
              ? bytes +=
                  generator.text('Remarks: ${remarksEditingController.text}')
              : null;
          bytes += generator.hr();

          if (productListMap[selectedTableString] == null) {
            productListMap[selectedTableString] = [];
          }

          for (var element in productListMap[selectedTableString]!) {
            bytes += generator.text(element.name, styles: const PosStyles());

            double discout =
                element.discount * 0.01 * element.quantity * element.price;
            String disString =
                discout > 0 ? ' - Disc: ${myDoubleRounder(discout, 2)}' : '';

            bytes += generator.text(
                '${element.quantity < 0 ? " " : ''}${myDoubleRounder(element.price, 2)} x'
                ' ${myDoubleRounder(element.quantity, 3)}$disString = '
                '${myDoubleRounder(element.total, 2)}${element.quantity < 0 ? " " : ''}',
                styles: PosStyles(
                    align: PosAlign.center,
                    reverse: element.quantity < 0 ? true : false));
          }
          bytes += generator.hr();
          var rest = restProductDetailsMap[selectedTableString];
          double discToSend = rest?.wDiscount ?? 0;
          if (rest?.totalSale == null) {
            discToSend = 0;
          } else {
            discToSend = discToSend * rest!.pSale * 0.01;
          }

          bytes += rowGenerator(
              'S. Total  ', myDoubleRounder(rest?.pSale ?? 0, 2), generator);
          bytes += rowGenerator(
              'Disc.  ', myDoubleRounder(discToSend, 2), generator);
          bytes += rowGenerator(
              'Tax%  ', myDoubleRounder(rest?.wTax ?? 0, 2), generator);
          bytes += rowGenerator(
              'Balance  ', myDoubleRounder(rest?.balance ?? 0, 2), generator);
          bytes += generator.hr(ch: '-');

          // bytes += rowGenerator(
          //     'Total', "", generator);

          bytes += generator.text("Total",
              styles: const PosStyles(align: PosAlign.left));

          bytes += generator.text(
            '${shopDetailController.shopDetailModel.currency} ${myDoubleRounder(rest?.totalSale ?? 0, 2)}',
            styles: const PosStyles(
                align: PosAlign.right,
                height: PosTextSize.size3,
                width: PosTextSize.size3),
          );

          bytes += generator.emptyLines(1);

          bytes += generator.hr(ch: '^');
          bytes += generator.text("Software developed By",
              styles: PosStyles(align: PosAlign.center));
          bytes += generator.text("InformUS Technologies",
              styles: PosStyles(align: PosAlign.center));
          bytes += generator.text("WhatsApp# +92-305-4509104",
              styles: PosStyles(align: PosAlign.center));

          bytes += generator.feed(shopDetailController.shopDetailModel.spaces);

        // bytes += generator.feed(4);


          if (thermalConnection) {
            bluetooth.writeBytes(Uint8List.fromList(bytes));

            bluetooth.paperCut();
          }
          if (usbThermalConnection) {
            bytes +=  generator.cut();
            await dragoUsbPrinter.write(Uint8List.fromList(bytes));
          }

          if (shopDetailController.shopDetailModel.isNetwork) {
            final PosPrintResult res = await printer.connect(
                shopDetailController.shopDetailModel.mainIp,
                port: int.parse(shopDetailController.shopDetailModel.mainPort));
            // final PosPrintResult res = await printer.connect("192.168.0.87",
            //                port: 9100);
            ;
            if (res == PosPrintResult.success) {
              mainReceipt(
                  printer,
                  restaurantName,
                  shopDetailController,
                  disTime,
                  disDate,
                  invoiceNumber,
                  adminPanelController,
                  tb,
                  remarksEditingController,
                  productListMap,
                  myDoubleRounder,
                  selectedTableString,
                  restProductDetailsMap);

              printer.disconnect();
            }
          }

          if (i + 1 != shopDetailController.shopDetailModel.copies ||
              shopDetailController.shopDetailModel.kCopies != 0) {
            await Future.delayed(
                Duration(seconds: shopDetailController.shopDetailModel.delay));
          }
        }

        for (int i = 0; i < shopDetailController.shopDetailModel.kCopies; i++) {
          if (shopDetailController.shopDetailModel.isNetwork) {
            final PosPrintResult res = await printer.connect(
                shopDetailController.shopDetailModel.kIp,
                port: int.parse(shopDetailController.shopDetailModel.kPort));
            // final PosPrintResult res = await printer.connect("192.168.0.87",
            //                port: 9100);
            ;
            if (res == PosPrintResult.success) {
              kReceipt(
                  printer,
                  restaurantName,
                  shopDetailController,
                  disTime,
                  disDate,
                  invoiceNumber,
                  adminPanelController,
                  tb,
                  remarksEditingController,
                  productListMap,
                  myDoubleRounder,
                  selectedTableString,
                  restProductDetailsMap);

              printer.disconnect();
            }
          }

          List<int> bytes = [];
          if (shopDetailController.shopDetailModel.soundLevel > 0) {
            bytes += generator.beep();
          }
          bytes += generator.text(restaurantName,
              styles: const PosStyles(
                height: PosTextSize.size2,
                width: PosTextSize.size2,
                align: PosAlign.center,
              ));
          //bytes += generator.clearStyle();

          bytes += generator.emptyLines(1);

          bytes += generator.text('D & T: ${disDate} ${disTime}',
              styles: const PosStyles(align: PosAlign.center));
          bytes += generator.text('IN# $invoiceNumber',
              styles: const PosStyles(
                  align: PosAlign.center,
                  height: PosTextSize.size2,
                  width: PosTextSize.size2));

          bytes += generator.text(
              'Cashier: ${adminPanelController.logInUserName} - M: ${tb}',
              styles: const PosStyles(align: PosAlign.center));
          remarksEditingController.text != ''
              ? bytes +=
                  generator.text('Remarks: ${remarksEditingController.text}')
              : null;
          bytes += generator.hr();

          if (productListMap[selectedTableString] == null) {
            productListMap[selectedTableString] = [];
          }

          for (var element in productListMap[selectedTableString]!) {
            bytes += generator.text(element.name, styles: const PosStyles());

            bytes += generator.text(
                '${element.quantity < 0 ? " " : ''}${myDoubleRounder(element.price, 2)} x'
                ' ${myDoubleRounder(element.quantity, 3)}',
                styles: PosStyles(
                    align: PosAlign.center,
                    reverse: element.quantity < 0 ? true : false));
          }

          if (shopDetailController.shopDetailModel.copies == 0) {
            bytes += generator.emptyLines(1);

            bytes += generator.hr(ch: '^');
            bytes += generator.text("Software developed By",
                styles: PosStyles(align: PosAlign.center));
            bytes += generator.text("InformUS Technologies",
                styles: PosStyles(align: PosAlign.center));
            bytes += generator.text("WhatsApp# +92-305-4509104",
                styles: PosStyles(align: PosAlign.center));
          }

          bytes += generator.feed(shopDetailController.shopDetailModel.spaces);


          if (thermalConnection) {
            bluetooth.writeBytes(Uint8List.fromList(bytes));

            bluetooth.paperCut();
          }

          if (usbThermalConnection) {
            bytes +=  generator.cut();
            await dragoUsbPrinter.write(Uint8List.fromList(bytes));
          }
          if (i + 1 != shopDetailController.shopDetailModel.kCopies)
            await Future.delayed(
                Duration(seconds: shopDetailController.shopDetailModel.delay));
        }
      } else {
        if (shopDetailController.shopDetailModel.isNetwork) {
          final PosPrintResult res = await printer.connect(
              shopDetailController.shopDetailModel.mainIp,
              port: int.parse(shopDetailController.shopDetailModel.mainPort));
          // final PosPrintResult res = await printer.connect("192.168.0.87",
          //                port: 9100);
              ;
          if (res == PosPrintResult.success) {
         nonActiveReceipt(printer);

            printer.disconnect();
          }
        }
        List<int> bytes = [];
        bytes += generator.emptyLines(1);

        bytes += generator.text("Non. Active",
            styles: const PosStyles(
                align: PosAlign.center,
                height: PosTextSize.size2,
                width: PosTextSize.size2));
        bytes += generator.text("Demo Account",
            styles: const PosStyles(
                align: PosAlign.center,
                height: PosTextSize.size1,
                width: PosTextSize.size1));
        bytes += generator.emptyLines(2);
        bytes += generator.text("+92-305-4509104",
            styles: const PosStyles(align: PosAlign.center));

        bytes += generator.text("Contact on WhatsApp to",
            styles: const PosStyles(align: PosAlign.center));

        bytes += generator.text("active account!",
            styles: const PosStyles(align: PosAlign.center));

        bytes += generator.emptyLines(1);

        bytes += generator.text("0305-4509104",
            styles: const PosStyles(align: PosAlign.center));

        bytes += generator.text("Is account ko active krne ke",
            styles: const PosStyles(align: PosAlign.center));
        bytes += generator.text("liye WhatsApp pe rabta kre!",
            styles: const PosStyles(align: PosAlign.center));

        bytes += generator.emptyLines(1);

        bytes += generator.hr(ch: '^');
        bytes += generator.text("Software developed By",
            styles: PosStyles(align: PosAlign.center));
        bytes += generator.text("InformUS Technologies",
            styles: PosStyles(align: PosAlign.center));
        bytes += generator.text("WhatsApp# +92-305-4509104",
            styles: PosStyles(align: PosAlign.center));

        if (thermalConnection) {
          bluetooth.writeBytes(Uint8List.fromList(bytes));

          bluetooth.paperCut();
        }
        if (usbThermalConnection) {
          bytes +=  generator.cut();
          await dragoUsbPrinter.write(Uint8List.fromList(bytes));
        }
      }
    }

    await boxOpenerForCurrentDate();

    MainInvoice tempMainInvoice = MainInvoice(
        subProductsList: productListMap[selectedTableString] ?? [],
        restInvoice: restProductDetailsMap[selectedTableString] ??
            RestInvoiceModal(
                pSale: 0, wDiscount: 0, wTax: 0, totalSale: 0, balance: 0),
        remarks: remarksEditingController.text,
        invoiceNumber: invoiceNumber.toString() + ' - ' + disTime,
        date: disDate,
        cashier: adminPanelController.logInUserName,
        tb: tb);

    String tempSave = jsonEncode(tempMainInvoice);

    await saleSaveBoxPointer.add(tempSave);

    balanceEditingController.text = '';

    double sale = saleTotalListPointer.get(currentDateTimeStr) ?? 0;

    sale += tempMainInvoice.restInvoice.totalSale;

    await saleTotalListPointer.put(currentDateTimeStr, sale);
    await inventoryUpdater(tempMainInvoice, disTime, disDate, invoiceNumber);

    if (tempMainInvoice.restInvoice.wDiscount != 0) {
      DiscountModel discountOModel = DiscountModel(
          invoiceNumberAndTime: tempMainInvoice.invoiceNumber,
          date: tempMainInvoice.date,
          itemName: "Over All",
          quantity: 0,
          remainingQuantity: 0,
          discount: tempMainInvoice.restInvoice.wDiscount,
          price: tempMainInvoice.restInvoice.totalSale,
          cost: tempMainInvoice.restInvoice.pSale);

      await discountDataPointer.add(jsonEncode(discountOModel));
    }

    resetHold();
    print("Usb Status:" + usbThermalConnection.toString());
  }
  printKPlusModule(bool isPrint) async {

    String tb = selectedTableString;
    if (tb.contains(' Hold')) {
      tb = selectedTableString.substring(
          0, selectedTableString.indexOf(' Hold'));
    }
    DateTime cDataTime = DateTime.now();
    String disDate = '${cDataTime.day}-${cDataTime.month}-${cDataTime.year}';
    String disTime = '${cDataTime.hour}:${cDataTime.minute}';
    final profile = await CapabilityProfile.load();
    List profilesList = await CapabilityProfile.getAvailableProfiles();
    print("Profiles Length:" + profilesList.length.toString());
    profilesList.forEach((element) {
      print("Data of Profile:" + element.toString());
    });
    final generator = Generator(
        shopDetailController.shopDetailModel.paperSize == '58mm'
            ? PaperSize.mm58
            : PaperSize.mm80,
        profile);

    const MethodChannel _channel = MethodChannel('blue/methods');

    BlueThermalPrinter bluetooth = BlueThermalPrinter.instance;

    int invoiceNumber = invoiceNumberPointer.get(0) ?? 0;

    await invoiceNumberPointer.put(0, invoiceNumber + 1);
    PaperSize paper = shopDetailController.shopDetailModel.paperSize == '58mm'
        ? PaperSize.mm58
        : PaperSize.mm80;

    final printer = NetworkPrinter(paper, profile);

    if (isPrint) {
      if (isAccountActive) {
        for (int i = 0; i < shopDetailController.shopDetailModel.copies; i++) {
          List<int> bytes = [];
          if (shopDetailController.shopDetailModel.soundLevel > 0) {
            bytes += generator.beep();
          }
          bytes += generator.text(restaurantName,
              styles: const PosStyles(
                height: PosTextSize.size2,
                width: PosTextSize.size2,
                align: PosAlign.center,
              ));
          // bytes += generator.clearStyle();
          bytes += generator.text(shopDetailController.shopDetailModel.shopMoto,
              styles: const PosStyles(align: PosAlign.center));
          bytes += generator.emptyLines(1);
          bytes += generator.text(
              'Address: ${shopDetailController.shopDetailModel.shopAddress}',
              styles: const PosStyles(align: PosAlign.center));
          bytes += generator.text(
              'Ph# ${shopDetailController.shopDetailModel.shopPhone}',
              styles: const PosStyles(align: PosAlign.center));
          bytes += generator.text('D & T: ${disDate} ${disTime}',
              styles: const PosStyles(align: PosAlign.center));
          bytes += generator.text('IN# $invoiceNumber',
              styles: const PosStyles(align: PosAlign.center));

          bytes += generator.text(
              'Cashier: ${adminPanelController.logInUserName} - M: ${tb}',
              styles: const PosStyles(align: PosAlign.center));

          remarksEditingController.text != ''
              ? bytes +=
              generator.text('Remarks: ${remarksEditingController.text}')
              : null;
          bytes += generator.hr();

          if (productListMap[selectedTableString] == null) {
            productListMap[selectedTableString] = [];
          }

          for (var element in productListMap[selectedTableString]!) {
            bytes += generator.text(element.name, styles: const PosStyles());

            double discout =
                element.discount * 0.01 * element.quantity * element.price;
            String disString =
            discout > 0 ? ' - Disc: ${myDoubleRounder(discout, 2)}' : '';

            bytes += generator.text(
                '${element.quantity < 0 ? " " : ''}${myDoubleRounder(element.price, 2)} x'
                    ' ${myDoubleRounder(element.quantity, 3)}$disString = '
                    '${myDoubleRounder(element.total, 2)}${element.quantity < 0 ? " " : ''}',
                styles: PosStyles(
                    align: PosAlign.center,
                    reverse: element.quantity < 0 ? true : false));
          }
          bytes += generator.hr();
          var rest = restProductDetailsMap[selectedTableString];
          double discToSend = rest?.wDiscount ?? 0;
          if (rest?.totalSale == null) {
            discToSend = 0;
          } else {
            discToSend = discToSend * rest!.pSale * 0.01;
          }

          bytes += rowGenerator(
              'S. Total  ', myDoubleRounder(rest?.pSale ?? 0, 2), generator);
          bytes += rowGenerator(
              'Disc.  ', myDoubleRounder(discToSend, 2), generator);
          bytes += rowGenerator(
              'Tax%  ', myDoubleRounder(rest?.wTax ?? 0, 2), generator);
          bytes += rowGenerator(
              'Balance  ', myDoubleRounder(rest?.balance ?? 0, 2), generator);
          bytes += generator.hr(ch: '-');

          // bytes += rowGenerator(
          //     'Total', "", generator);

          bytes += generator.text("Total",
              styles: const PosStyles(align: PosAlign.left));

          bytes += generator.text(
            '${shopDetailController.shopDetailModel.currency} ${myDoubleRounder(rest?.totalSale ?? 0, 2)}',
            styles: const PosStyles(
                align: PosAlign.right,
                height: PosTextSize.size3,
                width: PosTextSize.size3),
          );

          bytes += generator.emptyLines(1);

          bytes += generator.hr(ch: '^');
          bytes += generator.text("Software developed By",
              styles: PosStyles(align: PosAlign.center));
          bytes += generator.text("InformUS Technologies",
              styles: PosStyles(align: PosAlign.center));
          bytes += generator.text("WhatsApp# +92-305-4509104",
              styles: PosStyles(align: PosAlign.center));

          bytes += generator.feed(shopDetailController.shopDetailModel.spaces);

          // bytes += generator.feed(4);


          if (thermalConnection) {
            bluetooth.writeBytes(Uint8List.fromList(bytes));

            bluetooth.paperCut();
          }
          if (usbThermalConnection) {
            bytes +=  generator.cut();
            await dragoUsbPrinter.write(Uint8List.fromList(bytes));
          }

          if (shopDetailController.shopDetailModel.isNetwork) {
            final PosPrintResult res = await printer.connect(
                shopDetailController.shopDetailModel.mainIp,
                port: int.parse(shopDetailController.shopDetailModel.mainPort));
            // final PosPrintResult res = await printer.connect("192.168.0.87",
            //                port: 9100);
                ;
            if (res == PosPrintResult.success) {
              mainReceipt(
                  printer,
                  restaurantName,
                  shopDetailController,
                  disTime,
                  disDate,
                  invoiceNumber,
                  adminPanelController,
                  tb,
                  remarksEditingController,
                  productListMap,
                  myDoubleRounder,
                  selectedTableString,
                  restProductDetailsMap);

              printer.disconnect();
            }
          }

          if (i + 1 != shopDetailController.shopDetailModel.copies ||
              shopDetailController.shopDetailModel.kCopies != 0) {
            await Future.delayed(
                Duration(seconds: shopDetailController.shopDetailModel.delay));
          }
        }

        for (int i = 0; i < 1; i++) {
          if (shopDetailController.shopDetailModel.isNetwork) {
            final PosPrintResult res = await printer.connect(
                shopDetailController.shopDetailModel.kIp,
                port: int.parse(shopDetailController.shopDetailModel.kPort));
            // final PosPrintResult res = await printer.connect("192.168.0.87",
            //                port: 9100);
                ;
            if (res == PosPrintResult.success) {
              kReceipt(
                  printer,
                  restaurantName,
                  shopDetailController,
                  disTime,
                  disDate,
                  invoiceNumber,
                  adminPanelController,
                  tb,
                  remarksEditingController,
                  productListMap,
                  myDoubleRounder,
                  selectedTableString,
                  restProductDetailsMap);

              printer.disconnect();
            }
          }

          List<int> bytes = [];
          if (shopDetailController.shopDetailModel.soundLevel > 0) {
            bytes += generator.beep();
          }
          bytes += generator.text(restaurantName,
              styles: const PosStyles(
                height: PosTextSize.size2,
                width: PosTextSize.size2,
                align: PosAlign.center,
              ));
          //bytes += generator.clearStyle();

          bytes += generator.emptyLines(1);

          bytes += generator.text('D & T: ${disDate} ${disTime}',
              styles: const PosStyles(align: PosAlign.center));
          bytes += generator.text('IN# $invoiceNumber',
              styles: const PosStyles(
                  align: PosAlign.center,
                  height: PosTextSize.size2,
                  width: PosTextSize.size2));

          bytes += generator.text(
              'Cashier: ${adminPanelController.logInUserName} - M: ${tb}',
              styles: const PosStyles(align: PosAlign.center));
          remarksEditingController.text != ''
              ? bytes +=
              generator.text('Remarks: ${remarksEditingController.text}')
              : null;
          bytes += generator.hr();

          if (productListMap[selectedTableString] == null) {
            productListMap[selectedTableString] = [];
          }

          for (var element in productListMap[selectedTableString]!) {
            bytes += generator.text(element.name, styles: const PosStyles());

            bytes += generator.text(
                '${element.quantity < 0 ? " " : ''}${myDoubleRounder(element.price, 2)} x'
                    ' ${myDoubleRounder(element.quantity, 3)}',
                styles: PosStyles(
                    align: PosAlign.center,
                    reverse: element.quantity < 0 ? true : false));
          }

          if (shopDetailController.shopDetailModel.copies == 0) {
            bytes += generator.emptyLines(1);

            bytes += generator.hr(ch: '^');
            bytes += generator.text("Software developed By",
                styles: PosStyles(align: PosAlign.center));
            bytes += generator.text("InformUS Technologies",
                styles: PosStyles(align: PosAlign.center));
            bytes += generator.text("WhatsApp# +92-305-4509104",
                styles: PosStyles(align: PosAlign.center));
          }

          bytes += generator.feed(shopDetailController.shopDetailModel.spaces);


          if (thermalConnection) {
            bluetooth.writeBytes(Uint8List.fromList(bytes));

            bluetooth.paperCut();
          }

          if (usbThermalConnection) {
            bytes +=  generator.cut();
            await dragoUsbPrinter.write(Uint8List.fromList(bytes));
          }
          if (i + 1 != shopDetailController.shopDetailModel.kCopies)
            await Future.delayed(
                Duration(seconds: shopDetailController.shopDetailModel.delay));
        }
      } else {
        if (shopDetailController.shopDetailModel.isNetwork) {
          final PosPrintResult res = await printer.connect(
              shopDetailController.shopDetailModel.mainIp,
              port: int.parse(shopDetailController.shopDetailModel.mainPort));
          // final PosPrintResult res = await printer.connect("192.168.0.87",
          //                port: 9100);
              ;
          if (res == PosPrintResult.success) {
            nonActiveReceipt(printer);

            printer.disconnect();
          }
        }
        List<int> bytes = [];
        bytes += generator.emptyLines(1);

        bytes += generator.text("Non. Active",
            styles: const PosStyles(
                align: PosAlign.center,
                height: PosTextSize.size2,
                width: PosTextSize.size2));
        bytes += generator.text("Demo Account",
            styles: const PosStyles(
                align: PosAlign.center,
                height: PosTextSize.size1,
                width: PosTextSize.size1));
        bytes += generator.emptyLines(2);
        bytes += generator.text("+92-305-4509104",
            styles: const PosStyles(align: PosAlign.center));

        bytes += generator.text("Contact on WhatsApp to",
            styles: const PosStyles(align: PosAlign.center));

        bytes += generator.text("active account!",
            styles: const PosStyles(align: PosAlign.center));

        bytes += generator.emptyLines(1);

        bytes += generator.text("0305-4509104",
            styles: const PosStyles(align: PosAlign.center));

        bytes += generator.text("Is account ko active krne ke",
            styles: const PosStyles(align: PosAlign.center));
        bytes += generator.text("liye WhatsApp pe rabta kre!",
            styles: const PosStyles(align: PosAlign.center));

        bytes += generator.emptyLines(1);

        bytes += generator.hr(ch: '^');
        bytes += generator.text("Software developed By",
            styles: PosStyles(align: PosAlign.center));
        bytes += generator.text("InformUS Technologies",
            styles: PosStyles(align: PosAlign.center));
        bytes += generator.text("WhatsApp# +92-305-4509104",
            styles: PosStyles(align: PosAlign.center));

        if (thermalConnection) {
          bluetooth.writeBytes(Uint8List.fromList(bytes));

          bluetooth.paperCut();
        }
        if (usbThermalConnection) {
          bytes +=  generator.cut();
          await dragoUsbPrinter.write(Uint8List.fromList(bytes));
        }
      }
    }

    await boxOpenerForCurrentDate();

    MainInvoice tempMainInvoice = MainInvoice(
        subProductsList: productListMap[selectedTableString] ?? [],
        restInvoice: restProductDetailsMap[selectedTableString] ??
            RestInvoiceModal(
                pSale: 0, wDiscount: 0, wTax: 0, totalSale: 0, balance: 0),
        remarks: remarksEditingController.text,
        invoiceNumber: invoiceNumber.toString() + ' - ' + disTime,
        date: disDate,
        cashier: adminPanelController.logInUserName,
        tb: tb);

    String tempSave = jsonEncode(tempMainInvoice);

    await saleSaveBoxPointer.add(tempSave);

    balanceEditingController.text = '';

    double sale = saleTotalListPointer.get(currentDateTimeStr) ?? 0;

    sale += tempMainInvoice.restInvoice.totalSale;

    await saleTotalListPointer.put(currentDateTimeStr, sale);
    await inventoryUpdater(tempMainInvoice, disTime, disDate, invoiceNumber);

    if (tempMainInvoice.restInvoice.wDiscount != 0) {
      DiscountModel discountOModel = DiscountModel(
          invoiceNumberAndTime: tempMainInvoice.invoiceNumber,
          date: tempMainInvoice.date,
          itemName: "Over All",
          quantity: 0,
          remainingQuantity: 0,
          discount: tempMainInvoice.restInvoice.wDiscount,
          price: tempMainInvoice.restInvoice.totalSale,
          cost: tempMainInvoice.restInvoice.pSale);

      await discountDataPointer.add(jsonEncode(discountOModel));
    }

    resetHold();
    print("Usb Status:" + usbThermalConnection.toString());
  }

  inventoryUpdater(MainInvoice mainInvoice, String disTime, String disDate,
      int invoiceNumber) async {
    for (SubProductsModal element in mainInvoice.subProductsList) {
      String productRaw = productBoxPointer.get(element.key) ?? '';

      if (productRaw != '') {
        bool toSend = true;
        ProductModal product = ProductModal.fromJson(jsonDecode(productRaw));
        if (product.count < product.warLimit) {
          toSend = false;
        }
        product.count -= element.quantity;
        if (element.quantity < 0) {
          ReturnModal returnModal = ReturnModal(
              invoiceNumberAndTime: invoiceNumber.toString() + '-' + disTime,
              date: disDate,
              itemName: element.name,
              quantity: element.quantity,
              remainingQuantity: product.count,
              remarks: remarksEditingController.text,
              discount: element.discount,
              price: element.price,
              cost: element.cost);
          await returnDataPointer.add(jsonEncode(returnModal));
          print("Key:" + returnDataPointer.length.toString());
        }

        if (element.discount != 0) {
          DiscountModel discountModel = DiscountModel(
              invoiceNumberAndTime: invoiceNumber.toString() + '-' + disTime,
              date: disDate,
              itemName: element.name,
              quantity: element.quantity,
              remainingQuantity: product.count,
              discount: element.discount,
              price: element.total,
              cost: element.price * element.quantity);

          await discountDataPointer.add(jsonEncode(discountModel));
        }

        if (toSend == true) {
          product.count < product.warLimit ? toSend = true : toSend = false;
        }
        if (toSend) {
          int id = product.key ?? 9999999;
          await limitController.sendNotification(id, product.name,
              "This product is below set limit ${product.warLimit}");
        }

        await productBoxPointer.put(element.key, jsonEncode(product));

        if (product.rawItems.isNotEmpty) {
          for (String rawString in product.rawItems) {
            int index = productController.productList
                .map((e) => e.name)
                .toList()
                .indexOf(rawString);
            if (index > -1) {
              int key = productController.productList[index].key ?? 99999999999;
              if (key != 99999999999) {
                String productSubRaw = productBoxPointer.get(key) ?? '';
                if (productSubRaw != '') {
                  bool toSubSend = true;
                  ProductModal subProduct =
                      ProductModal.fromJson(jsonDecode(productSubRaw));
                  if (subProduct.count < subProduct.warLimit) {
                    toSubSend = false;
                  }
                  subProduct.count -= element.quantity;

                  if (toSubSend == true) {
                    subProduct.count < subProduct.warLimit
                        ? toSubSend = true
                        : toSubSend = false;
                  }
                  if (toSubSend) {
                    int id = subProduct.key ?? 9999999;
                    await limitController.sendNotification(id, subProduct.name,
                        "This product is below set limit ${subProduct.warLimit}");
                  }

                  await productBoxPointer.put(key, jsonEncode(subProduct));
                }
              }
            }
          }
        }
      }
    }
    productController.initializingProductList();
  }

  String myDoubleRounder(double number, int rounder) {
    String str = number.toStringAsFixed(rounder);

    if (!shopDetailController.shopDetailModel.isFinalDecimal){
      print("String: " + str);
      int temp = double.parse(str).toInt();
      str = temp.toString();
    }
    if (str == '0') return '0';
    if (str.endsWith('.0')) return str.substring(0, str.length - 2);
    if (str.endsWith('.00')) return str.substring(0, str.length - 3);
    if (str.endsWith('.000')) return str.substring(0, str.length - 4);

    return str;
  }

  rowGenerator(String str1, String str2, generator) {
    return generator.row([
      PosColumn(
        text: '',
        width: 2,
        styles: PosStyles(align: PosAlign.center, underline: true),
      ),
      PosColumn(
        text: str1,
        width: 4,
        styles: PosStyles(
          align: PosAlign.right,
        ),
      ),
      PosColumn(
        text: str2,
        width: 6,
        styles: PosStyles(align: PosAlign.right, underline: true),
      ),
    ]);
  }

  Future<void> uniqueIdGenerator() async {
    try {
      uniqueId = (await UniqueIdentifier.serial)!;
    } on PlatformException {
      uniqueId = 'Failed to get Unique Identifier';
    }

    update();
  }

  Future<void> goToWhatsApp(String message) async {
    var contact = "+923054509104";
    var androidUrl = "whatsapp://send?phone=$contact&text=$message";
    var iosUrl = "https://wa.me/$contact?text=${Uri.parse(message)}";

    try {
      if (Platform.isAndroid) {
        await launchUrl(Uri.parse(androidUrl));
      } else {
        await launchUrl(Uri.parse(iosUrl));
      }
    } on Exception {
      //EasyLoading.showError('WhatsApp is not installed.');
    }
  }

  myDecoder(String paraIdAndName) async {
    DateTime decoderDateTime = DateTime.now();
    String restaurantNameAndIdCoded = paraIdAndName;
    String newTempString = '';
    int triedLimit = 0;
    if (triedLimitPointer.get(0) == null) {
      await triedLimitPointer.put(0, 0);
      // sharedPreferences.setInt(AppConstants.triedLimits, 0);
    } else {
      triedLimit = triedLimitPointer.get(0) ?? 0;
    }

    bool isContainSpace = false;

    for (int i = 0; i < restaurantNameAndIdCoded.length; i++) {
      if (restaurantNameAndIdCoded[i] == ' ') {
        isContainSpace = true;
        i = restaurantNameAndIdCoded.length;
      }
    }

    if (restaurantNameAndIdCoded.length.remainder(4) == 0 &&
        triedLimit < 50 &&
        !isContainSpace) {
      for (int i = 0; i < restaurantNameAndIdCoded.length; i++) {
        newTempString += restaurantNameAndIdCoded[i].isNum
            ? deCodingScheme[int.parse(restaurantNameAndIdCoded[i])].toString()
            : restaurantNameAndIdCoded[i];
      }

      decodedStr = newTempString;

      decodedStr = myBase64Conversion(decodedStr, -5);

      newTempString = '';
      for (int i = 0; i < decodedStr.length; i++) {
        newTempString += decodedStr[i].isNum
            ? deCodingScheme[int.parse(decodedStr[i])].toString()
            : decodedStr[i];
      }

      decodedStr = newTempString;

      int n1Length = decodedStr.substring(0, 2).isNum
          ? int.parse(decodedStr.substring(0, 2))
          : 0;
      int n2Length = decodedStr.substring(2, 4).isNum
          ? int.parse(decodedStr.substring(2, 4))
          : 0;
      int year = decodedStr.substring(4, 8).isNum
          ? int.parse(decodedStr.substring(4, 8))
          : 0;
      int month = decodedStr.substring(8, 12).isNum
          ? int.parse(decodedStr.substring(8, 12))
          : 0;

      if (n1Length != 0 && n2Length != 0 && year != 0 && month != 0) {
        int restNameEncodingNumber =
            year + 100000 - month * n1Length - n2Length - 19;

        decodedStr = decodedStr.substring(12);

        decodedStr =
            myBase64Conversion(decodedStr, -1 * restNameEncodingNumber);
        String id = decodedStr.substring(0, n1Length);
        String resName = decodedStr.substring(n1Length, n1Length + n2Length);
        String tempResName = '';
        for (int i = 0; i < resName.length; i++) {
          tempResName += resName[i] == '/' ? ' ' : resName[i];
        }
        resName = tempResName;

        String comMonthYear = year + month < 10 ? '0$month' : month.toString();
        int pMonth = usedMonthPointer.get(0)!;
        int pYear = usedYearPointer.get(0)!;

        String pYearMonth =
            pYear.toString() + (pMonth < 10 ? '0$pMonth' : pMonth.toString());

        int.parse(comMonthYear) >= int.parse(pYearMonth)
            ? null
            : pYearMonth = '0';

        //success if
        if (id == uniqueId && pYearMonth == '0') {
          //success block

          //id assignment
          await resIdBoxPointer.put(0, id);

          //name assignment

          await resNameBoxPointer.put(0, resName);

          String monthToSet = month > 9 ? month.toString() : '0$month';
          String setDateTimeForHiveBox = year.toString() + monthToSet;

          await setDateTimeBoxPointer.put(0, setDateTimeForHiveBox);

          restaurantName = resName;
          await triedLimitPointer.put(0, 0);
          accountActivityChecker();
        } else {
          await onFailureMethod();
        }
      } else {
        // lenths are zero

        await onFailureMethod();
      }
    } else {
      print("tried value:" + triedLimit.toString());
      // length is not multiple of 4
      await onFailureMethod();
    }

    update();
  }

  myBase64Conversion(String str, int number) {
    Uint8List strU8 = base64Decode(str);

    List<int> codeIntList = [];

    for (int i = 0; i < strU8.length; i++) {
      int tempInt = number * i;

      codeIntList.add(strU8[i] + tempInt);
    }
    strU8 = Uint8List.fromList(codeIntList);

    return base64Encode(strU8);
  }

  initializingUsedMonthAndYear() async {
    DateTime dateTime = DateTime.now();

    if (usedMonthPointer.get(0) != null) {
      int tMonth = usedMonthPointer.get(0)!;
      tMonth <= dateTime.month ? null : await usedMonthPointer.put(0, 12);
    } else {
      await usedMonthPointer.put(0, dateTime.month);
    }

    if (usedYearPointer.get(0) != null) {
      int tYear = usedYearPointer.get(0)!;
      tYear <= dateTime.year ? null : await usedYearPointer.put(0, 3030);
    } else {
      await usedYearPointer.put(0, dateTime.year);
    }
  }

  onFailureMethod() async {
    int triedAttempts = triedLimitPointer.get(0) ?? 0;

    triedAttempts += 1;
    await triedLimitPointer.put(0, triedAttempts);
    //sharedPreferences.setInt(AppConstants.triedLimits, triedAttemps);
    Get.snackbar("Failed", 'You entered wrong passcode',
        backgroundColor: Colors.red,
        maxWidth: Dimension.width30 * 22,
        colorText: Colors.white);
    print("tried value1:" + triedAttempts.toString());
  }

  initializingRestaurantName() async {
    if (resNameBoxPointer.keys.isNotEmpty) {
      restaurantName = resNameBoxPointer.get(0).toString();
    }
    await uniqueIdGenerator();

    if (resIdBoxPointer.keys.isEmpty) {
      restaurantName = AppConstants.restNameByDefault;
      await resIdBoxPointer.put(0, uniqueId);
    } else {
      String tempId = '';
      tempId = resIdBoxPointer.get(0) ?? '';

      if (tempId != uniqueId) {
        restaurantName = AppConstants.restNameByDefault;
      } else {
        accountActivityChecker();
      }
    }
  }

  accountActivityChecker() {
    bool isExpired = true;
    String monthYearString = '000000';

    DateTime dateTime = DateTime.now();

    String tempyearStr = '${dateTime.year}00';
    int currentDate = int.parse(tempyearStr) + dateTime.month;

    monthYearString = setDateTimeBoxPointer.get(0) ?? '';
    monthYearString.isNum ? null : monthYearString = '000000';
    isExpired = currentDate > int.parse(monthYearString);
    isAccountActive = !isExpired;
  }

  String dateTimeIntoString(DateTime dateTime) =>
      dateTime.year.toString() +
      (dateTime.month > 9 ? dateTime.month.toString() : '0${dateTime.month}') +
      (dateTime.day > 9 ? dateTime.day.toString() : '0${dateTime.day}');

  boxOpenerForCurrentDate() async {
    String tempDateTime = dateTimeIntoString(DateTime.now());
    if (currentDateTimeStr != tempDateTime) {
      if (Hive.isBoxOpen(currentDateTimeStr)) {
        saleSaveBoxPointer.close();
      }

      currentDateTimeStr = tempDateTime;
      saleSaveBoxPointer = await Hive.openLazyBox<String>(
          Get.find<PanelController>().currentDateTimeStr);
    } else {
      bool isBoxOpened = Hive.isBoxOpen(currentDateTimeStr);

      if (!isBoxOpened) {
        saleSaveBoxPointer = await Hive.openLazyBox<String>(currentDateTimeStr);
      }
    }
  }

  initializeReturnProduct() {
    returnList = [];
    returnDataPointer.keys.forEach((element) {
      returnList.add(
          ReturnModal.fromJson(jsonDecode(returnDataPointer.get(element)!)));
    });
  }

  initializeDiscountProduct() {
    discountList = [];
    discountDataPointer.keys.forEach((element) {
      discountList.add(DiscountModel.fromJson(
          jsonDecode(discountDataPointer.get(element)!)));
    });
  }

  kSubPrinting(bool isSingle, SubProductsModal product) async {
    String tb = selectedTableString;
    DateTime dateTimeSub = DateTime.now();
    String disTime = dateTimeSub.hour.toString() + ':' + dateTimeSub.minute.toString();
    String disDate = dateTimeSub.day.toString() + '-'+dateTimeSub.month.toString()+ '-'+ dateTimeSub.year.toString();
    final profile = await CapabilityProfile.load();
    PaperSize paper = shopDetailController.shopDetailModel.paperSize == '58mm'
        ? PaperSize.mm58
        : PaperSize.mm80;

    NetworkPrinter printer = NetworkPrinter(paper, profile);
    final PosPrintResult res = await printer.connect(
        shopDetailController.shopDetailModel.kIp,
        port: int.parse(shopDetailController.shopDetailModel.kPort));

    print("Tester:" + product.quantity.toString());
    if (res == PosPrintResult.success) {
      kSubReceipt(
          printer,
          restaurantName,
          shopDetailController,
          disTime,
          disDate,

          adminPanelController,
          tb,


          myDoubleRounder,
          selectedTableString,
          product, isSingle



      );

      printer.disconnect();

    }


  }
}

void mainReceipt(
    NetworkPrinter printer,
    String restaurantName,
    ShopDetailController shopDetailController,
    String disTime,
    String disDate,
    int invoiceNumber,
    AdminPanelController adminPanelController,
    String tb,
    TextEditingController remarksEditingController,
    Map<String, List<SubProductsModal>> productListMap,
    String Function(double, int) myDoubleRounder,
    String selectedTableString,
    Map<String, RestInvoiceModal> restProductDetailsMap) {
  if(shopDetailController.soundLevel>0){
    printer.beep(duration: PosBeepDuration.beep450ms);
  }
  printer.text(restaurantName,
      styles: const PosStyles(
        height: PosTextSize.size2,
        width: PosTextSize.size2,
        align: PosAlign.center,
      ));
  // bytes += generator.clearStyle();
  printer.text(shopDetailController.shopDetailModel.shopMoto,
      styles: const PosStyles(align: PosAlign.center));
  printer.emptyLines(1);
  printer.text('Address: ${shopDetailController.shopDetailModel.shopAddress}',
      styles: const PosStyles(align: PosAlign.center));
  printer.text('Ph# ${shopDetailController.shopDetailModel.shopPhone}',
      styles: const PosStyles(align: PosAlign.center));
  printer.text('D & T: ${disDate} ${disTime}',
      styles: const PosStyles(align: PosAlign.center));
  printer.text('IN# $invoiceNumber',
      styles: const PosStyles(align: PosAlign.center));

  printer.text('Cashier: ${adminPanelController.logInUserName} - M: ${tb}',
      styles: const PosStyles(align: PosAlign.center));

  remarksEditingController.text != ''
      ? printer.text('Remarks: ${remarksEditingController.text}')
      : null;
  printer.hr();

  if (productListMap[selectedTableString] == null) {
    productListMap[selectedTableString] = [];
  }

  for (var element in productListMap[selectedTableString]!) {
    printer.text(element.name, styles: const PosStyles());

    double discout = element.discount * 0.01 * element.quantity * element.price;
    String disString =
        discout > 0 ? ' - Disc: ${myDoubleRounder(discout, 2)}' : '';

    printer.text(
        '${element.quantity < 0 ? " " : ''}${myDoubleRounder(element.price, 2)} x'
        ' ${myDoubleRounder(element.quantity, 3)}$disString = '
        '${myDoubleRounder(element.total, 2)}${element.quantity < 0 ? " " : ''}',
        styles: PosStyles(
            align: PosAlign.center,
            reverse: element.quantity < 0 ? true : false));
  }
  printer.hr();
  var rest = restProductDetailsMap[selectedTableString];
  double discToSend = rest?.wDiscount ?? 0;
  if (rest?.totalSale == null) {
    discToSend = 0;
  } else {
    discToSend = discToSend * rest!.pSale * 0.01;
  }

  printer.row([
    PosColumn(text: ' ', width: 3),
    PosColumn(text: 'S. Total', width: 4),
    PosColumn(
        text: myDoubleRounder(rest?.pSale ?? 0, 2),
        styles: PosStyles(align: PosAlign.right),
        width: 5),
  ]);
  printer.row([
    PosColumn(text: ' ', width: 3),
    PosColumn(text: 'Disc.', width: 4),
    PosColumn(
        text: myDoubleRounder(discToSend, 2),
        styles: PosStyles(align: PosAlign.right),
        width: 5),
  ]);
  printer.row([
    PosColumn(text: ' ', width: 3),
    PosColumn(text: 'Tax%  ', width: 4),
    PosColumn(
        text: myDoubleRounder(rest?.wTax ?? 0, 2),
        styles: PosStyles(align: PosAlign.right),
        width: 5),
  ]);
  printer.row([
    PosColumn(text: ' ', width: 3),
    PosColumn(text: 'Balance  ', width: 4),
    PosColumn(
        text: myDoubleRounder(rest?.balance ?? 0, 2),
        styles: PosStyles(align: PosAlign.right),
        width: 5),
  ]);

  // printer.row(
  //     'S. Total  ', myDoubleRounder(rest?.pSale ?? 0, 2), generator);
  // bytes +=
  //     rowGenerator('Disc.  ', myDoubleRounder(discToSend, 2), generator);
  // bytes +=
  //     rowGenerator('Tax%  ', myDoubleRounder(rest?.wTax ?? 0, 2), generator);
  // bytes += rowGenerator(
  //     'Balance  ', myDoubleRounder(rest?.balance ?? 0, 2), generator);

  printer.hr(ch: '-');

  // bytes += rowGenerator(
  //     'Total', "", generator);

  printer.text("Total", styles: const PosStyles(align: PosAlign.left));

  printer.text(
    '${shopDetailController.shopDetailModel.currency} ${myDoubleRounder(rest?.totalSale ?? 0, 2)}',
    styles: const PosStyles(
        align: PosAlign.right,
        height: PosTextSize.size2,
        width: PosTextSize.size2),
  );

  printer.emptyLines(1);

  printer.hr(ch: '^');
  printer.text("Software developed By",
      styles: PosStyles(align: PosAlign.center));
  printer.text("InformUS Technologies",
      styles: PosStyles(align: PosAlign.center));
  printer.text("WhatsApp# +92-305-4509104",
      styles: PosStyles(align: PosAlign.center));

  printer.feed(shopDetailController.shopDetailModel.spaces);

  printer.cut();
}

void kSubReceipt(
NetworkPrinter printer,
String restaurantName,
ShopDetailController shopDetailController,
String disTime,
String disDate,

AdminPanelController adminPanelController,
String tb,


String Function(double, int) myDoubleRounder,
String selectedTableString,
    SubProductsModal product, bool isSingle



    ){
  printer.text(restaurantName,
      styles: const PosStyles(
        height: PosTextSize.size2,
        width: PosTextSize.size2,
        align: PosAlign.center,
      ));
  if(shopDetailController.soundLevel>0){
    printer.beep(duration: PosBeepDuration.beep450ms);
  }
  printer.emptyLines(1);
  printer.text('D & T: ${disDate} ${disTime}',
      styles: const PosStyles(align: PosAlign.center));


  printer.text('Cashier: ${adminPanelController.logInUserName} - M: ${tb}',
      styles: const PosStyles(align: PosAlign.center));

  printer.hr();
  printer.text(product.name, styles: const PosStyles());
  if(isSingle){
    printer.text(
        '${product.quantity < 0 ? " " : ''}${myDoubleRounder(product.price, 2)} x'
            '1'
        ,
        styles: PosStyles(
            align: PosAlign.center,
            reverse: product.quantity < 0 ? true : false));
  }else{
    printer.text(
        '${product.quantity < 0 ? " " : ''}${myDoubleRounder(product.price, 2)} x'
            ' ${myDoubleRounder(product.quantity, 3)}'
        ,
        styles: PosStyles(
            align: PosAlign.center,
            reverse: product.quantity < 0 ? true : false));
  }

  printer.feed(shopDetailController.shopDetailModel.spaces);

  printer.cut();
}

void kReceipt(
    NetworkPrinter printer,
    String restaurantName,
    ShopDetailController shopDetailController,
    String disTime,
    String disDate,
    int invoiceNumber,
    AdminPanelController adminPanelController,
    String tb,
    TextEditingController remarksEditingController,
    Map<String, List<SubProductsModal>> productListMap,
    String Function(double, int) myDoubleRounder,
    String selectedTableString,
    Map<String, RestInvoiceModal> restProductDetailsMap) {
  printer.text(restaurantName,
      styles: const PosStyles(
        height: PosTextSize.size2,
        width: PosTextSize.size2,
        align: PosAlign.center,
      ));
  //bytes += generator.clearStyle();
if(shopDetailController.soundLevel>0){
  printer.beep(duration: PosBeepDuration.beep450ms);
}
  printer.emptyLines(1);



  printer.text('D & T: ${disDate} ${disTime}',
      styles: const PosStyles(align: PosAlign.center));
  printer.text('IN# $invoiceNumber',
      styles: const PosStyles(align: PosAlign.center , height: PosTextSize.size2, width: PosTextSize.size2));

  printer.text('Cashier: ${adminPanelController.logInUserName} - M: ${tb}',
      styles: const PosStyles(align: PosAlign.center));
  remarksEditingController.text != ''
      ? printer.text('Remarks: ${remarksEditingController.text}')
      : null;
  printer.hr();

  if (productListMap[selectedTableString] == null) {
    productListMap[selectedTableString] = [];
  }

  for (var element in productListMap[selectedTableString]!) {
    printer.text(element.name, styles: const PosStyles());



    printer.text(
        '${element.quantity < 0 ? " " : ''}${myDoubleRounder(element.price, 2)} x'
            ' ${myDoubleRounder(element.quantity, 3)}'
        ,
        styles: PosStyles(
            align: PosAlign.center,
            reverse: element.quantity < 0 ? true : false));
  }

  if(shopDetailController.shopDetailModel.copies == 0){
    printer.emptyLines(1);

    printer.hr(ch: '^');
    printer.text("Software developed By",
        styles: PosStyles(align: PosAlign.center));
    printer.text("InformUS Technologies",
        styles: PosStyles(align: PosAlign.center));
    printer.text("WhatsApp# +92-305-4509104",
        styles: PosStyles(align: PosAlign.center));
  }


  printer.feed(shopDetailController.shopDetailModel.spaces);
  printer.cut();
}

nonActiveReceipt(NetworkPrinter printer){
  printer.emptyLines(1);

  printer.text("Non. Active",
      styles: const PosStyles(
          align: PosAlign.center,
          height: PosTextSize.size2,
          width: PosTextSize.size2));
  printer.text("Demo Account",
      styles: const PosStyles(
          align: PosAlign.center,
          height: PosTextSize.size1,
          width: PosTextSize.size1));
  printer.emptyLines(2);
  printer.text("+92-305-4509104",
      styles: const PosStyles(align: PosAlign.center));

  printer.text("Contact on WhatsApp to",
      styles: const PosStyles(align: PosAlign.center));

  printer.text("active account!",
      styles: const PosStyles(align: PosAlign.center));

  printer.emptyLines(1);

  printer.text("0305-4509104",
      styles: const PosStyles(align: PosAlign.center));

  printer.text("Is account ko active krne ke",
      styles: const PosStyles(align: PosAlign.center));
  printer.text("liye WhatsApp pe rabta kre!",
      styles: const PosStyles(align: PosAlign.center));

  printer.emptyLines(1);

  printer.hr(ch: '^');
  printer.text("Software developed By",
      styles: PosStyles(align: PosAlign.center));
  printer.text("InformUS Technologies",
      styles: PosStyles(align: PosAlign.center));
  printer.text("WhatsApp# +92-305-4509104",
      styles: PosStyles(align: PosAlign.center));
}