import 'dart:convert';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pos_mobile_f/controller/panel_controller.dart';
import 'package:pos_mobile_f/main.dart';
import 'package:pos_mobile_f/modal/category_modal.dart';
import 'package:pos_mobile_f/modal/fire_key_modal.dart';

import '../utils/dimensions.dart';
import 'admin_panel_controller.dart';

class BackUpController extends GetxController implements GetxService {
  AdminPanelController adminPanelController;
  PanelController panelController;
  BackUpController({required this.panelController, required this.adminPanelController});

  late FirebaseFirestore db;

  int progressValue = 0;
  Color colorValueForProgress = Colors.red;

  bool isProcessing = false;
  int isBackUpSuccessFul = 0;

  int progressValueForPull = 0;
  Color colorValueForProgressForPull = Colors.red;

  bool isProcessingForPull = false;
  int isBackUpSuccessFulForPull = 0;

  List<String> keysFromFireList = [];

  initializedDB() {
    db = FirebaseFirestore.instance;
  }

  sendBackUp(String userKey) async {
    String pushDate = pushBackUpDatePointer.get(0) ?? '';
    String currentDate = panelController.dateTimeIntoString(DateTime.now());
    isBackUpSuccessFul = 0;

    progressValue = 0;
    colorValueForProgress = Colors.red;
    isProcessing = true;
    update();

    await storeBackUpSingleKeyPointer.put(0, userKey);
    await takeKeys();

    progressValue = 50;
    colorValueForProgress = Colors.blue;

    update();

    if (keysFromFireList.isEmpty) {
      isBackUpSuccessFul = 1;
    }

    if (isBackUpSuccessFul != 1) {
      isBackUpSuccessFul = 2;
    }

    List<String> dataOfProductList = [];
    List<String> dataOfCategory = [];
    for (var element in panelController.productController.productList) {
      dataOfProductList.add(jsonEncode(element));
    }

    for (var element in panelController.productController.categoriesList) {
      dataOfCategory.add(jsonEncode(element));
    }

    if (pushDate != currentDate) {
      for (int i = 0; i < keysFromFireList.length; i++) {
        if (userKey == keysFromFireList[i]) {
          Map<String, List<String>> toSendProduct = {
            'products': dataOfProductList
          };

          db
              .collection('productsee')
              .doc(userKey)
              .set(toSendProduct)
              .onError((error, stackTrace) => isBackUpSuccessFul = 3);

          if (isBackUpSuccessFul != 3) {
            isBackUpSuccessFul = 4;
            await pushBackUpDatePointer.put(0, currentDate);
          }
          i = keysFromFireList.length;
        }
      }
    } else {
      isBackUpSuccessFul = 5;
    }

    progressValue = 100;
    colorValueForProgress = Colors.green;
    isProcessing = false;
    update();

    if (isBackUpSuccessFul == 1) {
      Get.snackbar("Error", 'Error 101 occurred!',
          backgroundColor: Colors.redAccent,
          maxWidth: Dimension.width30 * 22,
          colorText: Colors.white);
    } else if (isBackUpSuccessFul == 2) {
      Get.snackbar("Error", 'Your Key is not valid!',
          backgroundColor: Colors.redAccent,
          maxWidth: Dimension.width30 * 22,
          colorText: Colors.white);
    } else if (isBackUpSuccessFul == 3) {
      Get.snackbar("Error", 'Error 103 occurred!',
          backgroundColor: Colors.redAccent,
          maxWidth: Dimension.width30 * 22,
          colorText: Colors.white);
    } else if (isBackUpSuccessFul == 4) {
      Get.snackbar("Success", 'Data is backed UP',
          backgroundColor: Colors.green,
          maxWidth: Dimension.width30 * 22,
          colorText: Colors.white);
    } else if (isBackUpSuccessFul == 5) {
      Get.snackbar("Error", 'You can take only one back-up  a day!',
          backgroundColor: Colors.redAccent,
          maxWidth: Dimension.width30 * 22,
          colorText: Colors.white);
    } else {
      print("Nothing Found");
    }
  }

  takeKeys() async {
    DateTime dateTime = DateTime.now();

    String currentDate = panelController.dateTimeIntoString(dateTime);

    String listCheckDate = fireListCheckPointer.get(0) ?? '';

    bool isSameDay = currentDate == listCheckDate;

    if (isSameDay) {
      keysFromFireList = [];
      for (int key in backUpKeyPointer.keys) {
        keysFromFireList.add(backUpKeyPointer.get(key)!);
      }
    } else {
      final docRef = db.collection("mainKeys").doc("keysBy");
      await docRef.get(const GetOptions()).then(
        (res) async {
          await fireListCheckPointer.put(0, currentDate);

          await backUpKeyPointer.deleteAll(backUpKeyPointer.keys);

          FireKeyModal fireKeyModal = FireKeyModal.fromJson(res.data()!);

          await backUpKeyPointer.addAll(fireKeyModal.fireKeyList);

          keysFromFireList = [];
          for (int key in backUpKeyPointer.keys) {
            keysFromFireList.add(backUpKeyPointer.get(key)!);
          }
        },
        onError: (e) {},
      );
    }
  }

  getProductsData(String userKey) async {
    String pullDate = pullBackUpDatePointer.get(0) ?? '';
    String currentDate = panelController.dateTimeIntoString(DateTime.now());

    progressValueForPull = 0;
    colorValueForProgressForPull = Colors.red;

    isProcessingForPull = true;
    isBackUpSuccessFulForPull = 0;

    update();

    await takeKeys();
    progressValueForPull = 30;
    colorValueForProgressForPull = Colors.blue;

    update();

    if (keysFromFireList.isEmpty) {
      isBackUpSuccessFulForPull = 1;
    }
    if (isBackUpSuccessFulForPull != 1) {
      isBackUpSuccessFulForPull = 2;
    }

    if (pullDate != currentDate) {
      for (int i = 0; i < keysFromFireList.length; i++) {

        if (userKey == keysFromFireList[i]) {


          List<String> productsListInStr = [];

          await db.collection('productsee').doc(userKey).get().then(
            (DocumentSnapshot doc) async {
              final data = doc.data() as Map<String, dynamic>;
              if (data['products'] != null) {
                productsListInStr =
                    List.castFrom<dynamic, String>(data['products']);
              }
            },
            onError: (e) => isBackUpSuccessFulForPull = 3,
          );

          if (isBackUpSuccessFulForPull != 3) {
            print('home');
            await productBoxPointer.deleteAll(productBoxPointer.keys);
            await productBoxPointer.addAll(productsListInStr);
            panelController.productController.initializingProductList();
            panelController.productController.initializingCategoriesList();

            isBackUpSuccessFulForPull = 4;
            await pullBackUpDatePointer.put(0, currentDate);
          }
          i = keysFromFireList.length;
        }
      }
    } else {
      isBackUpSuccessFulForPull = 5;
    }

    progressValueForPull = 100;
    colorValueForProgressForPull = Colors.green;

    isProcessingForPull = false;
    update();

    if (isBackUpSuccessFulForPull == 1) {
      Get.snackbar("Error", 'Error 101 occurred!',
          backgroundColor: Colors.redAccent,
          maxWidth: Dimension.width30 * 22,
          colorText: Colors.white);
    } else if (isBackUpSuccessFulForPull == 2) {
      Get.snackbar("Error", 'Your Key is not valid!',
          backgroundColor: Colors.redAccent,
          maxWidth: Dimension.width30 * 22,
          colorText: Colors.white);
    } else if (isBackUpSuccessFulForPull == 3) {
      Get.snackbar("Error", 'Error 103 occurred!',
          backgroundColor: Colors.redAccent,
          maxWidth: Dimension.width30 * 22,
          colorText: Colors.white);
    } else if (isBackUpSuccessFulForPull == 4) {
      Get.snackbar("Success", 'Data has been updated',
          backgroundColor: Colors.green,
          maxWidth: Dimension.width30 * 22,
          colorText: Colors.white);
    } else if (isBackUpSuccessFulForPull == 5) {
      Get.snackbar("Error", 'You can take products only one time a day!',
          backgroundColor: Colors.redAccent,
          maxWidth: Dimension.width30 * 22,
          colorText: Colors.white);
    } else {
      print("Nothing Found");
    }
  }
}

//
// final ref = db.collection("mainKeys").doc("keysBy").withConverter(
//   fromFirestore: FireKeyModal.fromFirestore,
//   toFirestore: (FireKeyModal fireKeyModal, _) =>
//       fireKeyModal.toFireStore(),
// );
//
// final docSnap = await ref.get();
// if (docSnap.data() != null) {
// FireKeyModal fireKeyModal = docSnap.data()!;
//
// fireKeyModal.fireKeyList!.forEach((element) {
// print("Data" + element);
// });
// }
