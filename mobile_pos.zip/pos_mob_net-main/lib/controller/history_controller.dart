import 'dart:convert';
import 'dart:io';

import 'package:blue_thermal_printer/blue_thermal_printer.dart';
import 'package:esc_pos_printer/esc_pos_printer.dart';
import 'package:esc_pos_utils/esc_pos_utils.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:hive/hive.dart';
import 'package:open_filex/open_filex.dart';
import 'package:path_provider/path_provider.dart';
import 'package:pos_mobile_f/controller/panel_controller.dart';
import 'package:pos_mobile_f/controller/shop_detail_controller.dart';
import 'package:pos_mobile_f/main.dart';
import 'package:pos_mobile_f/modal/day_sale_list_modal.dart';
import 'package:pos_mobile_f/modal/log_in_modal.dart';
import 'package:pos_mobile_f/modal/sold_products_list_modal.dart';
import 'package:syncfusion_flutter_xlsio/xlsio.dart';

import '../modal/invoice_modal.dart';
import '../utils/dimensions.dart';
import 'admin_panel_controller.dart';

class HistoryController extends GetxController implements GetxService {
  AdminPanelController adminPanelController;
  HistoryController({required this.adminPanelController});

  bool isExpanded = true;
  bool isLoading = false;
  int hour1H = 0;
  int hour2H = 23;
  int dayListIndex = DateTime.now().day;
  int monthListIndex = DateTime.now().month;
  int yearListIndex = DateTime.now().year;
  int dayTListIndex = DateTime.now().day;
  int monthTListIndex = DateTime.now().month;
  int yearTListIndex = DateTime.now().year;
  double sale = 0;
  double profit = 0;
  int salesCounter = 0;
  int soldProductCounter = 0;

  double tempSaleCal = 0;

  String dateForModalSheet = '00-00-0000';
  String dateTForModalSheet = '00-00-0000';
  String checkTest = 'Hello';

  List<MainInvoice> invoiceList = [];
  List<DaySaleListModal> daySaleList = [];
  List<SoldProductListModal> soldProductsList = [];

  String userListForHisIndex = 'All';

  String tbListIndex = 'All';
  String date1ForExcel = '';
  String date2ForExcel = '';

  List<String> tbList = [];
  List<String> userListForHis = [];

  setExpandingMode(bool mode){
    isExpanded = mode;
    update();
  }

  initiateTbAndUserList() {
    tbList = [];
    userListForHis = [];

    tbList.add('All');
    userListForHis.add('All');


    tableBoxPointer.keys.forEach((element) {
      tbList.add(tableBoxPointer.get(element).toString());
    });



    usersListPointer.keys.forEach((element) {
      userListForHis.add(
          LogInModal.fromJson(jsonDecode(usersListPointer.get(element)!))
              .username);
    });
  }

  getInvoiceDate(

      int day, int month, int year, int dayT, int monthT, int yearT, int h1 , int h2) async {
    invoiceList = [];
    soldProductsList = [];
    isLoading = true;
    setExpandingMode(false);
    List<MainInvoice> temMainInvoiceList = [];
    String date = year.toString() +
        (month > 9 ? month.toString() : '0$month') +
        (day > 9 ? day.toString() : '0$day');
    String dateT = yearT.toString() +
        (monthT > 9 ? monthT.toString() : '0$monthT') +
        (dayT > 9 ? dayT.toString() : '0$dayT');

    date1ForExcel = day.toString()+'-'+ month.toString()+'-'+ year.toString();
    date2ForExcel = dayT.toString()+ '-'+ monthT.toString()+ '-' + yearT.toString();

    String dateC = DateTime.now().year.toString() +
        (DateTime.now().month > 9 ? DateTime.now().month.toString() : '0${DateTime.now().month}') +
        (DateTime.now().day > 9 ? DateTime.now().day.toString() : '0${DateTime.now().day}');

int date3 = int.parse(dateC);

    int date1 = int.parse(date);
    int date2 = int.parse(dateT);
    date2>date3? date2 = date3: null;
    print("Date:" + date1.toString() + '---' + date2.toString());
    dateForModalSheet =
        '${date.substring(6, 8)}-${date.substring(4, 6)}-${date.substring(0, 4)}';
    dateTForModalSheet =
        '${dateT.substring(6, 8)}-${dateT.substring(4, 6)}-${dateT.substring(0, 4)}';

    await saleSaveBoxPointer.close();
    int startDate = date1;
    for (; date1 <= date2; date1++) {
      final pointer = await Hive.openBox<String>(date1.toString());
      for (var key in pointer.keys) {
        MainInvoice object =  MainInvoice.fromJson(jsonDecode(pointer.get(key)!));
        String timeTo = object.invoiceNumber;

        int comTime = int.parse(timeTo.substring(timeTo.indexOf(' - ' ) +3, timeTo.indexOf(':') ));


        if(date1 == startDate && startDate == date2){
          if(h1 <= comTime && h2 >= comTime ){
            invoiceList.add(object);
          }
        }
 else
        if(date1 == startDate){
          if(h1 <= comTime ){
            invoiceList.add(object);
          }
        }
        else if(date1 == date2){

          if(h2 >= comTime ){
            print("Date2:" +dayT.toString());
            invoiceList.add(object);
          }
        } else{
          invoiceList.add(object);
        }







      }

      await pointer.close();
    }

    if(userListForHisIndex != 'All'){
      invoiceList.forEach((element) {

      if(element.cashier == userListForHisIndex)  {

        temMainInvoiceList.add(element);
      }



      });
      print("User" + temMainInvoiceList.length.toString());
     // invoiceList = [];
      invoiceList = temMainInvoiceList;
      temMainInvoiceList = [];
    }

    if(tbListIndex != 'All'){
      invoiceList.forEach((element) {
        if(element.tb == tbListIndex){
          temMainInvoiceList.add(element);
        }

      });
      invoiceList =  temMainInvoiceList;
      temMainInvoiceList = [];

    }






    // final pointer = saleSaveBoxPointer;

    sale = 0;
    profit = 0;
    salesCounter = 0;
    tempSaleCal = 0;
    soldProductCounter = 0;

    if (invoiceList.isEmpty) {
    } else {
      salesCounter = invoiceList.length;
      invoiceList.forEach((element) {
        sale += element.restInvoice.totalSale;
        element.subProductsList.forEach((element) {
          tempSaleCal += element.cost * element.quantity;

          if (soldProductsList.isEmpty) {
            soldProductsList.add(SoldProductListModal(
                name: element.name, counter: element.quantity));
          } else {
            int index = soldProductsList
                .map((e) => e.name)
                .toList()
                .indexOf(element.name);

            if (index > -1) {
              soldProductsList[index].counter += element.quantity;
            } else {
              soldProductsList.add(SoldProductListModal(
                  name: element.name, counter: element.quantity));
            }
          }
        });
      });
    }

    profit = sale - tempSaleCal;

    soldProductCounter = soldProductsList.length;
    soldProductsList.sort((b, a) => a.counter.compareTo(b.counter));
    isLoading = false;
    update();
  }

  initializingDaySaleList() {
    daySaleList = [];

    for (var element in saleTotalListPointer.keys) {
      daySaleList.add(DaySaleListModal(
          sale: saleTotalListPointer.get(element)!, day: element.toString()));
    }

    //
    // for(int i=0 ;i<20 ; i++){
    //   daySaleList.add(DaySaleListModal(sale: 1000*i*i.toDouble() , day: ( i<10?  '202309'+ "0"+ i.toString() :'202309'+  i.toString() ) ));
    // }
  }

  reverseList() {
    List<SoldProductListModal> temList = [];

    temList = soldProductsList.reversed.toList();

    soldProductsList = temList;
    update();
  }

  printDupModule(MainInvoice mainInvoice) async {
    {

      DateTime cDataTime = DateTime.now();
      String disDate = '${cDataTime.day}-${cDataTime.month}-${cDataTime.year}';
      String disTime = '${cDataTime.hour}:${cDataTime.minute}';
      final profile = await CapabilityProfile.load();
      final generator = Generator(PaperSize.mm58, profile);

      const MethodChannel _channel = MethodChannel('blue/methods');

      BlueThermalPrinter bluetooth = BlueThermalPrinter.instance;

      int invoiceNumber = invoiceNumberPointer.get(0) ?? 0;

      await invoiceNumberPointer.put(0, invoiceNumber + 1);

      PanelController pController = Get.find<PanelController>();

      PaperSize paper = pController.shopDetailController.shopDetailModel.paperSize == '58mm'
          ? PaperSize.mm58
          : PaperSize.mm80;
      final printer = NetworkPrinter(paper, profile);
      if (pController.isAccountActive) {
        if (pController.shopDetailController.shopDetailModel.isNetwork) {
          final PosPrintResult res = await printer.connect(
              pController.shopDetailController.shopDetailModel.mainIp,
              port: int.parse(pController.shopDetailController.shopDetailModel.mainPort));
          // final PosPrintResult res = await printer.connect("192.168.0.87",
          //                port: 9100);
              ;
          if (res == PosPrintResult.success) {
         mainDReceipt(printer, dayListIndex, monthListIndex, yearListIndex, disDate, disTime, mainInvoice, pController);

            printer.disconnect();
          }
        }
        List<int> bytes = [];
        if(Get.find<ShopDetailController>().shopDetailModel.soundLevel>0){
          bytes +=    generator.beep();
        }

        bytes += generator.text(pController.restaurantName,
            styles: const PosStyles(
              height: PosTextSize.size2,
              width: PosTextSize.size2,
              align: PosAlign.center,
            ));
       // bytes += generator.clearStyle();
        bytes += generator.text(
            pController.shopDetailController.shopDetailModel.shopMoto,
            styles: const PosStyles(align: PosAlign.center));
        bytes += generator.emptyLines(1);
        bytes += generator.text(
            'Address: ${pController.shopDetailController.shopDetailModel.shopAddress}',
            styles: const PosStyles(align: PosAlign.center));
        bytes += generator.text(
            'Ph# ${pController.shopDetailController.shopDetailModel.shopPhone}',
            styles: const PosStyles(align: PosAlign.center));

        bytes += generator.text(
            'D & T: $dayListIndex-$monthListIndex-$yearListIndex ${mainInvoice.invoiceNumber.substring(mainInvoice.invoiceNumber.indexOf('- '))}',
            styles: const PosStyles(align: PosAlign.center));
        bytes += generator.text(
            'IN# ${mainInvoice.invoiceNumber.substring(0, mainInvoice.invoiceNumber.indexOf(' -'))}',
            styles: const PosStyles(
              align: PosAlign.center,
            ));
        bytes += generator.text('Cashier: ${mainInvoice.cashier} - M: ${mainInvoice.tb}',
            styles: const PosStyles(align: PosAlign.center));
        mainInvoice.remarks != ''
            ? bytes += generator.text('Remarks: ${mainInvoice.remarks}')
            : null;
        bytes += generator.text('Duplicate- ${disDate} ${disTime} ',
            styles: const PosStyles(
              align: PosAlign.left,
            ));
        bytes += generator.hr();

        mainInvoice.subProductsList ??= [];

        for (var element in mainInvoice.subProductsList!) {
          bytes += generator.text(element.name, styles: const PosStyles());

          double discout =
              element.discount * 0.01 * element.quantity * element.price;
          String disString = discout > 0
              ? ' - Disc: ${pController.myDoubleRounder(discout, 2)}'
              : '';

          bytes += generator.text(
              '${element.quantity < 0 ? " " : ''}${pController.myDoubleRounder(element.price, 2)} x'
              ' ${pController.myDoubleRounder(element.quantity, 3)}$disString = '
              '${pController.myDoubleRounder(element.total, 2)}${element.quantity < 0 ? " " : ''}',
              styles: PosStyles(
                  align: PosAlign.center,
                  reverse: element.quantity < 0 ? true : false));
        }

        bytes += generator.hr();
        var rest = mainInvoice.restInvoice;
        double discToSend = rest?.wDiscount ?? 0;
        if (rest?.totalSale == null) {
          discToSend = 0;
        } else {
          discToSend = discToSend * rest!.pSale * 0.01;
        }

        bytes += pController.rowGenerator('S. Total  ',
            pController.myDoubleRounder(rest?.pSale ?? 0, 2), generator);
        bytes += pController.rowGenerator(
            'Disc.  ', pController.myDoubleRounder(discToSend, 2), generator);
        bytes += pController.rowGenerator(
            'Tax%  ', pController.myDoubleRounder(rest?.wTax ?? 0, 2), generator);
        bytes += pController.rowGenerator('Balance  ',
            pController.myDoubleRounder(rest?.balance ?? 0, 2), generator);
        bytes += generator.hr(ch: '-');

        // bytes += rowGenerator(
        //     'Total', "", generator);

        bytes += generator.text("Total",
            styles: const PosStyles(align: PosAlign.left));

        bytes += generator.text(
          '${pController.shopDetailController.shopDetailModel.currency} ${pController.myDoubleRounder(rest?.totalSale ?? 0, 2)}',
          styles: const PosStyles(
              align: PosAlign.right,
              height: PosTextSize.size3,
              width: PosTextSize.size3),
        );

        bytes += generator.emptyLines(1);

        bytes += generator.hr(ch: '^');
        bytes += generator.text("Software developed By",
            styles: PosStyles(align: PosAlign.center));
        bytes += generator.text("InformUS Technologies",
            styles: PosStyles(align: PosAlign.center));
        bytes += generator.text("WhatsApp# +92-305-4509104",
            styles: PosStyles(align: PosAlign.center));
        bytes += generator.feed(Get.find<ShopDetailController>().shopDetailModel.spaces);


      if(pController.thermalConnection){
        bluetooth.writeBytes(Uint8List.fromList(bytes));

        bluetooth.paperCut();
      }

      if(pController.usbThermalConnection){
        bytes += generator.cut();
        await pController.dragoUsbPrinter.write(Uint8List.fromList(bytes));
      }

      } else {
        List<int> bytes = [];
        bytes += generator.emptyLines(1);

        bytes += generator.text("Non. Active",
            styles: const PosStyles(
                align: PosAlign.center,
                height: PosTextSize.size2,
                width: PosTextSize.size2));
        bytes += generator.text("Demo Account",
            styles: const PosStyles(
                align: PosAlign.center,
                height: PosTextSize.size1,
                width: PosTextSize.size1));
        bytes += generator.emptyLines(2);
        bytes += generator.text("+92-305-4509104",
            styles: const PosStyles(align: PosAlign.center));

        bytes += generator.text("Contact on WhatsApp to",
            styles: const PosStyles(align: PosAlign.center));

        bytes += generator.text("active account!",
            styles: const PosStyles(align: PosAlign.center));

        bytes += generator.emptyLines(1);

        bytes += generator.text("0305-4509104",
            styles: const PosStyles(align: PosAlign.center));

        bytes += generator.text("Is account ko active krne ke",
            styles: const PosStyles(align: PosAlign.center));
        bytes += generator.text("liye WhatsApp pe rabta kre!",
            styles: const PosStyles(align: PosAlign.center));

        bytes += generator.emptyLines(1);

        bytes += generator.hr(ch: '^');
        bytes += generator.text("Software developed By",
            styles: PosStyles(align: PosAlign.center));
        bytes += generator.text("InformUS Technologies",
            styles: PosStyles(align: PosAlign.center));
        bytes += generator.text("WhatsApp# +92-305-4509104",
            styles: PosStyles(align: PosAlign.center));

        bluetooth.writeBytes(Uint8List.fromList(bytes));

        bluetooth.paperCut();
      }
    }
  }

  generateExcel() async {
    // soldProductList
    // invoiceList

    if(invoiceList.isNotEmpty && soldProductsList.isNotEmpty){
      final Workbook workbook = new Workbook();
      workbook.worksheets.create(0);
      final Worksheet sheet1 = workbook.worksheets[0];
      workbook.worksheets.create(1);
      final Worksheet sheet2 = workbook.worksheets[1];
      workbook.worksheets.create(2);
      final Worksheet sheet3 = workbook.worksheets[2];

      sheet1.name = 'Invoices History';
      sheet2.name = 'Sold Products';
      sheet3.name = 'Further Details';



      sheet1.getRangeByName('A1').setText('InvoiceNumber');
      sheet1.getRangeByName('B1').setText('Date');
      sheet1.getRangeByName('C1').setText('Cashier');
      sheet1.getRangeByName('D1').setText('TB');
      sheet1.getRangeByName('E1').setText('Remarks');
      sheet1.getRangeByName('F1').setText('Sub Total');
      sheet1.getRangeByName('G1').setText('OverAll Discount');
      sheet1.getRangeByName('H1').setText('Tax');
      sheet1.getRangeByName('I1').setText('Balance');
      sheet1.getRangeByName('J1').setText('Net Total');

      sheet3.getRangeByName('A1').setText('InvoiceNumber');
      sheet3.getRangeByName('B1').setText('Date');
      sheet3.getRangeByName('C1').setText('Cashier');
      sheet3.getRangeByName('D1').setText('TB');
      sheet3.getRangeByName('E1').setText('Remarks');
      sheet3.getRangeByName('F1').setText('Product Name');
      sheet3.getRangeByName('G1').setText('Product Code');
      sheet3.getRangeByName('H1').setText('Cost');
      sheet3.getRangeByName('I1').setText('Unit Price');
      sheet3.getRangeByName('J1').setText('Quantity');
      sheet3.getRangeByName('K1').setText('Discount');
      sheet3.getRangeByName('L1').setText('Total');


      int marker1 = 2;
      int marker3  = 2;
      invoiceList.forEach((element) {

        sheet1.getRangeByName('A$marker1').setText(element.invoiceNumber);
        sheet1.getRangeByName('B$marker1').setText(element.date);
        sheet1.getRangeByName('C$marker1').setText(element.cashier);
        sheet1.getRangeByName('D$marker1').setText(element.tb);
        sheet1.getRangeByName('E$marker1').setText(element.remarks);
        sheet1.getRangeByName('F$marker1').setNumber(element.restInvoice.pSale);
        sheet1.getRangeByName('G$marker1').setNumber(element.restInvoice.wDiscount);
        sheet1.getRangeByName('H$marker1').setNumber(element.restInvoice.wTax);
        sheet1.getRangeByName('I$marker1').setNumber(element.restInvoice.balance);
        sheet1.getRangeByName('J$marker1').setNumber(element.restInvoice.totalSale);
        element.subProductsList.forEach((sElement) {
          sheet3.getRangeByName('A$marker3').setText(element.invoiceNumber);
          sheet3.getRangeByName('B$marker3').setText(element.date);
          sheet3.getRangeByName('C$marker3').setText(element.cashier);
          sheet3.getRangeByName('D$marker3').setText(element.tb);
          sheet3.getRangeByName('E$marker3').setText(element.remarks);
          sheet3.getRangeByName('F$marker3').setText(sElement.name);
          sheet3.getRangeByName('G$marker3').setText(sElement.code);
          sheet3.getRangeByName('H$marker3').setNumber(sElement.cost);
          sheet3.getRangeByName('I$marker3').setNumber(sElement.price);
          sheet3.getRangeByName('J$marker3').setNumber(sElement.quantity);
          sheet3.getRangeByName('K$marker3').setNumber(sElement.discount);
          sheet3.getRangeByName('L$marker3').setNumber(sElement.total);
          marker3++;
        });
        marker1++;
      });


      marker1 +=5;

      sheet1.getRangeByName('A$marker1').setText('Invoices Count');
      sheet1.getRangeByName('B$marker1').setNumber(invoiceList.length.toDouble());


      marker1++;
      sheet1.getRangeByName('A$marker1').setText('Total Sale');
      sheet1.getRangeByName('B$marker1').setNumber(sale);

      marker1++;
      sheet1.getRangeByName('A$marker1').setText('Total Profit');
      sheet1.getRangeByName('B$marker1').setNumber(profit);



      int marker2  = 2;
      sheet2.getRangeByName('A1').setText("Product");
      sheet2.getRangeByName('B1').setText("Quantity");


      soldProductsList.forEach((element) {

        sheet2.getRangeByName('A$marker2').setText(element.name);
        sheet2.getRangeByName('B$marker2').setNumber(element.counter);

        marker2++;


      });





     // invoiceList[0].subProductsList[0].









      final List<int> bytes = workbook.saveAsStream();
      workbook.dispose();
      final String path = (await getApplicationDocumentsDirectory()).path;
      final String fileName = '$path/$date1ForExcel---$date2ForExcel.xlsx';      final File  file = File(fileName);

     await file.writeAsBytes(bytes);
     await OpenFilex.open(fileName);


    }

    else{
      Get.snackbar("Restriction", 'There is no sale!',
          backgroundColor: Colors.redAccent , maxWidth: Dimension.width30*22,colorText: Colors.white);


    }



  }


}
void mainDReceipt(
    NetworkPrinter printer,int dayListIndex, int monthListIndex, int yearListIndex,String disDate, String disTime,
MainInvoice mainInvoice,
 PanelController pController ) {

  printer.text(pController.restaurantName,
      styles: const PosStyles(
        height: PosTextSize.size2,
        width: PosTextSize.size2,
        align: PosAlign.center,
      ));
  // bytes += generator.clearStyle();
  printer.text(
      pController.shopDetailController.shopDetailModel.shopMoto,
      styles: const PosStyles(align: PosAlign.center));
  printer.emptyLines(1);
  printer.text(
      'Address: ${pController.shopDetailController.shopDetailModel.shopAddress}',
      styles: const PosStyles(align: PosAlign.center));
  printer.text(
      'Ph# ${pController.shopDetailController.shopDetailModel.shopPhone}',
      styles: const PosStyles(align: PosAlign.center));

  printer.text(
      'D & T: $dayListIndex-$monthListIndex-$yearListIndex ${mainInvoice.invoiceNumber.substring(mainInvoice.invoiceNumber.indexOf('- '))}',
      styles: const PosStyles(align: PosAlign.center));
  printer.text(
      'IN# ${mainInvoice.invoiceNumber.substring(0, mainInvoice.invoiceNumber.indexOf(' -'))}',
      styles: const PosStyles(
        align: PosAlign.center,
      ));
  printer.text('Cashier: ${mainInvoice.cashier} - M: ${mainInvoice.tb}',
      styles: const PosStyles(align: PosAlign.center));
  mainInvoice.remarks != ''
      ? printer.text('Remarks: ${mainInvoice.remarks}')
      : null;
  printer.text('Duplicate- ${disDate} ${disTime} ',
      styles: const PosStyles(
        align: PosAlign.left,
      ));
  printer.hr();

  mainInvoice.subProductsList ??= [];

  for (var element in mainInvoice.subProductsList!) {
    printer.text(element.name, styles: const PosStyles());

    double discout =
        element.discount * 0.01 * element.quantity * element.price;
    String disString = discout > 0
        ? ' - Disc: ${pController.myDoubleRounder(discout, 2)}'
        : '';

    printer.text(
        '${element.quantity < 0 ? " " : ''}${pController.myDoubleRounder(element.price, 2)} x'
            ' ${pController.myDoubleRounder(element.quantity, 3)}$disString = '
            '${pController.myDoubleRounder(element.total, 2)}${element.quantity < 0 ? " " : ''}',
        styles: PosStyles(
            align: PosAlign.center,
            reverse: element.quantity < 0 ? true : false));
  }

  printer.hr();
  var rest = mainInvoice.restInvoice;
  double discToSend = rest?.wDiscount ?? 0;
  if (rest?.totalSale == null) {
    discToSend = 0;
  } else {
    discToSend = discToSend * rest!.pSale * 0.01;
  }

  printer.row([
    PosColumn(text: ' ', width: 3),
    PosColumn(text: 'S. Total', width: 4),
    PosColumn(
        text: pController.myDoubleRounder(rest?.pSale ?? 0, 2),
        styles: PosStyles(align: PosAlign.right),
        width: 5),
  ]);
  printer.row([
    PosColumn(text: ' ', width: 3),
    PosColumn(text: 'Disc.', width: 4),
    PosColumn(
        text: pController.myDoubleRounder(discToSend, 2),
        styles: PosStyles(align: PosAlign.right),
        width: 5),
  ]);
  printer.row([
    PosColumn(text: ' ', width: 3),
    PosColumn(text: 'Tax%  ', width: 4),
    PosColumn(
        text: pController.myDoubleRounder(rest?.wTax ?? 0, 2),
        styles: PosStyles(align: PosAlign.right),
        width: 5),
  ]);
  printer.row([
    PosColumn(text: ' ', width: 3),
    PosColumn(text: 'Balance  ', width: 4),
    PosColumn(
        text: pController.myDoubleRounder(rest?.balance ?? 0, 2),
        styles: PosStyles(align: PosAlign.right),
        width: 5),
  ]);
  printer.hr(ch: '-');

  // bytes += rowGenerator(
  //     'Total', "", generator);

  printer.text("Total",
      styles: const PosStyles(align: PosAlign.left));

  printer.text(
    '${pController.shopDetailController.shopDetailModel.currency} ${pController.myDoubleRounder(rest?.totalSale ?? 0, 2)}',
    styles: const PosStyles(
        align: PosAlign.right,
        height: PosTextSize.size2,
        width: PosTextSize.size2),
  );

  printer.emptyLines(1);

  printer.hr(ch: '^');
  printer.text("Software developed By",
      styles: PosStyles(align: PosAlign.center));
  printer.text("InformUS Technologies",
      styles: PosStyles(align: PosAlign.center));
  printer.text("WhatsApp# +92-305-4509104",
      styles: PosStyles(align: PosAlign.center));
  printer.feed(Get.find<ShopDetailController>().shopDetailModel.spaces);
  printer.cut();
}