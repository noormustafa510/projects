class AppConstants {
  static const String testing = '10';

  static const String categoryBox = 'category-box$testing';
  static const String productBox = 'product-box$testing';
  static const String tableBox = 'table-box$testing';
  static const String resNameBox = 'res-name-box$testing';
  static const String resIDBox = 'res-id-box$testing';
  static const String setDateTimeBox = 'set-dateTime-box$testing';
  static const String saleTotalListBox = 'sale-total-list-box$testing';
  static const String invoiceNumberBox = 'invoice-number-box$testing';
  static const String shopDetailBox = 'shop-detail-box-2$testing';
  static const String triedLimitsBox = 'tried-limit-box$testing';
  static const String usedMonthBox = 'used-month-box$testing';
  static const String usedYearBox = 'used-year-box$testing';
  static const String backUpKeyBox = 'back-up-box$testing';
  static const String fireListCheckBox = 'fire-list-check-box$testing';
  static const String storeBackUpSingleKeyBox = 'store-Back-up-Single-key-box$testing';
  static const String pushBackUpDateBox = 'push-back-up-date-int-box$testing';
  static const String pullBackUpDateBox = 'pull-back-up-date-int-box$testing';
  static const String returnDataBox = 'return-data-box$testing';
  static const String discountDataBox = 'discount-data-box$testing';
  static const String usersListBox = 'user-list-box$testing';
  static const String wrongAttemptBox = 'wrong-attempt-box$testing';
  static const String lastBarCodeGenBox = 'last-barcode-gen-box$testing';


  static const String restNameByDefault = 'Demo Store';
  static const String restMoto = 'Best Store in Town';

  static const String restPhone = '+92-305-4509104';

  static const String restAddress =
      'Shop# 9, Khan  Market  near  Shehbaz Khan Road Kasur';

  static const String idEncryptionKey = 'p12qhysqaavba12tp12qhysqaavba12tSt3/tT9q54as';
  static const String dateTimeEncryptionKey = 'p12qhysqaasts12tp12qhysqfdvba12tStq/tT9q54as';
  static const String generalEncryptionKey = 'p12qhysqaasts12tg1eqhyrqfavba12tStq/tT9q54as';
 // static const String dateTimeEncryptionKey = 'p12qhysqdddts12tp12qhysqfdvba12tStq/tT9q54as';


  //SharedPreference

//static const String triedLimits = 'tried-limits$testing';
//static const String usedMonth = 'used-month $testing';
//static const String usedYear = 'used-year $testing';
//static const String shopDetailPoint = 'shop-details $testing';
//static const String invoiceNumber = 'invoice-number $testing';

}

//http://mvs.bslmeiyu.com/api/v1/products/popular
//http://mvs.bslmeiyu.com/api/v1/products/popular/uploads/images/9447a79793a4b7f832d981f975c0abc4.jpeg
