import 'package:get/get.dart';
import 'package:pos_mobile_f/controller/admin_panel_controller.dart';
import 'package:pos_mobile_f/controller/back_up_controller.dart';
import 'package:pos_mobile_f/controller/barcode_controller.dart';
import 'package:pos_mobile_f/controller/history_controller.dart';
import 'package:pos_mobile_f/controller/limit_controller.dart';
import 'package:pos_mobile_f/controller/panel_controller.dart';
import 'package:pos_mobile_f/controller/product_controller.dart';
import 'package:pos_mobile_f/controller/scanner_controller.dart';
import 'package:pos_mobile_f/controller/shop_detail_controller.dart';


Future<void> init() async {
  Get.lazyPut(() => ScannerController());
  Get.lazyPut(() => ProductController(
        adminPanelController: Get.find(),
      ));
  Get.lazyPut(() => PanelController(
      productController: Get.find(),
      shopDetailController: Get.find(),
      limitController: Get.find(),
      adminPanelController: Get.find()));
  Get.lazyPut(() => ShopDetailController(adminPanelController: Get.find()));
  Get.lazyPut(() => HistoryController(adminPanelController: Get.find()));
  Get.lazyPut(() => BarcodeController(
      panelController: Get.find(), adminPanelController: Get.find()));
  Get.lazyPut(() => LimitController(
      productController: Get.find(), adminPanelController: Get.find()));
  Get.lazyPut(() => BackUpController(
      panelController: Get.find(), adminPanelController: Get.find()));
  Get.lazyPut(() => AdminPanelController());

  // final sharedPreferences = await SharedPreferences.getInstance();
  //
  // Get.lazyPut(() => sharedPreferences);
  // //api client
  // Get.lazyPut(() => ApiClient(
  //     appBaseUrl: AppConstants.BASE_URL, sharedPreferences: Get.find()));
  // Get.lazyPut(
  //     () => AuthRepo(apiClient: Get.find(), sharedPreferences: Get.find()));
  // Get.lazyPut(() => UserRepo(apiClient: Get.find()));
  //
  // //repos
  // Get.lazyPut(() => PopularProductRepo(apiClient: Get.find()));
  // Get.lazyPut(() => RecommendedProductRepo(apiClient: Get.find()));
  // Get.lazyPut(() => CartRepo(sharedPreferences: Get.find()));
  // Get.lazyPut(
  //     () => LocationRepo(apiClient: Get.find(), sharedPreferences: Get.find()));
  // Get.lazyPut(() => BlockingRepo(sharedPreferences: Get.find()));
  //
  // Get.lazyPut(() => OrderRepo(apiClient: Get.find()));
  // Get.lazyPut(() => AllProductRepo());
  //
  // //controller
  // Get.lazyPut(() => AuthController(authRepo: Get.find()));
  // Get.lazyPut(() => UserController(userRepo: Get.find()));
  //
  // Get.lazyPut(() => CartController(cartRepo: Get.find()));
  //
  // Get.lazyPut(() => PopularProductController(popularProductRepo: Get.find()));
  // Get.lazyPut(
  //     () => RecommendedProductController(recommendedProductRepo: Get.find()));
  //
  // Get.lazyPut(() => LocationController(
  //       locationRepo: Get.find(),
  //     ));
  // Get.lazyPut(() => OrderController(orderRepo: Get.find()));
  // Get.lazyPut(() => AllProductController(
  //     allProductRepo: Get.find(), blockingRepo: Get.find()));
}
