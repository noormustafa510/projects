import 'package:flutter/material.dart';
import 'package:flutter_beep/flutter_beep.dart';
import 'package:get/get.dart';
import 'package:pos_mobile_f/controller/scanner_controller.dart';
import 'package:pos_mobile_f/utils/dimensions.dart';
import 'package:pos_mobile_f/widgets/big_text.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return GetBuilder<ScannerController>(builder: (scannerController){
      return Scaffold(


        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            //crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              IconButton(onPressed: () async {

                await scannerController.scanBarcodeNormal();

              }, icon: Icon(Icons.scanner,size: Dimension.iconSize24*2,)),

              SizedBox(height: Dimension.height45,),
              IconButton(onPressed: () async {

                await scannerController.startBarcodeScanStream();

              }, icon: Icon(Icons.near_me,size: Dimension.iconSize24*2,)),

              SizedBox(height: Dimension.height45,),

              BigText(text: scannerController.barStreams.length.toString()),
              SizedBox(height: Dimension.height45,),


              BigText(text: scannerController.scanBarcode)
              ,


              SizedBox(height: Dimension.height45,),
              Container(height: Dimension.height45*8,

                child: ListView.builder(
                    itemCount: scannerController.barStreams.length,
                    itemBuilder: (context, index){
                      int marker =  scannerController.barStreams.length- index -1;
                      return ListTile(title: BigText(text: scannerController.barStreams[marker]),);
                    }),

                color: Colors.grey,
              )

            ],
          ),
        ),
        floatingActionButton: FloatingActionButton(onPressed: (){
          scannerController.scanBarcodeNormal();

        },child: Icon(Icons.scanner,size: Dimension.font26*1.5,),)
      );
    });
  }
}
