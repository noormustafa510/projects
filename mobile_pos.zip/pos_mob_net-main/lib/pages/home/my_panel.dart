import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:list_picker/list_picker.dart';
import 'package:pos_mobile_f/controller/panel_controller.dart';
import 'package:pos_mobile_f/pages/products/printing_class.dart';
import 'package:pos_mobile_f/utils/colors.dart';
import 'package:pos_mobile_f/utils/dimensions.dart';
import 'package:pos_mobile_f/widgets/big_text.dart';
import 'package:pos_mobile_f/widgets/final_price_widget.dart';
import 'package:pos_mobile_f/widgets/network_panel_product_tile.dart';
import 'package:pos_mobile_f/widgets/non_log_in_user.dart';
import 'package:pos_mobile_f/widgets/panel_product_tile.dart';
import 'package:pos_mobile_f/widgets/panel_text_field.dart';
import 'package:pos_mobile_f/widgets/productByCat.dart';
import 'package:pos_mobile_f/widgets/search_text_field.dart';

class MyPanel extends StatefulWidget {
  const MyPanel({super.key});

  @override
  State<MyPanel> createState() => _MyPanelState();
}

class _MyPanelState extends State<MyPanel> with TickerProviderStateMixin {
  late TabController _tabController;

  @override
  Widget build(BuildContext context) {
    Get.find<PanelController>().initializeTableList();

    return GetBuilder<PanelController>(builder: (panelController) {
      return panelController.adminPanelController.isLogIn?Scaffold(

        body: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            SizedBox(
              height: Dimension.height10,
            ),
            panelController.isSearchEnables
                ? SearchTextFieldForHome(
                    textController:
                        panelController.mainPanelSearchEditingController,
                    hintText: "Enter Product Name",
                    icon: Icons.search)
                : Container(),
            panelController.isSearchEnables
                ? Expanded(
                    child: SizedBox(
                    height: Dimension.height10 / 10,
                  ))
                : Container(),

            Expanded(
              flex: 3,
              child: Padding(
                padding: EdgeInsets.symmetric(horizontal: Dimension.width20),
                child: Container(
                  decoration:
                      BoxDecoration(color: Colors.orangeAccent, boxShadow: [
                    BoxShadow(
                        blurRadius: 3,
                        spreadRadius: 1,
                        offset: const Offset(1, 1),
                        color: Colors.orange.withOpacity(0.3))
                  ]),
                  child: Padding(
                    padding: EdgeInsets.symmetric(
                        vertical: Dimension.height10 / 2,
                        horizontal: Dimension.width10),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Expanded(
                            child: Center(
                                child: BigText(
                          text: 'Price',
                          color: Colors.white,
                        ))),
                        Expanded(
                            child: Center(
                                child:
                                    BigText(text: 'Qty', color: Colors.white))),
                        Expanded(
                            child: Center(
                                child: BigText(
                                    text: 'Disc.', color: Colors.white))),
                        Expanded(
                            child: Center(
                                child: BigText(
                                    text: 'Total', color: Colors.white))),
                      ],
                    ),
                  ),
                ),
              ),
            ),

            Expanded(
              flex: 35,
              child: Padding(
                padding: EdgeInsets.only(
                    left: Dimension.width20,
                    right: Dimension.width20,
                    top: Dimension.height10,
                    bottom: Dimension.height10 / 2),
                child: Container(
                  height: Dimension.height45 * 5,
                  decoration: BoxDecoration(color: Colors.white, boxShadow: [
                    BoxShadow(
                        blurRadius: 3,
                        spreadRadius: 1,
                        offset: Offset(1, 1),
                        color: Colors.grey.withOpacity(0.8))
                  ]),
                  child: ListView.builder(
                      itemCount: panelController
                              .productListMap[
                                  panelController.selectedTableString]
                              ?.length ??
                          0,
                      itemBuilder: (context, index) {
                        return panelController.shopDetailController.shopDetailModel.isNetwork?NetworkPanelProductTile (
                          subProductsModal: panelController.productListMap[
                          panelController.selectedTableString]![index],
                          index: index,
                        ): PanelProductTile
                          (
                          subProductsModal: panelController.productListMap[
                              panelController.selectedTableString]![index],
                          index: index,
                        );
                      }),
                ),
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                ElevatedButton(
                    onPressed: () {
                      panelController.resetHold();
                    },
                    onLongPress: () {
                      panelController.searchEnablingSetter();
                    },
                    child: Row(
                      children: [
                        BigText(
                          text: "Rst/",
                          color: Colors.white,
                        ),
                        Icon(
                          Icons.search,
                        ),
                      ],
                    )),
                ElevatedButton(
                    onPressed: () {
                      Get.snackbar(
                          "InComplete Action", 'Long Press to reset all !',
                          backgroundColor: Colors.redAccent,
                          maxWidth: Dimension.width30 * 22,
                          colorText: Colors.white);
                    },
                    onLongPress: () {
                      panelController.resetAll();
                    },
                    child: BigText(
                      text: "Rst All",
                      color: Colors.white,
                    )),
                ElevatedButton(
                    onPressed: () {
                      panelController.addHold();
                    },
                    onLongPress: () {
                      panelController.deleteHolds();
                    },
                    child: Row(
                      children: [
                        Icon(Icons.add),
                        BigText(
                          text: "/",
                          color: Colors.white,
                        ),
                        Icon(Icons.delete),
                        BigText(
                          text: "Holds",
                          color: Colors.white,
                        )
                      ],
                    )),
              ],
            ),
            SizedBox(
              height: Dimension.height10 / 10,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Expanded(
                  child: Column(
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: PanelTextField(
                              textController:
                                  panelController.wDiscountEditingController,
                              hintText: "Disc.",
                              icon: Icons.discount,
                              isNumber: true,
                              onSubmit: (value) {
                                panelController.restProductDetailSetter(
                                    panelController.productListMap[
                                            panelController
                                                .selectedTableString] ??
                                        []);
                                panelController.update();
                              },
                            ),
                          ),
                          Expanded(
                            child: PanelTextField(
                                textController:
                                    panelController.balanceEditingController,
                                isNumber: true,
                                hintText: "A.R.",
                                icon: Icons.account_balance_wallet_rounded,
                                onSubmit: (value) {
                                  panelController.restProductDetailSetter(
                                      panelController.productListMap[
                                              panelController
                                                  .selectedTableString] ??
                                          []);
                                  panelController.update();
                                }),
                          )
                        ],
                      ),
                      SizedBox(
                        height: Dimension.height10,
                      ),
                      PanelTextField(
                          textController:
                              panelController.remarksEditingController,
                          hintText: "Enter Remark",
                          icon: Icons.abc,
                          onSubmit: (value) {}),
                    ],
                  ),
                ),
                Padding(
                  padding: EdgeInsets.only(right: Dimension.width10),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      ElevatedButton(
                        onPressed: () async {
                          await panelController.startBarcodeScanStream();
                        },
                        style: ButtonStyle(
                            backgroundColor:
                                MaterialStateProperty.all(Colors.orangeAccent),
                           ),
                        child: Container(
                          width: Dimension.width30*6,
                          child: Center(
                            child: Icon(
                              Icons.barcode_reader,
                              size: Dimension.iconSize24 * 2,
                              color: AppColors.mainColor,
                            ),
                          ),
                        ),
                      ),
                      SizedBox(
                        height: Dimension.height10,
                      ),
                      ElevatedButton(
                        onLongPress: () async {
                          panelController.shopDetailController.shopDetailModel.isNetwork? await panelController.printKPlusModule(true):
                          await panelController.printModule(false);
                        },
                        onPressed: () async {


                          if (!panelController.thermalConnection && !panelController.usbThermalConnection && !panelController.shopDetailController.shopDetailModel.isNetwork) {
                            await Get.to(() => MyPrintApp());
                          }

                          print("main is here");

                          if (panelController.thermalConnection || panelController.usbThermalConnection || panelController.shopDetailController.shopDetailModel.isNetwork) {
                            print("main is here2");
                            await panelController.printModule(true);
                          }
                        },
                        style: const ButtonStyle(),
                        child: Container(

                          width: Dimension.width30*6,
                          child: Center(
                            child: Icon(
                              Icons.print,
                              size: Dimension.iconSize24 * 3,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                )
              ],
            ),
            //floatingHeight
            // SizedBox(height: Dimension.height10/3,),

            SizedBox(height: Dimension.height10,),

            Row(
              children: [
                Padding(
                  padding: EdgeInsets.only(
                      left: Dimension.width20, right: Dimension.width10),
                  child: Container(
                    height: Dimension.height45 * 1.2,
                    width: Dimension.width30 * 8,
                    decoration: BoxDecoration(
                        color: AppColors.mainColor,
                        borderRadius:
                            BorderRadius.circular(Dimension.radius15)),
                    child: Center(
                        child: Column(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        BigText(
                          text: 'Balance',
                          color: Colors.orangeAccent,
                          size: Dimension.font16,
                        ),
                        BigText(
                          text: (panelController
                                      .restProductDetailsMap[
                                          panelController.selectedTableString]
                                      ?.balance ??
                                  0)
                              .toString(),
                          color: Colors.white,
                        ),
                      ],
                    )),
                  ),
                ),
                Expanded(
                  child: ElevatedButton(
                      style: ButtonStyle(
                          backgroundColor:
                              MaterialStateProperty.all(Colors.orangeAccent),
                          padding: MaterialStateProperty.all(
                              EdgeInsets.symmetric(
                                  horizontal: Dimension.width10,
                                  vertical: Dimension.height10 * 0.85))),
                      onPressed: () async {
                        String? item = await showPickerDialog(
                          context: context,
                          label: "Table",
                          items: panelController.tableList,
                        );
                        print("Length:" +
                            panelController.tableList.length.toString());
                        if (item != null) {
                          panelController.selectedTableString = item;
                          panelController.balanceEditingController.text = '';
                          panelController.update();
                        }
                      },
                      child: Column(
                        children: [
                          Row(
                            children: [
                              Expanded(
                                  child: Center(
                                      child: BigText(
                                text: panelController.selectedTableString,
                                color: Colors.white,
                                size: Dimension.font16 * 0.8,
                              ))),
                            ],
                          ),
                          Row(
                            children: [
                              BigText(
                                text: panelController.shopDetailController.shopDetailModel.currency,
                                size: Dimension.font16,
                                color: Colors.white,
                              ),
                              Expanded(
                                  child: BigText(
                                text: panelController
                                        .restProductDetailsMap[
                                            panelController.selectedTableString]
                                        ?.totalSale
                                        .toString() ??
                                    0.toString(),
                                size: Dimension.font26*0.8,
                                color: AppColors.mainColor,
                              ))
                            ],
                          ),
                        ],
                      )),
                ),
            SizedBox(width: Dimension.width20,),
            Padding(
              padding:  EdgeInsets.only(right: Dimension.width10),
              child: ElevatedButton(

                style: ButtonStyle(

                    // padding: MaterialStateProperty.all(
                    //     EdgeInsets.symmetric(
                    //         horizontal: Dimension.width10,
                    //         vertical: Dimension.height10 * 0.5))


                ),
                    onPressed: () {
                      panelController.productController.productsListByCategoryProducer();

                      _tabController = TabController(
                          length: panelController.productController.categoriesList.length,
                          vsync: this);
                      showModalBottomSheet(
                          isScrollControlled: true,
                          backgroundColor: Colors.transparent,
                          context: context,
                          builder: (_) {
                            return FractionallySizedBox(
                              heightFactor: 0.8,
                              child: Column(
                                children: [
                                  Expanded(
                                    child: Container(
                                      height: Dimension.height45 * 10,
                                      decoration: BoxDecoration(
                                        color: Colors.white,
                                        borderRadius: BorderRadius.only(
                                          topLeft: Radius.circular(Dimension.radius20),
                                          topRight: Radius.circular(Dimension.radius20),
                                        ),
                                      ),
                                      child: Column(
                                        children: [
                                          Row(
                                            mainAxisAlignment: MainAxisAlignment.start,
                                            children: [
                                              Expanded(
                                                child: Column(
                                                  children: [
                                                    SizedBox(
                                                      height: Dimension.height10,
                                                    ),
                                                    TextButton(
                                                      onPressed: (){
                                                        panelController.resetHold();
                                                      },
                                                      child: Center(
                                                        child: BigText(
                                                          text: "Categories",
                                                          color: AppColors.mainColor,
                                                          size: Dimension.font26 * 1.5,
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                              TextButton(
                                                style: ButtonStyle(
                                                    backgroundColor: MaterialStateProperty.all(Colors.transparent)
                                                ),

                                                onLongPress: () async {
                                                  panelController.shopDetailController.shopDetailModel.isNetwork? await panelController.printKPlusModule(true):
                                                  await panelController.printModule(false);
                                                },

                                                onPressed: () async {

                                                  //print("Main Print");
                                                  if (!panelController.thermalConnection && !panelController.usbThermalConnection && !panelController.shopDetailController.shopDetailModel.isNetwork) {
                                                    await Get.to(() => MyPrintApp());
                                                  }

                                                  if (panelController.thermalConnection || panelController.usbThermalConnection|| panelController.shopDetailController.shopDetailModel.isNetwork) {
                                                    await panelController.printModule(true);
                                                  }
                                                },
                                                child: Icon(
                                                  Icons.print,
                                                  color: AppColors.mainColor,
                                                  size: Dimension.iconSize24 * 3,
                                                ),
                                              ),
                                              SizedBox(
                                                width: Dimension.width30 * 2,
                                              ),
                                            ],
                                          ),
                                          FinalPriceWidget(),
                                          SizedBox(
                                            height: Dimension.height10,
                                          ),
                                          TabBar(
                                              indicatorColor: AppColors.yellowColor,
                                              indicatorSize: TabBarIndicatorSize.label,
                                              labelStyle: TextStyle(
                                                  fontSize: Dimension.font20 * 0.85),
                                              dividerColor: Colors.yellow,
                                              labelColor: AppColors.yellowColor,
                                              unselectedLabelColor: Colors.grey,
                                              isScrollable: true,
                                              controller: _tabController,
                                              tabs: List.generate(
                                                  panelController.productController
                                                      .categoriesList.length, (index) {
                                                String title = panelController
                                                    .productController
                                                    .categoriesList[index]
                                                    .categoryName;

                                                return Tab(
                                                  text: title,
                                                );
                                              })),
                                          Expanded(
                                              child: TabBarView(
                                                  controller: _tabController,
                                                  children: List.generate(
                                                      panelController.productController
                                                          .categoriesList.length,
                                                          (index) => ProductByCat(
                                                          productsList: panelController
                                                              .productController
                                                              .productsListByCategory[
                                                          panelController
                                                              .productController
                                                              .categoriesList[index]
                                                              .categoryName]!)))),
                                          SizedBox(height: Dimension.height10,)

                                          // ProductByCat(productsList:
                                          // productController.productsListByCategory[productController.categoriesList[index]]!
                                          // )
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            );
                          });
                    },
                    child: Padding(
                      padding:  EdgeInsets.symmetric(vertical: Dimension.height10*0.5),
                      child: Container(
                        width: Dimension.width30*6,
                        child: Icon(
                          Icons.padding,
                          color: Colors.white,
                          size: Dimension.iconSize24 * 2,
                        ),
                      ),
                    ),
                  ),
            ),

              ],
            ),
            SizedBox(
              height: Dimension.height10,
            )
          ],
        ),
      ):NonLogInUserWidget();
    });
  }
}
