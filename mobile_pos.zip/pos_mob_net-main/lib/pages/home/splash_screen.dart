import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:hive/hive.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:pos_mobile_f/controller/admin_panel_controller.dart';
import 'package:pos_mobile_f/controller/back_up_controller.dart';
import 'package:pos_mobile_f/controller/limit_controller.dart';
import 'package:pos_mobile_f/controller/panel_controller.dart';
import 'package:pos_mobile_f/controller/product_controller.dart';
import 'package:pos_mobile_f/controller/shop_detail_controller.dart';
import 'package:pos_mobile_f/main.dart';
import 'package:pos_mobile_f/pages/home/home_page.dart';
import 'package:pos_mobile_f/utils/app_constants.dart';
import 'package:pos_mobile_f/utils/dimensions.dart';
import '../../helper/dependencies.dart' as dep;
import 'my_drawer.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}



class _SplashScreenState extends State<SplashScreen> {



  @override
  void initState() {
    // TODO: implement initState
    super.initState();



  Future.delayed(Duration(seconds: 1), () async {
    await dep.init();
    await hiveBoxOpener();

    Get.off(()=>const MyDrawer());
  } );



  }

  hiveBoxOpener() async {



    await Hive.initFlutter();
    Get.find<PanelController>().initializeCurrentDateTime();

    categoryBoxPointer = await Hive.openBox<String>(AppConstants.categoryBox,);
    productBoxPointer = await Hive.openBox<String>(AppConstants.productBox);
    tableBoxPointer = await Hive.openBox<String>(AppConstants.tableBox);
    resNameBoxPointer = await Hive.openBox<String>(AppConstants.resNameBox);

    resIdBoxPointer = await Hive.openBox<String>(AppConstants.resIDBox, encryptionCipher
        : HiveAesCipher(base64Decode(AppConstants.idEncryptionKey).map((e) => e).toList()..removeLast()));
    setDateTimeBoxPointer = await Hive.openBox<String>(AppConstants.setDateTimeBox, encryptionCipher
        : HiveAesCipher(base64Decode(AppConstants.dateTimeEncryptionKey).map((e) => e).toList()..removeLast()));
    saleSaveBoxPointer = await Hive.openLazyBox<String>(Get.find<PanelController>().currentDateTimeStr);
    saleTotalListPointer = await Hive.openBox<double>(AppConstants.saleTotalListBox);
    invoiceNumberPointer = await Hive.openBox<int>(AppConstants.invoiceNumberBox);
    shopDetailPointer = await Hive.openBox<String>(AppConstants.shopDetailBox);
    triedLimitPointer = await Hive.openBox<int>(AppConstants.triedLimitsBox);
    usedMonthPointer = await Hive.openBox<int>(AppConstants.usedMonthBox);
    usedYearPointer = await Hive.openBox<int>(AppConstants.usedYearBox);
    backUpKeyPointer = await Hive.openBox<String>(AppConstants.backUpKeyBox);
    fireListCheckPointer = await Hive.openBox<String>(AppConstants.fireListCheckBox);
    storeBackUpSingleKeyPointer = await Hive.openBox<String>(AppConstants.storeBackUpSingleKeyBox);
    pushBackUpDatePointer = await Hive.openBox<String>(AppConstants.pushBackUpDateBox);
    pullBackUpDatePointer = await Hive.openBox<String>(AppConstants.pullBackUpDateBox);
    returnDataPointer = await Hive.openBox<String>(AppConstants.returnDataBox);
    discountDataPointer = await Hive.openBox<String>(AppConstants.discountDataBox);
    usersListPointer = await Hive.openBox<String>(AppConstants.usersListBox);
    wrongAttemptPointer = await Hive.openBox<int>(AppConstants.wrongAttemptBox);
    lastBarCodeGenPointer = await Hive.openBox<String>(AppConstants.lastBarCodeGenBox);


    await Get.find<ProductController>().initializingProductList();
    await Get.find<ProductController>().initializingCategoriesList();
    await Get.find<ProductController>().initializingTableList();
   await Get.find<PanelController>().initializingRestaurantName();
   await Get.find<PanelController>().initializingUsedMonthAndYear();
  await  Get.find<ShopDetailController>().shopDetailsInitialization();
  await  Get.find<LimitController>().initializeNotification();
  await Get.find<BackUpController>().initializedDB();
   Get.find<AdminPanelController>().initializeUserList();
   Get.find<AdminPanelController>().initializingWrongInputs();




  }

  @override



  Widget build(BuildContext context) {
    return Scaffold(body: Center(
      child: Icon(Icons.print, color: Colors.blueGrey, size: MediaQuery.of(context).size.width*0.6,) ,
    ),);
  }
}
