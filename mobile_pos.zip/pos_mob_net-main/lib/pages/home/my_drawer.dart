import 'package:flutter/material.dart';
import 'package:flutter_advanced_drawer/flutter_advanced_drawer.dart';
import 'package:get/get.dart';
import 'package:pos_mobile_f/controller/admin_panel_controller.dart';
import 'package:pos_mobile_f/pages/account/accounts.dart';
import 'package:pos_mobile_f/pages/account/shop_details.dart';
import 'package:pos_mobile_f/pages/back-up/pull_backup.dart';
import 'package:pos_mobile_f/pages/back-up/push_backup.dart';
import 'package:pos_mobile_f/pages/history/history_page.dart';
import 'package:pos_mobile_f/pages/home/home_page.dart';
import 'package:pos_mobile_f/pages/home/my_panel.dart';
import 'package:pos_mobile_f/pages/products/admin_panel.dart';
import 'package:pos_mobile_f/pages/products/barcode_generator.dart';
import 'package:pos_mobile_f/pages/products/discount_products.dart';
import 'package:pos_mobile_f/pages/products/limit_notifier.dart';
import 'package:pos_mobile_f/pages/products/log_in.dart';
import 'package:pos_mobile_f/pages/products/my_categories.dart';
import 'package:pos_mobile_f/pages/products/my_tables.dart';
import 'package:pos_mobile_f/pages/products/products.dart';
import 'package:pos_mobile_f/pages/products/return_products.dart';
import 'package:pos_mobile_f/pages/products/test_screen.dart';
import 'package:pos_mobile_f/utils/dimensions.dart';

class MyDrawer extends StatefulWidget {
  const MyDrawer({super.key});

  @override
  // ignore: library_private_types_in_public_api
  _MyDrawerState createState() => _MyDrawerState();
}

class _MyDrawerState extends State<MyDrawer> {
  final _advancedDrawerController = AdvancedDrawerController();
//  int adminPanelController.marker = 0;

  @override
  Widget build(BuildContext context) {
    return GetBuilder<AdminPanelController>(builder: (adminPanelController) {
      return AdvancedDrawer(
        backdrop: Container(
          width: double.infinity,
          height: double.infinity,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [Colors.blueGrey, Colors.blueGrey.withOpacity(0.2)],
            ),
          ),
        ),

        controller: _advancedDrawerController,
        animationCurve: Curves.easeInOut,
        animationDuration: const Duration(milliseconds: 300),
        animateChildDecoration: true,

        rtlOpening: false,
        // openScale: 1.0,
        disabledGestures: false,
        childDecoration: const BoxDecoration(
          // NOTICE: Uncomment if you want to add shadow behind the page.
          // Keep in mind that it may cause animation jerks.
          // boxShadow: <BoxShadow>[
          //   BoxShadow(
          //     color: Colors.black12,
          //     blurRadius: 0.0,
          //   ),
          // ],
          borderRadius: BorderRadius.all(Radius.circular(16)),
        ),
        drawer: SafeArea(
          child: ListTileTheme(
            textColor: Colors.white,
            iconColor: Colors.white,
            child: Container(
              height: Dimension.screenHeight,
              child: Column(
                mainAxisSize: MainAxisSize.max,
                children: [
                  SizedBox(
                    height: Dimension.height45 * 1.4,
                  ),
                  Expanded(
                    child: Row(
                      children: [
                        Expanded(
                            child: Image.asset(
                          'assets/images/nBLogo.png',
                        )),
                      ],
                    ),
                  ),
                  SizedBox(height: Dimension.height45 * 0.9),
                  Container(
                    height: Dimension.screenHeight * 0.72,
                    child: SingleChildScrollView(
                      child: Column(
                        children: [
                          ListTile(
                            onTap: () {
                              setState(() {
                                adminPanelController.marker = 0;
                                _advancedDrawerController.value =
                                    AdvancedDrawerValue.hidden();
                              });
                            },
                            leading: const Icon(Icons.login),
                            title: const Text('LogIn Page'),
                          ),
                          ListTile(
                            onTap: () {
                              setState(() {
                                adminPanelController.marker = 1;
                                _advancedDrawerController.value =
                                    AdvancedDrawerValue.hidden();
                              });
                            },
                            leading: const Icon(Icons.home),
                            title: const Text('Panel'),
                          ),
                          ListTile(
                            onTap: () {
                              setState(() {
                                adminPanelController.marker = 2;
                                _advancedDrawerController.value =
                                    AdvancedDrawerValue.hidden();
                              });
                            },
                            leading: const Icon(Icons.add_box_sharp),
                            title: const Text('Products'),
                          ),
                          ListTile(
                            onTap: () {
                              setState(() {
                                adminPanelController.marker = 3;
                                _advancedDrawerController.value =
                                    AdvancedDrawerValue.hidden();
                              });
                            },
                            leading: const Icon(Icons.warning),
                            title: const Text('Warning Page'),
                          ),
                          ListTile(
                            onTap: () {
                              setState(() {
                                adminPanelController.marker = 4;
                                _advancedDrawerController.value =
                                    AdvancedDrawerValue.hidden();
                              });
                            },
                            leading: const Icon(Icons.category),
                            title: const Text('Category'),
                          ),
                          ListTile(
                            onTap: () {
                              setState(() {
                                adminPanelController.marker = 5;
                                _advancedDrawerController.value =
                                    AdvancedDrawerValue.hidden();
                              });
                            },
                            leading: const Icon(Icons.table_bar),
                            title: const Text('Table'),
                          ),
                          ListTile(
                            onTap: () {
                              setState(() {
                                adminPanelController.marker = 6;
                                _advancedDrawerController.value =
                                    AdvancedDrawerValue.hidden();
                              });
                            },
                            leading: const Icon(Icons.shop),
                            title: const Text('Shop Detail'),
                          ),
                          ListTile(
                            onTap: () {
                              setState(() {
                                adminPanelController.marker = 7;
                                _advancedDrawerController.value =
                                    AdvancedDrawerValue.hidden();
                              });
                            },
                            leading: const Icon(Icons.history),
                            title: const Text('History'),
                          ),
                          ListTile(
                            onTap: () {
                              setState(() {
                                adminPanelController.marker = 8;
                                _advancedDrawerController.value =
                                    AdvancedDrawerValue.hidden();
                              });
                            },
                            leading: const Icon(Icons.assignment_return),
                            title: const Text('Return Products'),
                          ),
                          ListTile(
                            onTap: () {
                              setState(() {
                                adminPanelController.marker = 9;
                                _advancedDrawerController.value =
                                    AdvancedDrawerValue.hidden();
                              });
                            },
                            leading: const Icon(Icons.discount),
                            title: const Text('Discounted Products'),
                          ),
                          ListTile(
                            onTap: () {
                              setState(() {
                                adminPanelController.marker = 10;
                                _advancedDrawerController.value =
                                    AdvancedDrawerValue.hidden();
                              });
                            },
                            leading: const Icon(Icons.barcode_reader),
                            title: const Text('Barcode Print'),
                          ),
                          ListTile(
                            onTap: () {
                              setState(() {
                                adminPanelController.marker = 11;
                                _advancedDrawerController.value =
                                    AdvancedDrawerValue.hidden();
                              });
                            },
                            leading: const Icon(Icons.admin_panel_settings),
                            title: const Text('Admin Page'),
                          ),
                          ListTile(
                            onTap: () {
                              setState(() {
                                adminPanelController.marker = 12;
                                _advancedDrawerController.value =
                                    AdvancedDrawerValue.hidden();
                              });
                            },
                            leading: const Icon(Icons.account_box),
                            title: const Text('Account'),
                          ),
                          ListTile(
                            onTap: () {
                              setState(() {
                                adminPanelController.marker = 13;
                                _advancedDrawerController.value =
                                    AdvancedDrawerValue.hidden();
                              });
                            },
                            leading: const Icon(Icons.backup_outlined),
                            title: const Text('Take BackUp'),
                          ),
                          ListTile(
                            onTap: () {
                              setState(() {
                                adminPanelController.marker = 14;
                                _advancedDrawerController.value =
                                    AdvancedDrawerValue.hidden();
                              });
                            },
                            leading: const Icon(Icons.ac_unit_sharp),
                            title: const Text('Get Products'),
                          ),
                          SizedBox(
                            height: Dimension.height45,
                          ),
                        ],
                      ),
                    ),
                  )

                  // const Spacer(),
                  // DefaultTextStyle(
                  //   style: TextStyle(
                  //     fontSize: 12,
                  //     color: Colors.white54,
                  //   ),
                  //   child: Container(
                  //     margin: const EdgeInsets.symmetric(
                  //       vertical: 16.0,
                  //     ),
                  //     child: Text('Terms of Service | Privacy Policy'),
                  //   ),
                  // ),
                ],
              ),
            ),
          ),
        ),
        child: Scaffold(
          appBar: AppBar(
            backgroundColor: Colors.blueGrey,
            title: Text(barName[adminPanelController.marker]),
            leading: IconButton(
              onPressed: _handleMenuButtonPressed,
              icon: ValueListenableBuilder<AdvancedDrawerValue>(
                valueListenable: _advancedDrawerController,
                builder: (_, value, __) {
                  return AnimatedSwitcher(
                    duration: const Duration(milliseconds: 250),
                    child: Icon(
                      value.visible ? Icons.clear : Icons.menu,
                      key: ValueKey<bool>(value.visible),
                    ),
                  );
                },
              ),
            ),
          ),
          body: widgetList[adminPanelController.marker],
        ),
      );
    });
  }

  void _handleMenuButtonPressed() {
    // NOTICE: Manage Advanced Drawer state through the Controller.

    _advancedDrawerController.showDrawer();
  }

  List<String> barName = [
    'LogIn Page',
    'Panel',
    'Manage Products',
    'Warning Page',
    'Manage Categories',
    'Manage Tables',
    'Edit Shop Details',
    'History Page',
    'Return Products',
    'Discounted Products',
    'Barcode Print',
    'Admin Page',
    'Account Section',
    'Take BackUp',
    'Get Products',
  ];
  List<Widget> widgetList = [


    //TestScreen(),

    LogInPage(),

    const MyPanel(),
    const Products(),
    const LimitNotifier(),

    const MyCategories(),
    const MyTables(),
     ShopDetail(),

    HistoryPage(),
    ReturnProducts(),
   DiscountProducts(),
    BarcodeGenerator(),
    AdminPanel(),
    Accounts(),
    PushBackup(),

    PullBackup(),

    // Accounts(),

//    MyCategories(),
    //HomePage(),
    //HomePage(),
    // Container(),
  ];
}
