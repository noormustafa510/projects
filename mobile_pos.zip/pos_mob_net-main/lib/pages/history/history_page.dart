import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:list_picker/list_picker.dart';
import 'package:pos_mobile_f/controller/history_controller.dart';
import 'package:pos_mobile_f/controller/panel_controller.dart';
import 'package:pos_mobile_f/modal/day_sale_list_modal.dart';
import 'package:pos_mobile_f/modal/sold_products_list_modal.dart';
import 'package:pos_mobile_f/utils/colors.dart';
import 'package:pos_mobile_f/utils/constants.dart';
import 'package:pos_mobile_f/utils/dimensions.dart';
import 'package:pos_mobile_f/widgets/big_text.dart';
import 'package:pos_mobile_f/widgets/history_invoice_tile.dart';
import 'package:pos_mobile_f/widgets/non_active_account_widget.dart';
import 'package:pos_mobile_f/widgets/non_log_in_user.dart';

class HistoryPage extends StatelessWidget {
   HistoryPage({super.key});


  String day = DateTime.now().day.toString();
  String month = DateTime.now().month.toString();
  String year = DateTime.now().year.toString();
   String dayT = DateTime.now().day.toString();
   String monthT = DateTime.now().month.toString();
   String yearT = DateTime.now().year.toString();
   String hour1 = '0';
   String hour2 = '23';
  @override
  Widget build(BuildContext context) {
    Get.find<HistoryController>().initiateTbAndUserList();

    return Scaffold(
      body: GetBuilder<HistoryController>(builder: (historyController){

        return  Get.find<PanelController>().isAccountActive? historyController.adminPanelController.isAdminLogIn?
        Stack(
          children: [SingleChildScrollView(



            child: Column(
              children: [

                SizedBox(height: Dimension.height20,),

                historyController.isExpanded? Column(children: [
                  Padding(
                    padding: EdgeInsets.symmetric(
                        horizontal: Dimension.width30 * 3, vertical: 0),
                    child: Row(
                      children: [
                        Expanded(
                          flex: 2,
                          child: DropdownButton(
                              value: historyController.dayListIndex,
                              isExpanded: true,
                              items: List.generate(
                                  dayList.length,
                                      (index) => DropdownMenuItem(
                                      value: dayList[index],
                                      child: BigText(
                                          text: dayList[index].toString()))),
                              onChanged: (value) {
                                historyController.dayListIndex = value ?? 0;
                                day = historyController.dayListIndex.toString();

                                historyController.update();
                              }),
                        ),
                        SizedBox(
                          width: Dimension.width30 * 2,
                        ),

                        Expanded(
                          flex: 2,
                          child: DropdownButton(
                              value: historyController.monthListIndex,
                              isExpanded: true,
                              items: List.generate(
                                  monthList.length,
                                      (index) => DropdownMenuItem(
                                      value: monthList[index],
                                      child: BigText(
                                          text: monthList[index].toString()))),
                              onChanged: (value) {
                                historyController.monthListIndex = value ?? 0;
                                month = historyController.monthListIndex.toString();

                                historyController.update();
                              }),
                        ),
                        SizedBox(
                          width: Dimension.width30 * 2,
                        ),
                        Expanded(
                          flex: 3,
                          child: DropdownButton(
                              value: historyController.yearListIndex,
                              isExpanded: true,
                              items: List.generate(
                                  yearList.length,
                                      (index) => DropdownMenuItem(
                                      value: yearList[index],
                                      child: BigText(
                                          text: yearList[index].toString()))),
                              onChanged: (value) {
                                historyController.yearListIndex = value ?? 0;
                                year = historyController.yearListIndex.toString();

                                historyController.update();
                              }),
                        ),
                      ],
                    ),
                  ),
                  BigText(text: "To", color: Colors.green,size: Dimension.font16,),

                  Padding(
                    padding: EdgeInsets.symmetric(
                        horizontal: Dimension.width30 * 3, vertical: 0),
                    child: Row(
                      children: [
                        Expanded(
                          flex: 2,
                          child: DropdownButton(
                              value: historyController.dayTListIndex,
                              isExpanded: true,
                              items: List.generate(
                                  dayList.length,
                                      (index) => DropdownMenuItem(
                                      value: dayList[index],
                                      child: BigText(
                                          text: dayList[index].toString()))),
                              onChanged: (value) {
                                historyController.dayTListIndex = value ?? 0;
                                dayT = historyController.dayTListIndex.toString();

                                historyController.update();
                              }),
                        ),
                        SizedBox(
                          width: Dimension.width30 * 2,
                        ),

                        Expanded(
                          flex: 2,
                          child: DropdownButton(
                              value: historyController.monthTListIndex,
                              isExpanded: true,
                              items: List.generate(
                                  monthList.length,
                                      (index) => DropdownMenuItem(
                                      value: monthList[index],
                                      child: BigText(
                                          text: monthList[index].toString()))),
                              onChanged: (value) {
                                historyController.monthTListIndex = value ?? 0;
                                monthT = historyController.monthTListIndex.toString();

                                historyController.update();
                              }),
                        ),
                        SizedBox(
                          width: Dimension.width30 * 2,
                        ),
                        Expanded(
                          flex: 3,
                          child: DropdownButton(
                              value: historyController.yearTListIndex,
                              isExpanded: true,
                              items: List.generate(
                                  yearList.length,
                                      (index) => DropdownMenuItem(
                                      value: yearList[index],
                                      child: BigText(
                                          text: yearList[index].toString()))),
                              onChanged: (value) {
                                historyController.yearTListIndex = value ?? 0;
                                yearT = historyController.yearTListIndex.toString();

                                historyController.update();
                              }),
                        ),
                      ],
                    ),
                  ),

                  Padding(
                    padding: EdgeInsets.symmetric(
                        horizontal: Dimension.width30 * 3, vertical: 0),
                    child: Row(
                      children: [
                        BigText(text: "Hour:", color: Colors.grey,),
                        SizedBox(
                          width: Dimension.width30 * 2,
                        ),
                        Expanded(
                          flex: 2,
                          child: DropdownButton(
                              value: historyController.hour1H,

                              isExpanded: true,
                              items: List.generate(
                                  hourList.length,
                                      (index) => DropdownMenuItem(
                                      value: hourList[index],
                                      child: BigText(
                                          text: hourList[index].toString()))),
                              onChanged: (value) {

                                historyController.hour1H = value ?? 0;
                                hour1 = value.toString();


                                historyController.update();
                              }),
                        ),
                        SizedBox(
                          width: Dimension.width30 * 2,
                        ),
                        Expanded(
                          flex: 2,
                          child: DropdownButton(
                              value: historyController.hour2H,

                              isExpanded: true,
                              items: List.generate(
                                  hourList.length,
                                      (index) => DropdownMenuItem(
                                      value: hourList[index],
                                      child: BigText(
                                          text: hourList[index].toString()))),
                              onChanged: (value) {
                                historyController.hour2H = value ?? 0;
                                hour2 = value.toString();

                                historyController.update();
                              }),
                        ),
                      ],
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.symmetric(
                        horizontal: Dimension.width30 * 3, vertical: 0),
                    child: Row(
                      children: [
                        Expanded(

                          child: DropdownButton(
                              value: historyController.userListForHisIndex,
                              isExpanded: true,
                              items: List.generate(
                                  historyController.userListForHis.length,
                                      (index) => DropdownMenuItem(
                                      value: historyController.userListForHis[index],
                                      child: BigText(
                                          text: historyController.userListForHis[index].toString()))),
                              onChanged: (value) {
                                historyController.userListForHisIndex  = value?? 'All';
                                //day = historyController.dayListIndex.toString();

                                historyController.update();
                              }),
                        ),





                      ],
                    ),
                  ),
                  // Padding(
                  //   padding: EdgeInsets.symmetric(
                  //       horizontal: Dimension.width30 * 3, vertical: 0),
                  //   child: Row(
                  //     children: [
                  //       Expanded(
                  //
                  //         child: DropdownButton(
                  //             value: historyController.tbListIndex,
                  //             isExpanded: true,
                  //             items: List.generate(
                  //                 historyController.tbList.length,
                  //                     (index) => DropdownMenuItem(
                  //                     value: historyController.tbList[index],
                  //                     child: BigText(
                  //                         text: historyController.tbList[index].toString()))),
                  //             onChanged: (value) {
                  //               historyController.tbListIndex = value ?? 'All';
                  //               //month = historyController.monthListIndex.toString();
                  //
                  //               historyController.update();
                  //             }),
                  //       ),
                  //
                  //
                  //
                  //
                  //
                  //     ],
                  //   ),
                  // ),
                  TextButton(onPressed: () async {
                    String? item = await showPickerDialog(
                      context: context,
                      label: "Party",
                      items:historyController.tbList,
                    );
                    // print("Length:" +
                    //     panelController.tableList.length.toString());
                    if (item != null) {
                      historyController.tbListIndex = item;
                      historyController.update();
                      //panelController.selectedTableString = item;
                      //panelController.balanceEditingController.text = '';
                      //panelController.update();
                    }
                  }, child: BigText(text: historyController.tbListIndex, color: Colors.blue, size: Dimension.font26, )),
                ],):Container(),

                IconButton(onPressed: (){
                  historyController.setExpandingMode(!historyController.isExpanded);
                }, icon: Icon(historyController.isExpanded?CupertinoIcons.up_arrow:CupertinoIcons.down_arrow, size: Dimension.iconSize24*2, color: !historyController.isExpanded?Colors.green:Colors.red,)),

                SizedBox(height: Dimension.height10/2,),
                Row(
                  children: [

                    Expanded(child: TextButton(
                        onPressed: (){


                      showModalBottomSheet
                        (
                          isScrollControlled: true,
                          backgroundColor: Colors.transparent,
                          context: context,
                          builder: (_) {
                            return FractionallySizedBox(
                              heightFactor: 0.8,
                              child: Column(
                                children: [
                                  Expanded(
                                    child: Container(
                                      height: Dimension.height45 * 10,
                                      decoration: BoxDecoration(
                                        color: Colors.white,
                                        borderRadius: BorderRadius.only(
                                          topLeft: Radius.circular(Dimension.radius20),
                                          topRight: Radius.circular(Dimension.radius20),
                                        ),
                                      ),
                                      child: Column(
                                          children: [

                                            SizedBox(height: Dimension.height20,),

                                            Row(
                                              mainAxisAlignment: MainAxisAlignment.center,
                                              children: [
                                                BigText(text: "Date:  ", color: Colors.orangeAccent, size: Dimension.font26, )
                                                ,
                                                BigText(text: historyController.dateForModalSheet + '-' +historyController.dateTForModalSheet, color: AppColors.mainColor, size: Dimension.font26,)
                                              ],),

                                            SizedBox(height: Dimension.height10,),
                                            Divider(thickness: Dimension.height10/4, indent: Dimension.width30*5, endIndent: Dimension.width30*5,),

                                            Padding(
                                              padding:  EdgeInsets.symmetric(horizontal: Dimension.width20),
                                              child: SizedBox(
                                                height: Dimension.height45*3,
                                                child: Column(
                                                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                                                  children: [
                                                    Row(children: [
                                                      BigText(text: "No. of Invoices: ", color: Colors.grey, size: Dimension.font26,),
                                                      Expanded(child: BigText(text: historyController.salesCounter.toString(), color: Colors.black, size: Dimension.font26,))
                                                    ],),
                                                    Row(children: [
                                                      BigText(text: "Total Sale: ", color: Colors.grey, size: Dimension.font26,),
                                                      Expanded(child: BigText(text: Get.find<PanelController>().myDoubleRounder(historyController.sale, 3), color: Colors.black, size: Dimension.font26,))
                                                    ],),
                                                    Row(children: [
                                                      BigText(text: "Profit: ", color: Colors.grey, size: Dimension.font26,),
                                                      Expanded(child: BigText(text: Get.find<PanelController>().myDoubleRounder(historyController.profit, 3), color: Colors.black, size: Dimension.font26,))
                                                    ],),
                                                  ],
                                                ),
                                              ),
                                            ),
                                            SizedBox(height: Dimension.height10,),
                                            Divider(thickness: Dimension.height10/4, indent: Dimension.width30*5, endIndent: Dimension.width30*5,),

                                            Row(children: [
                                              Expanded(child: TextButton(
                                                  onPressed: (){
                                                    historyController.reverseList();
                                                  },
                                                  child: Center(child: BigText(text: "Sold Products - " + historyController.soldProductCounter.toString(), color: Colors.orangeAccent, size: Dimension.font26, ))))
                                            ],),
                                            SizedBox(height: Dimension.height20,),

                                            GetBuilder<HistoryController>(builder: (hisC){
                                              return Expanded(child: ListView.builder(
                                                  itemCount:  historyController.soldProductsList.length,
                                                  itemBuilder: (context, index){
                                                    SoldProductListModal object = hisC.soldProductsList[index];
                                                    return Padding(
                                                      padding:  EdgeInsets.symmetric(horizontal: Dimension.width30, vertical: Dimension.height10/2),
                                                      child: Container(
                                                        decoration: BoxDecoration(
                                                            color: Colors.white,
                                                            boxShadow: [
                                                              BoxShadow(
                                                                  blurRadius: 3,
                                                                  spreadRadius: 1,
                                                                  offset: const Offset(1, 1),
                                                                  color: Colors.grey.withOpacity(0.5))
                                                            ]

                                                        ),
                                                        child: Padding(
                                                          padding:  EdgeInsets.symmetric(vertical: Dimension.height10/2),
                                                          child: Column(
                                                            children: [
                                                              Row(children: [Expanded(child: Center(child: BigText(text: object.name)))],),
                                                              SizedBox(height: Dimension.height10/5,),
                                                              Row(children: [
                                                                Expanded(child: Center(child: BigText(text: Get.find<PanelController>().myDoubleRounder(object.counter, 3), color: Colors.orangeAccent,), ))
                                                              ],)
                                                            ],
                                                          ),
                                                        ),
                                                      ),
                                                    );
                                                  }));
                                            }),



                                          ]
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            );
                          });


                    },
                        onLongPress: () async {

                        await                          historyController.generateExcel();
                        },

                        child: Icon(CupertinoIcons.rectangle_fill_on_rectangle_fill , color: AppColors.mainColor,))),



                    Expanded(
                      flex: 2,
                      child: ElevatedButton(onPressed: () async {
                        await historyController.getInvoiceDate(int.parse(day), int.parse(month), int.parse(year),
                            int.parse(dayT), int.parse(monthT), int.parse(yearT), int.parse(hour1), int.parse(hour2)

                        );
                      }, child: BigText(text: "  Search  " , color: Colors.white,)),
                    ),
                    Expanded(child: IconButton(onPressed: (){

                      historyController.initializingDaySaleList();

                      showModalBottomSheet
                        (
                          isScrollControlled: true,
                          backgroundColor: Colors.transparent,
                          context: context,
                          builder: (_) {
                            return FractionallySizedBox(
                              heightFactor: 0.8,
                              child: Column(
                                children: [
                                  Expanded(
                                    child: Container(
                                      height: Dimension.height45 * 10,
                                      decoration: BoxDecoration(
                                        color: Colors.white,
                                        borderRadius: BorderRadius.only(
                                          topLeft: Radius.circular(Dimension.radius20),
                                          topRight: Radius.circular(Dimension.radius20),
                                        ),
                                      ),
                                      child: Column(
                                          children: [
                                            SizedBox(height: Dimension.height20,),
                                            Row(
                                              children: [
                                                Expanded(child: Center(child: BigText(text: "Daily Sale History", size: Dimension.font26, color: AppColors.mainColor, )))
                                              ],
                                            ),

                                            SizedBox(height: Dimension.height10,),

                                            Expanded(



                                              child: Container(

                                                child: ListView.builder(
                                                    itemCount: historyController.daySaleList.length,
                                                    itemBuilder: (context, index){
                                                      int pointer = historyController.daySaleList.length - index-1 ;
                                                      DaySaleListModal object = historyController.daySaleList[pointer];
                                                      return Padding(
                                                        padding:  EdgeInsets.symmetric(horizontal: Dimension.width20, vertical: Dimension.height10/2),
                                                        child: Container(
                                                          decoration: BoxDecoration(
                                                              color: Colors.white,
                                                              borderRadius: BorderRadius.circular(Dimension.radius15),
                                                              boxShadow: [
                                                                BoxShadow(
                                                                    blurRadius: 3,
                                                                    spreadRadius: 1,
                                                                    offset: const Offset(1, 1),
                                                                    color: Colors.grey.withOpacity(0.5))
                                                              ]
                                                          ),
                                                          child: Padding(

                                                            padding:  EdgeInsets.symmetric(horizontal: Dimension.width20, vertical: Dimension.height10),
                                                            child: Row(

                                                              children: [
                                                                Expanded(child: Row(
                                                                  children: [
                                                                    const Icon(Icons.access_time_filled_sharp ,color: Colors.orangeAccent,),
                                                                    Expanded(child: BigText( text: '  ${object.day.substring(6,8)}-${object.day.substring(4,6)}-${object.day.substring(0,4)}'  )),
                                                                  ],
                                                                )),


                                                                Expanded(
                                                                  child: Row(
                                                                    mainAxisAlignment: MainAxisAlignment.center,
                                                                    children: [
                                                                      const Icon(Icons.money ,color: Colors.orangeAccent,),
                                                                      Expanded(child: BigText(text: ' ${Get.find<PanelController>().myDoubleRounder(object.sale, 3)}' )),
                                                                    ],
                                                                  ),
                                                                ),

                                                              ],),
                                                          ),

                                                        ),
                                                      );
                                                    }),
                                              ),
                                            )
                                          ]
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            );
                          });

                    }, icon: Icon(CupertinoIcons.arrow_up_bin_fill , color: AppColors.mainColor,))),

                  ],
                ),
                Divider(thickness: Dimension.height10/5, indent: Dimension.height10*8, endIndent: Dimension.height10*8,)
                ,

                SizedBox(
                  height: Dimension.height45*12.5,
                  child: ListView.builder(
                      itemCount:  historyController.invoiceList.length,
                      itemBuilder: (context , index){
                        return HistoryInvoiceTile(mainInvoice: historyController.invoiceList[index] );
                      }),
                )

              ],
            ),
          ), Positioned(child: Center(
            child: historyController.isLoading?CircularProgressIndicator():Container(),
          )) ],
        ) : NonLogInUserWidget(): const NonActiveAccountWidget()  ;
      }) ,
    );
  }
}
