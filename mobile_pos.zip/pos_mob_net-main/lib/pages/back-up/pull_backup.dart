import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pos_mobile_f/controller/back_up_controller.dart';
import 'package:pos_mobile_f/controller/panel_controller.dart';
import 'package:pos_mobile_f/widgets/big_text.dart';
import 'package:pos_mobile_f/widgets/non_active_account_widget.dart';
import 'package:pos_mobile_f/widgets/non_log_in_user.dart';
import 'package:pos_mobile_f/widgets/panel_text_field.dart';

import '../../utils/dimensions.dart';

class PullBackup extends StatelessWidget {
   PullBackup({super.key});
  TextEditingController backUpEditingController = TextEditingController();

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      body: GetBuilder<BackUpController>(builder: (backUpController) {
        return Get.find<PanelController>().isAccountActive?backUpController.adminPanelController.isAdminLogIn?
        Padding(
          padding:  EdgeInsets.symmetric(horizontal: Dimension.width30),
          child: SingleChildScrollView(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                SizedBox(height: Dimension.height45*1.5,),
                backUpController.isProcessingForPull?  Container(
                  width: Dimension.screenWidth*0.7, height: Dimension.height45*5.5,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [CircularProgressIndicator(strokeCap: StrokeCap.butt, ),
                      SizedBox(height: Dimension.height30,),

                      Text( backUpController.progressValueForPull.toString() , style: TextStyle(
                          color: backUpController.colorValueForProgressForPull, fontSize: Dimension.font26*1.4
                      ),),
                    ],
                  ),
                ):
                Container(width: Dimension.screenWidth*0.7, height: Dimension.height45*5.5, color: Colors.transparent,),

                SizedBox(height: Dimension.height45,),

                PanelTextField(
                    textController: backUpEditingController,
                    hintText: "Enter Key For Products",
                    icon: Icons.key,
                    onSubmit: (value) {}),
                SizedBox(
                  height: Dimension.height45,
                ),
                ElevatedButton(
                    onPressed: () async {
                      await backUpController
                          .getProductsData(backUpEditingController.text);
                    },
                    child: BigText(text: "   Get Products   " , color: Colors.white,) ),
              ],
            ),
          ),
        ):NonLogInUserWidget():NonActiveAccountWidget();
      }),
    );
  }
}
