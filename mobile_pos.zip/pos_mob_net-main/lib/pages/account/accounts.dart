import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:pos_mobile_f/controller/panel_controller.dart';
import 'package:pos_mobile_f/main.dart';
import 'package:pos_mobile_f/utils/colors.dart';
import 'package:pos_mobile_f/utils/dimensions.dart';
import 'package:pos_mobile_f/widgets/app_text_field.dart';
import 'package:pos_mobile_f/widgets/big_text.dart';
import 'package:pos_mobile_f/widgets/non_active_account_widget.dart';
import 'package:pos_mobile_f/widgets/non_log_in_user.dart';

class Accounts extends StatelessWidget {
   Accounts({super.key});

  TextEditingController passCodeEditingController = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return GetBuilder<PanelController>(builder: (panelController){
      DateTime dateTime = DateTime.now();
      bool isDemo = panelController.restaurantName == "Demo Store" ;
      int month = 0;
      int year = 0;

      String monthYearString = '000000';

      if(!isDemo){


        monthYearString = setDateTimeBoxPointer.get(0)??'';
        monthYearString.isNum ? null : monthYearString = '000000';


        panelController.accountActivityChecker();



         month = int.parse(monthYearString.substring(4));
         year = int.parse(monthYearString.substring(0, 4));








      }
      return  panelController.adminPanelController.isAdminLogIn? Scaffold(
        body: isDemo? Center(
          child: SingleChildScrollView(
            child: Column(

              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                SizedBox(height: Dimension.height45*1,),
                Column(
                  children: [BigText(text: "You are using",),
                    BigText(text: "Demo Account!",size: Dimension.font26*1.5,color: Colors.red,),

                  ],
                ),
               panelController.uniqueId == ''?  Column(

                 children: [
                 SizedBox(height: Dimension.height45*5,),
                   ElevatedButton(onPressed: () async {

                     await panelController.uniqueIdGenerator();
                    }, child: BigText(text: "    Get ID    ", color: Colors.white,)),
                 ],
               ):Container() ,

                panelController.uniqueId != '' ?Column(
                  children: [

                    SizedBox(height: Dimension.height45*3,),
                    Padding(
                      padding:  EdgeInsets.symmetric(horizontal:Dimension.width30),
                      child: AppTextField(textController: passCodeEditingController, hintText: "Enter Passcode", icon: Icons.password),
                    ),

                    SizedBox(height: Dimension.height45*0.5,),
                    ElevatedButton(onPressed: () async {
                     await panelController.myDecoder(passCodeEditingController.text);

                    }, child: BigText(text: "Proceed" , color: Colors.white,)),

                    SizedBox(height: Dimension.height45*3,),
                    BigText(text: "Contact on WhatsApp for Passcode", color: Colors.lightBlueAccent,),
                    ElevatedButton(onPressed: () async {
                     await panelController.goToWhatsApp("I need Passcode");
                    }, style: ButtonStyle(
                      backgroundColor: MaterialStateProperty.all(Colors.green)
                    ),
                        child:BigText(text: "     +92-305-4509104     ", color: Colors.white,) ),


                    SizedBox(height: Dimension.height45*1.2,),
                    Material(

                      child: InkWell(onTap: () async {
                        await Clipboard.setData(ClipboardData(text: panelController.uniqueId));
                        Get.snackbar("Copied", 'ID is copied to clipboard!',
                            backgroundColor: AppColors.mainColor,
                            maxWidth: Dimension.width30 * 22,
                            colorText: Colors.white);
                      },
                      child: Padding(
                        padding:  EdgeInsets.all(Dimension.height10),
                        child: BigText(text:"ID: ${panelController.uniqueId}" ),
                      ),),
                    )
                    , SizedBox(height: Dimension.height45*0.8,),
                  ],
                ):Container()

              ],
            ),
          ),
        ):Center(
          child: SingleChildScrollView(
            child: Column(

              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                SizedBox(height: Dimension.height45*1,),
                Column(
                  children: [BigText(text: "You are using",),
                    BigText(text: panelController.restaurantName,size: Dimension.font26*1.5,color: panelController.isAccountActive? Colors.green:Colors.red,),
                    BigText(text: "Account",size: Dimension.font26,color: Colors.black,),
                    SizedBox(height: Dimension.height20,),
                    !panelController.isAccountActive? BigText(text: "Account is expired",size: Dimension.font16,color: Colors.blueAccent,):
                    BigText(text: "Valid till",size: Dimension.font16,color: Colors.blueAccent,),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                      BigText(text: "Month:  $month" ,size: Dimension.font20,color: Colors.black,),
                      BigText(text: "Year:  $year",size: Dimension.font20,color: Colors.black,),
                    ],),




                  ],
                ),
                panelController.uniqueId == ''?  Column(

                  children: [
                    SizedBox(height: Dimension.height45*5,),
                    ElevatedButton(onPressed: () async {

                      await panelController.uniqueIdGenerator();
                    }, child: BigText(text: "    Get ID    ", color: Colors.white,)),
                  ],
                ):Container() ,

                panelController.uniqueId != '' ?Column(
                  children: [

                    SizedBox(height: Dimension.height45*3,),
                    Padding(
                      padding:  EdgeInsets.symmetric(horizontal:Dimension.width30),
                      child: AppTextField(textController: passCodeEditingController, hintText: "Enter Passcode", icon: Icons.password),
                    ),

                    SizedBox(height: Dimension.height45*0.5,),
                    ElevatedButton(onPressed: () async {

                    await  panelController.myDecoder(passCodeEditingController.text);

                    }, child: BigText(text: "  Apply  " , color: Colors.white,)),

                    SizedBox(height: Dimension.height45*1.5,),
                    BigText(text: "Contact on WhatsApp for Passcode", color: Colors.lightBlueAccent,),
                    ElevatedButton(onPressed: () async {
                      await panelController.goToWhatsApp("I need Passcode");
                    }, style: ButtonStyle(
                        backgroundColor: MaterialStateProperty.all(Colors.green)
                    ),child:BigText(text: "     +92-305-4509104     ", color: Colors.white,) ),


                    SizedBox(height: Dimension.height45,),
                    Material(

                      child: InkWell(onTap: () async {
                        await Clipboard.setData(ClipboardData(text: panelController.uniqueId));
                        Get.snackbar("Copied", 'ID is copied to clipboard!',
                            backgroundColor: AppColors.mainColor,
                            maxWidth: Dimension.width30 * 22,
                            colorText: Colors.white);
                      },
                        child: Padding(
                          padding:  EdgeInsets.all(Dimension.height10),
                          child: BigText(text:"ID: ${panelController.uniqueId}" ),
                        ),),
                    )
                    , SizedBox(height: Dimension.height45*0.8,),
                  ],
                ):Container()

              ],
            ),
          ),
        ),

      ):NonLogInUserWidget();
    });
  }
}
