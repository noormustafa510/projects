import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pos_mobile_f/controller/panel_controller.dart';
import 'package:pos_mobile_f/controller/shop_detail_controller.dart';
import 'package:pos_mobile_f/modal/shop_detail_modal.dart';
import 'package:pos_mobile_f/utils/dimensions.dart';
import 'package:pos_mobile_f/widgets/big_text.dart';
import 'package:pos_mobile_f/widgets/non_active_account_widget.dart';
import 'package:pos_mobile_f/widgets/non_log_in_user.dart';
import 'package:pos_mobile_f/widgets/panel_text_field.dart';
import 'package:pos_mobile_f/widgets/paper_size_drop_down.dart';
import 'package:pos_mobile_f/widgets/printer_setter.dart';
import 'package:pos_mobile_f/widgets/sound_drop_down.dart';

class ShopDetail extends StatelessWidget {
  ShopDetail({super.key});

  @override
  Widget build(BuildContext context) {
    TextEditingController shopMottoEditingController = TextEditingController();
    TextEditingController addressEditingController = TextEditingController();
    TextEditingController phoneEditingController = TextEditingController();
    TextEditingController currencyEditingController = TextEditingController();
    TextEditingController discountEditingController = TextEditingController();
    TextEditingController taxEditingController = TextEditingController();
    TextEditingController copiesEditingController = TextEditingController();
    TextEditingController kCopiesEditingController = TextEditingController();
    TextEditingController delayEditingController = TextEditingController();
    TextEditingController spacesEditingController = TextEditingController();
    TextEditingController mainIpEditingController = TextEditingController();
    TextEditingController mainPortEditingController = TextEditingController();
    TextEditingController kIpEditingController = TextEditingController();
    TextEditingController kPortEditingController = TextEditingController();

    return Scaffold(
      body: GetBuilder<ShopDetailController>(builder: (shopDetailController) {
        shopMottoEditingController.text =
            shopDetailController.shopDetailModel.shopMoto;
        addressEditingController.text =
            shopDetailController.shopDetailModel.shopAddress;
        phoneEditingController.text =
            shopDetailController.shopDetailModel.shopPhone;
        currencyEditingController.text =
            shopDetailController.shopDetailModel.currency;
        discountEditingController.text =
            shopDetailController.shopDetailModel.shopDiscount.toString();
        taxEditingController.text =
            shopDetailController.shopDetailModel.shopTax.toString();
        copiesEditingController.text =
            shopDetailController.shopDetailModel.copies.toString();

        kCopiesEditingController.text =
            shopDetailController.shopDetailModel.kCopies.toString();
        spacesEditingController.text =
            shopDetailController.shopDetailModel.spaces.toString();
        delayEditingController.text =
            shopDetailController.shopDetailModel.delay.toString();
        shopDetailController.isNetwork = shopDetailController.shopDetailModel.isNetwork;
        mainIpEditingController.text = shopDetailController.shopDetailModel.mainIp;
        mainPortEditingController.text = shopDetailController.shopDetailModel.mainPort;
        kIpEditingController.text = shopDetailController.shopDetailModel.kIp;
        kPortEditingController.text = shopDetailController.shopDetailModel.kPort;

        if (shopDetailController.soundLevel == 5 ||
            addressEditingController.text == '') {
          shopDetailController.soundLevel =
              shopDetailController.shopDetailModel.soundLevel;
          shopDetailController.paperSize =
              shopDetailController.shopDetailModel.paperSize;


        }

        return Get.find<PanelController>().isAccountActive
            ? shopDetailController.adminPanelController.isAdminLogIn
                ? SingleChildScrollView(
                    child: Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: [
                          SizedBox(
                            height: Dimension.height20,
                          ),
                          Padding(
                            padding: EdgeInsets.symmetric(
                                horizontal: Dimension.width30),
                            child: SizedBox(
                              height: Dimension.height45*(20.75+6.2),
                              child: Column(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceAround,
                                children: [
                                  ElevatedButton(
                                      onPressed: () async {
                                        await shopDetailController
                                            .setInvoiceNumber();
                                      },
                                      child: BigText(
                                        text: "  Set Invoice Number at 0  ",
                                        color: Colors.white,
                                      )),
                                  PanelTextField(
                                      textController:
                                          shopMottoEditingController,
                                      hintText: "Enter Shop Motto",
                                      icon: Icons.announcement,
                                      onSubmit: (value) {}),
                                  PanelTextField(
                                      textController: addressEditingController,
                                      hintText: "Enter Shop Address",
                                      icon: Icons.location_city,
                                      onSubmit: (value) {}),
                                  PanelTextField(
                                    textController: phoneEditingController,
                                    hintText: "Enter Shop Phone",
                                    icon: Icons.phone,
                                    onSubmit: (value) {},
                                    isNumber: true,
                                  ),
                                  PanelTextField(
                                      textController: currencyEditingController,
                                      hintText: "Enter Currency",
                                      icon: Icons.currency_bitcoin_sharp,
                                      onSubmit: (value) {}),
                                  PanelTextField(
                                    textController: discountEditingController,
                                    hintText: "Enter Discount",
                                    icon: Icons.discount,
                                    onSubmit: (value) {},
                                    isNumber: true,
                                  ),
                                  PanelTextField(
                                    textController: taxEditingController,
                                    hintText: "Enter Tax",
                                    icon: Icons.money,
                                    onSubmit: (value) {},
                                    isNumber: true,
                                  ),
                                  PanelTextField(
                                    textController: copiesEditingController,
                                    hintText: "Enter Copies",
                                    icon: Icons.copy,
                                    onSubmit: (value) {},
                                    isNumber: true,
                                  ),
                                  PanelTextField(
                                    textController: kCopiesEditingController,
                                    hintText: "Enter Kitchen Copies",
                                    icon: Icons.copy_all_sharp,
                                    onSubmit: (value) {},
                                    isNumber: true,
                                  ),
                                  PanelTextField(
                                    textController: delayEditingController,
                                    hintText: "Enter Receipt Delay",
                                    icon: Icons.timelapse_rounded,
                                    onSubmit: (value) {},
                                    isNumber: true,
                                  ),
                                  PanelTextField(
                                    textController: spacesEditingController,
                                    hintText: "Enter Spaces",
                                    icon: Icons.space_bar,
                                    onSubmit: (value) {},
                                    isNumber: true,
                                  ),
                                  PrinterSetter(
                                      mainIpEditingController:
                                          mainIpEditingController,
                                      mainPortEditingController:
                                          mainPortEditingController,
                                      kIpEditingController:
                                          kIpEditingController,
                                      kPortEditingController:
                                          kPortEditingController,
                                    isNetwork: shopDetailController.shopDetailModel.isNetwork,
                                  isDecimal: shopDetailController.shopDetailModel.isFinalDecimal,
                                  ),
                                  Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceAround,
                                    children: [
                                      BigText(text: 'Paper Width'),
                                      PaperSizeDropDown()
                                    ],
                                  ),
                                  Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceAround,
                                    children: [
                                      BigText(text: 'Sound Level'),
                                      SoundDropDown()
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          ),
                          SizedBox(
                            height: Dimension.height15,
                          ),
                          ElevatedButton(
                              onPressed: () async {
                                if (discountEditingController.text.isNum &&
                                    taxEditingController.text.isNum &&
                                    copiesEditingController.text.isNum &&
                                    kCopiesEditingController.text.isNum &&
                                    spacesEditingController.text.isNum &&
                                    delayEditingController.text.isNum &&
                                    kPortEditingController.text.isNum &&
                                    mainPortEditingController.text.isNum) {
                                  shopDetailController.shopDetailModel =
                                      ShopDetailModel(
                                    shopMoto: shopMottoEditingController.text,
                                    shopAddress: addressEditingController.text,
                                    shopPhone: phoneEditingController.text,
                                    shopDiscount: double.parse(
                                        discountEditingController.text),
                                    currency: currencyEditingController.text,
                                    shopTax:
                                        double.parse(taxEditingController.text),
                                    copies:
                                        int.parse(copiesEditingController.text),
                                    kCopies: int.parse(
                                        kCopiesEditingController.text),
                                    spaces:
                                        int.parse(spacesEditingController.text),
                                    delay:
                                        int.parse(delayEditingController.text),
                                    soundLevel: shopDetailController.soundLevel,
                                    mainIp: mainIpEditingController.text,
                                    mainPort: mainPortEditingController.text,
                                    kIp: kIpEditingController.text,
                                    kPort: kPortEditingController.text,
                                    isNetwork: shopDetailController.isNetwork,
                                    isFinalDecimal: shopDetailController.isDecimal,
                                    paperSize: shopDetailController.paperSize,
                                  );
                                  await shopDetailController.saveShopDetail(
                                      shopDetailController.shopDetailModel);

                                  Get.snackbar("Successful",
                                      'Shops details has been saved!',
                                      backgroundColor: Colors.green,
                                      maxWidth: Dimension.width30 * 22,
                                      colorText: Colors.white);
                                } else {
                                  Get.snackbar("Failed",
                                      'Discount, Tax or copies and others are not numbers!',
                                      backgroundColor: Colors.redAccent,
                                      maxWidth: Dimension.width30 * 22,
                                      colorText: Colors.white);
                                }
                              },
                              child: BigText(
                                text: "   Save   ",
                                color: Colors.white,
                              )),
                          SizedBox(
                            height: Dimension.height45,
                          ),
                        ],
                      ),
                    ),
                  )
                : NonLogInUserWidget()
            : NonActiveAccountWidget();
      }),
    );
  }
}
