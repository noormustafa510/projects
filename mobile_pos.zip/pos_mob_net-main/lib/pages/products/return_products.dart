import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pos_mobile_f/controller/panel_controller.dart';
import 'package:pos_mobile_f/pages/products/return_product_tile.dart';
import 'package:pos_mobile_f/widgets/non_active_account_widget.dart';
import 'package:pos_mobile_f/widgets/non_log_in_user.dart';

class ReturnProducts extends StatelessWidget {
  const ReturnProducts({super.key});

  @override
  Widget build(BuildContext context) {
    Get.find<PanelController>().initializeReturnProduct();
    return Scaffold(
      body: GetBuilder<PanelController>(builder: (panelController){
        return
          Get.find<PanelController>().isAccountActive? panelController.adminPanelController.isAdminLogIn? ListView.builder(
            itemCount: panelController.returnList.length,
            itemBuilder: (context, index){

              int pointer = panelController.returnList.length- index-1;
              return ReturnProductTile(returnModal:  panelController.returnList[pointer],);

        })
          :NonLogInUserWidget()
              : NonActiveAccountWidget() ;
      })
    );
  }
}
