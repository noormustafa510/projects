import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pos_mobile_f/controller/admin_panel_controller.dart';
import 'package:pos_mobile_f/controller/panel_controller.dart';
import 'package:pos_mobile_f/utils/colors.dart';
import 'package:pos_mobile_f/utils/dimensions.dart';
import 'package:pos_mobile_f/widgets/big_text.dart';
import 'package:pos_mobile_f/widgets/non_active_account_widget.dart';
import 'package:pos_mobile_f/widgets/non_log_in_user.dart';
import 'package:pos_mobile_f/widgets/panel_text_field.dart';
import 'package:pos_mobile_f/widgets/switch_button.dart';
import 'package:pos_mobile_f/widgets/user_credential_tile.dart';

class AdminPanel extends StatelessWidget {
   AdminPanel({super.key});


  @override
  Widget build(BuildContext context) {

    return Scaffold(body:

    GetBuilder<AdminPanelController>(builder: (adminPanelController)

    {return
      Get.find<PanelController>().isAccountActive? adminPanelController.isAdminLogIn? Center(
      child:  !adminPanelController.isAddMode?
      Container(
        child: adminPanelController.isEditMode?    Padding(
          padding:  EdgeInsets.symmetric(horizontal: Dimension.width30),
          child: SingleChildScrollView(
            child: Column(
              children: [
                BigText(text: "Edit User", color: AppColors.mainColor,size: Dimension.font26, ),
                SizedBox(height: Dimension.height45,),

                PanelTextField(textController: adminPanelController.userNameEditingController, hintText: "Enter User Name",
                    icon: Icons.person, onSubmit: (value){}),
                SizedBox(height: Dimension.height30,),
                PanelTextField(textController: adminPanelController.passwordEditingController, hintText: "Enter Password",
                    icon: Icons.password, onSubmit: (value){}),

                SizedBox(height: Dimension.height20,),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [

                    BigText(text: "Admin: "),
                    SizedBox(width: Dimension.width10,),
                    SwitchButton(),
                  ],
                )
                ,
                SizedBox(height: Dimension.height45,),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [

                    TextButton(onPressed: (){
                      adminPanelController.closeEditMode();
                    }, child: BigText(text: "  Cancel  ")),
                    ElevatedButton(onPressed: () async {


                      await adminPanelController.updateUser();
                    }, child: BigText(text: "   Update   ", color: Colors.white, ))
                  ],
                )
              ],
            ),
          ),
        ):
        SingleChildScrollView(
          child: Column(

            mainAxisAlignment: MainAxisAlignment.start,

            children: [

              IconButton(onPressed: (){
                adminPanelController.changeAddMode(true);
              }, icon: Icon(Icons.add_box, size: Dimension.iconSize24*2,) , color: AppColors.mainColor,),
              SizedBox(
                height: Dimension.height30,
              ),
              SizedBox(
                height: Dimension.height45*13,
                child: ListView.builder(
                    itemCount:  adminPanelController.userList.length,
                    itemBuilder: (context, index){
                  return UserCredentialTile(logInModal: adminPanelController.userList[index]);
                }),
              )


            ],
          ),
        ),
      ):
      Padding(
        padding:  EdgeInsets.symmetric(horizontal: Dimension.width30),
        child: SingleChildScrollView(
          child: Column(
            children: [
              BigText(text: "Add User", color: AppColors.mainColor,size: Dimension.font26, ),
              SizedBox(height: Dimension.height45,),


              PanelTextField(textController: adminPanelController.userNameEditingController, hintText: "Enter User Name",
                  icon: Icons.person, onSubmit: (value){}),
              SizedBox(height: Dimension.height30,),
              PanelTextField(textController: adminPanelController.passwordEditingController, hintText: "Enter Password",
                  icon: Icons.password, onSubmit: (value){}),

              SizedBox(height: Dimension.height20,),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [

               BigText(text: "Admin: "),
                  SizedBox(width: Dimension.width10,),
                  SwitchButton(),
                ],
              )
,
              SizedBox(height: Dimension.height45,),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [

                  TextButton(onPressed: (){
                    adminPanelController.changeAddMode(false);
                  }, child: BigText(text: "  Cancel  ")),
                  ElevatedButton(onPressed: () async {


                    await adminPanelController.saveUser();
                  }, child: BigText(text: "   Save   ", color: Colors.white, ))
                ],
              )
            ],
          ),
        ),
      ),
    ): NonLogInUserWidget():NonActiveAccountWidget();

    })


    );
  }
}
