import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:list_picker/list_picker.dart';
import 'package:pos_mobile_f/controller/barcode_controller.dart';
import 'package:pos_mobile_f/controller/panel_controller.dart';
import 'package:pos_mobile_f/pages/products/printing_class.dart';
import 'package:pos_mobile_f/utils/dimensions.dart';
import 'package:pos_mobile_f/widgets/big_text.dart';
import 'package:pos_mobile_f/widgets/non_active_account_widget.dart';
import 'package:pos_mobile_f/widgets/non_log_in_user.dart';
import 'package:pos_mobile_f/widgets/panel_text_field.dart';

class BarcodeGenerator extends StatelessWidget {
   BarcodeGenerator({super.key});



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: GetBuilder<BarcodeController>(builder: (barcodeController){
        return   Get.find<PanelController>().isAccountActive? barcodeController.adminPanelController.isAdminLogIn?
        SingleChildScrollView(
          child: Column(
            children: [


              SizedBox(
                height: Dimension.height45*9,
                child: Padding(
                  padding:  EdgeInsets.symmetric(horizontal: Dimension.width30),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,

                    children: [
                      SizedBox(height: Dimension.height20,),
                      ElevatedButton(onPressed: () async {

                        List<String> nameList =  barcodeController.panelController.productController.productList.map((e) => e.name).toList();
                         String    res = await    showPickerDialog(context: context, label: 'Select Product', items: nameList

                        ) ?? '';

                         if(res != ''){

                           barcodeController.setterMethodForProduct(res);
                         }
                      }, child: BigText(text: "Select Product" , color: Colors.white,)),
                      SizedBox(height: Dimension.height10,),
                      PanelTextField(textController: barcodeController.productNameEditingController, hintText: "Name of Product", icon: Icons.abc, onSubmit: (value){}),
                      PanelTextField(textController: barcodeController.barcodeEditingController, hintText: "Barcode of Product", icon: Icons.numbers, isNumber: true,onSubmit: (value){}),
                      PanelTextField(textController: barcodeController.priceEditingController, hintText: "Price of Product", isNumber: true, icon: Icons.money, onSubmit: (value){}),
                      PanelTextField(textController: barcodeController.noOfCopiesEditingController, hintText: "No. of Copies of Product", icon: Icons.confirmation_number_sharp,

                          isNumber: true,onSubmit: (value){}),


                    ],

                  ),
                ),

              ),
              SizedBox(height: Dimension.height45,),

              ElevatedButton(onPressed: () async {

                if(!barcodeController.panelController.thermalConnection){
                  await Get.to(()=> MyPrintApp());
                }

                if(barcodeController.panelController.thermalConnection){

                  if(barcodeController.barcodeEditingController.text.length == 12){
                    await barcodeController.printModule();
                  } else{

                    Get.snackbar("Restriction", 'Barcode should have 12 Characters !',
                        backgroundColor: Colors.redAccent , maxWidth: Dimension.width30*22,colorText: Colors.white);


                  }

                }

              }, child: BigText(text: "   Print   " , color: Colors.white,)),


            ],
          ),
        ):NonLogInUserWidget() :const NonActiveAccountWidget();
      }),
    );
  }
}
