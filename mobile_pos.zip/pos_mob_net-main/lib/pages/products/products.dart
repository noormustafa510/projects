import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:list_picker/list_picker.dart';
import 'package:pos_mobile_f/controller/product_controller.dart';
import 'package:pos_mobile_f/modal/product_modal.dart';
import 'package:pos_mobile_f/utils/colors.dart';
import 'package:pos_mobile_f/utils/dimensions.dart';
import 'package:pos_mobile_f/widgets/app_text_field.dart';
import 'package:pos_mobile_f/widgets/big_text.dart';
import 'package:pos_mobile_f/widgets/non_log_in_user.dart';
import 'package:pos_mobile_f/widgets/product_entry_search_field.dart';
import 'package:pos_mobile_f/widgets/product_tile.dart';
import 'package:pos_mobile_f/widgets/raw_items_tile.dart';

class Products extends StatelessWidget {
  const Products({super.key});

  @override
  Widget build(BuildContext context) {
    DateTimeRange defaultTimeRange =
        DateTimeRange(start: DateTime.now(), end: DateTime(2124));

    return GetBuilder<ProductController>(builder: (productController) {
      return productController.adminPanelController.isAdminLogIn? Scaffold(
        floatingActionButton: productController.isAddMode ||  productController.isEditMode
            ? Container()
            : FloatingActionButton(
                onPressed: () {
                  productController.modeSetter();
                },
                backgroundColor: AppColors.mainColor,
                child: Icon(Icons.add),
              ),
        body: productController.isAddMode || productController.isEditMode
            ? SingleChildScrollView(
                child: productController.isAddMode?Center(
                  child: Column(
                    children: [
                      SizedBox(
                        height: Dimension.height20,
                      ),
                      BigText(
                        text: "Add Product",
                        size: Dimension.font26,
                        color: AppColors.mainColor,
                      ),
                      SizedBox(
                        height: Dimension.height20,
                      ),
                      Container(
                        height: productController.rawItems.length>0?  Dimension.height45 * 21.5: Dimension.height45 * 20,
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            AppTextField(
                                textController: productController.nameOfProductEditingController,
                                hintText: "Enter Product Name",
                                icon: Icons.abc),
                            AppTextField(
                                textController: productController
                                    .codeOfProductEditingController,
                                hintText: "Enter Product Code",
                                isNumber: true,
                                icon: Icons.barcode_reader),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceAround,
                              children: [
                                IconButton(
                                    onPressed: () {
                                      productController.scanBarcodeNormal();
                                    },
                                    icon: Icon(
                                      Icons.barcode_reader,
                                      color: AppColors.mainColor,
                                      size: Dimension.iconSize24 * 1.5,
                                    )),
                                ElevatedButton(onPressed: () async {

                              await    productController.autoGenerateBarCode();
                                }, child: BigText(text: "Auto Gen." , color: Colors.white,))
                              ],
                            ),
                            AppTextField(
                                textController: productController.priceOfProductEditingController,                                isNumber: true,

                                hintText: "Enter Price",
                                icon: Icons.currency_bitcoin_sharp),
                            AppTextField(
                                textController: productController.costOfProductEditingController,                                isNumber: true,

                                hintText: "Enter Cost",
                                icon: Icons.money),

                            AppTextField(
                                textController: productController.discountEditingController,
                                isNumber: true,

                                hintText: "Enter Discount",
                                icon: Icons.discount),


                            AppTextField(
                                textController: productController.itemsInInventoryEditingController,                                isNumber: true,

                                hintText: "Enter count of Items",
                                icon: Icons.numbers),
                            AppTextField(
                              textController: productController.limitSetterEditingController,                                isNumber: true,

                              hintText: "Enter Warning Limit",
                              icon: Icons.warning,
                              color: Colors.red,
                            ),
                            ListPickerField(
                              //padding: EdgeInsets.symmetric(horizontal: ),

                              width: Dimension.width30 * 20,

                              label: "Category",
                              items: productController.categoriesList
                                  .map((e) => e.categoryName)
                                  .toList()
                                  .reversed
                                  .toList(),
                              controller: productController
                                  .selectedCategoryEditingController,
                              //controller: controller,
                            ),
                            !productController.expirySelectionStatus
                                ? ElevatedButton(
                              onPressed: () async {
                                DateTimeRange newDateTimeRange =
                                    await showDateRangePicker(
                                      context: context,
                                      firstDate: DateTime(2022),
                                      lastDate: DateTime(2124),
                                      currentDate: DateTime.now(),
                                    ) ??
                                        defaultTimeRange;

                                if (newDateTimeRange.end.year != 2124) {
                                  productController.dateTimeRangeSetter(
                                      newDateTimeRange);
                                  productController
                                      .expirySelectionStatusUpdate(true);
                                }
                              },
                              child: Padding(
                                padding: EdgeInsets.symmetric(
                                    horizontal: Dimension.width10 / 2,
                                    vertical: Dimension.height10 / 2),
                                child: BigText(
                                  text: 'Set Expiry',
                                  size: Dimension.font20,
                                  color: Colors.white,
                                ),
                              ),
                              style: ButtonStyle(
                                  backgroundColor:
                                  MaterialStateProperty.all(
                                      Colors.red)),
                            )
                                : GestureDetector(
                              onTap: () async {
                                DateTimeRange newDateTimeRange =
                                    await showDateRangePicker(
                                        context: context,
                                        firstDate: DateTime(2022),
                                        lastDate: DateTime(2124),
                                        currentDate:
                                        DateTime.now()) ??

                                        //    dateTimeRange
                                        defaultTimeRange;

                                if (newDateTimeRange.end.year != 2124) {
                                  productController.dateTimeRangeSetter(
                                      newDateTimeRange);
                                  productController
                                      .expirySelectionStatusUpdate(true);
                                }
                              },
                              child: Row(
                                mainAxisAlignment:
                                MainAxisAlignment.center,
                                children: [
                                  Container(
                                    decoration: BoxDecoration(
                                        color: Colors.green,
                                        borderRadius: BorderRadius.only(
                                            topLeft: Radius.circular(
                                                Dimension.radius30),
                                            bottomLeft: Radius.circular(
                                                Dimension.radius30))),
                                    child: Padding(
                                      padding: EdgeInsets.symmetric(
                                          horizontal:
                                          Dimension.width10 * 1.5,
                                          vertical: Dimension.height10),
                                      child: BigText(
                                          text:
                                          'MD: ${productController.dateTimeToString(productController.dateTimeRange.start)}',
                                          size: Dimension.font20,
                                          color: Colors.white),
                                    ),
                                  ),
                                  Container(
                                    decoration: BoxDecoration(
                                        color: Colors.red,
                                        borderRadius: BorderRadius.only(
                                            topRight: Radius.circular(
                                                Dimension.radius30),
                                            bottomRight: Radius.circular(
                                                Dimension.radius30))),
                                    child: Padding(
                                      padding: EdgeInsets.symmetric(
                                          horizontal:
                                          Dimension.width10 * 1.5,
                                          vertical: Dimension.height10),
                                      child: BigText(
                                        text:
                                        'ED: ${productController.dateTimeToString(productController.dateTimeRange.end)}',
                                        size: Dimension.font20,
                                        color: Colors.white,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Divider(
                              color: Colors.orangeAccent,
                              thickness: Dimension.height10 / 4,
                            ),
                            Container(
                                height: productController.rawItems.length>0?Dimension.height45*3:Dimension.height45*1.5,
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                                  children: [
                                    ElevatedButton(
                                        onPressed: () async {

                                          String? item = await showPickerDialog(
                                            context: context,
                                            label: "Inventory Items",
                                            items: productController.productList.map((e) => e.name).toList(),
                                          );

                                          if(item !=null ){
                                            //dataEntryController.addItemInProductInventoryList(item);
                                            productController.rawItems.add(item);
                                            productController.update();

                                          }


                                        },


                                        style: const ButtonStyle(
                                        ),
                                        child: BigText(text: "Add Raw Products",color: Colors.orangeAccent,size: Dimension.font26,)

                                    ),
                                    productController.rawItems.length>0? Container(
                                      height: Dimension.height45*1.5,
                                      width: Dimension.width30*30,
                                      child: ListView.builder(
                                          scrollDirection: Axis.horizontal,
                                          itemCount: productController.rawItems.length,
                                          itemBuilder: (context,index){
                                            int marker = productController.rawItems.length-index-1;
                                            return
                                              RawItemTile(name: productController.rawItems[marker],
                                                  index: marker);
                                          }),
                                    ):Container()
                                  ],
                                )),
                            Divider(
                              color: Colors.orangeAccent,
                              thickness: Dimension.height10 / 4,
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                TextButton(
                                    onPressed: () {
                                      productController.cancelProduct();
                                    },
                                    child: BigText(text: 'Cancel')),
                                SizedBox(
                                  width: Dimension.width30 * 3,
                                ),
                                ElevatedButton(
                                  onPressed: () async {

                                   await productController.saveProduct();
                                    // for(int i=0; i<10000 ; i++){
                                    //   print("Data:"+ i.toString());
                                    //
                                    //   productController.nameOfProductEditingController.text = "This is pro-number:"+ i.toString() ;
                                    //   productController.codeOfProductEditingController.text = i.toString();
                                    //   productController.saveProduct();
                                    // }


                                  },
                                  child: BigText(
                                    text: "Save",
                                    color: Colors.white,
                                  ),
                                )
                              ],
                            ),
                            SizedBox(
                              height: Dimension.height15,
                            )
                          ],
                        ),
                      ),
                    ],
                  ),
                ):Center(
                  child: Column(
                    children: [
                      SizedBox(
                        height: Dimension.height20,
                      ),
                      BigText(
                        text: "Edit Product",
                        size: Dimension.font26,
                        color: AppColors.mainColor,
                      ),
                      SizedBox(
                        height: Dimension.height20,
                      ),
                      Container(
                        height: productController.rawItems.length>0?  Dimension.height45 * 21.5: Dimension.height45 * 20,
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            AppTextField(
                                textController: productController.nameOfProductEditingController,
                                hintText: "Update Product Name",
                                icon: Icons.abc),
                            AppTextField(
                                textController: productController
                                    .codeOfProductEditingController,
                                hintText: "Update Product Code",
                                isNumber: true,
                                icon: Icons.barcode_reader),
                            IconButton(
                                onPressed: () {
                                  productController.scanBarcodeNormal();
                                },
                                icon: Icon(
                                  Icons.barcode_reader,
                                  color: AppColors.mainColor,
                                  size: Dimension.iconSize24 * 1.5,
                                )),
                            AppTextField(
                                textController: productController.priceOfProductEditingController,                                isNumber: true,

                                hintText: "Update Price",
                                icon: Icons.currency_bitcoin_sharp),
                            AppTextField(
                                textController: productController.costOfProductEditingController,                                isNumber: true,

                                hintText: "Update Cost",
                                icon: Icons.money),
                            AppTextField(
                                textController: productController.discountEditingController,
                                isNumber: true,

                                hintText: "Update Discount",
                                icon: Icons.discount),
                            AppTextField(
                                textController: productController.itemsInInventoryEditingController,                                isNumber: true,

                                hintText: "Update count of Items",
                                icon: Icons.numbers),
                            AppTextField(
                              textController: productController.limitSetterEditingController,                                isNumber: true,

                              hintText: "Update Warning Limit",
                              icon: Icons.warning,
                              color: Colors.red,
                            ),
                            ListPickerField(
                              //padding: EdgeInsets.symmetric(horizontal: ),

                              width: Dimension.width30 * 20,



                              label: "Category",
                              items: productController.categoriesList
                                  .map((e) => e.categoryName)
                                  .toList()
                                  .reversed
                                  .toList(),
                              controller: productController
                                  .selectedCategoryEditingController,
                              //controller: controller,
                            ),
                             GestureDetector(
                              onTap: () async {
                                DateTimeRange newDateTimeRange =
                                    await showDateRangePicker(
                                        context: context,
                                        firstDate: DateTime(2022),
                                        lastDate: DateTime(2124),
                                        currentDate:
                                        DateTime.now()) ??

                                        //    dateTimeRange
                                        defaultTimeRange;

                                if (newDateTimeRange.end.year != 2124) {
                                  productController.dateTimeRangeSetter(
                                      newDateTimeRange);
                                  productController
                                      .expirySelectionStatusUpdate(true);
                                }
                              },
                              child: Row(
                                mainAxisAlignment:
                                MainAxisAlignment.center,
                                children: [
                                  Container(
                                    decoration: BoxDecoration(
                                        color: Colors.green,
                                        borderRadius: BorderRadius.only(
                                            topLeft: Radius.circular(
                                                Dimension.radius30),
                                            bottomLeft: Radius.circular(
                                                Dimension.radius30))),
                                    child: Padding(
                                      padding: EdgeInsets.symmetric(
                                          horizontal:
                                          Dimension.width10 * 1.5,
                                          vertical: Dimension.height10),
                                      child: BigText(
                                          text:
                                          'MD: ${productController.dateTimeToString(productController.dateTimeRange.start)}',
                                          size: Dimension.font20,
                                          color: Colors.white),
                                    ),
                                  ),
                                  Container(
                                    decoration: BoxDecoration(
                                        color: Colors.red,
                                        borderRadius: BorderRadius.only(
                                            topRight: Radius.circular(
                                                Dimension.radius30),
                                            bottomRight: Radius.circular(
                                                Dimension.radius30))),
                                    child: Padding(
                                      padding: EdgeInsets.symmetric(
                                          horizontal:
                                          Dimension.width10 * 1.5,
                                          vertical: Dimension.height10),
                                      child: BigText(
                                        text:
                                        'ED: ${productController.dateTimeToString(productController.dateTimeRange.end)}',
                                        size: Dimension.font20,
                                        color: Colors.white,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Divider(
                              color: Colors.orangeAccent,
                              thickness: Dimension.height10 / 4,
                            ),
                            Container(
                                height: productController.rawItems.length>0?Dimension.height45*3:Dimension.height45*1.5,
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                                  children: [
                                    ElevatedButton(
                                        onPressed: () async {

                                          String? item = await showPickerDialog(
                                            context: context,
                                            label: "Inventory Items",
                                            items: productController.productList.map((e) => e.name).toList(),
                                          );

                                          if(item !=null ){
                                            //dataEntryController.addItemInProductInventoryList(item);
                                            productController.rawItems.add(item);
                                            productController.update();

                                          }


                                        },


                                        style: const ButtonStyle(
                                        ),
                                        child: BigText(text: "Add Raw Products",color: Colors.orangeAccent,size: Dimension.font26,)

                                    ),
                                    productController.rawItems.length>0? Container(
                                      height: Dimension.height45*1.5,
                                      width: Dimension.width30*30,
                                      child: ListView.builder(
                                          scrollDirection: Axis.horizontal,
                                          itemCount: productController.rawItems.length,
                                          itemBuilder: (context,index){
                                            int marker = productController.rawItems.length-index-1;
                                            return
                                              RawItemTile(name: productController.rawItems[marker],
                                                  index: marker);
                                          }),
                                    ):Container()
                                  ],
                                )),
                            Divider(
                              color: Colors.orangeAccent,
                              thickness: Dimension.height10 / 4,
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceAround,
                              children: [
                                TextButton(
                                    onPressed: () {
                                      productController.cancelUpdateProduct();
                                    },
                                    child: BigText(text: 'Cancel')),

                                ElevatedButton(
                                  style: ButtonStyle(
                                    backgroundColor: MaterialStateProperty.all(Colors.red)
                                  ),
                                  onLongPress: (){
                                    productController.deleteProduct();
                                    Get.snackbar("Deleted", '${productController.editingProductModal.name} has been deleted!',
                                        backgroundColor: Colors.redAccent,
                                        maxWidth: Dimension.width30 * 22,
                                        colorText: Colors.white);
                                  },

                                  onPressed: () {
                                    Get.snackbar("Long Press", 'Long Press Delete Button to delete!',
                                        backgroundColor: Colors.redAccent,
                                        maxWidth: Dimension.width30 * 22,
                                        colorText: Colors.white);
                                    //productController.saveProduct();
                                  },
                                  child: BigText(
                                    text: "Delete",
                                    color: Colors.white,
                                  ),
                                ),
                                ElevatedButton(
                                  onPressed: () async {
                                  await  productController.updateProduct();
                                  },
                                  child: BigText(
                                    text: "Update",
                                    color: Colors.white,
                                  ),
                                ),
                              ],
                            ),
                            SizedBox(
                              height: Dimension.height15,
                            )
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              )
            : SizedBox(

          height: Dimension.height45*18,
          child: Column(
            children: [
              SizedBox(height: Dimension.height20,),

              ProductEntrySearchField(textController: productController.searchEditingController,
                  hintText: "Enter Product Name", icon: Icons.search),
              SizedBox(height: Dimension.height10,),
              Padding(padding: EdgeInsets.symmetric(horizontal: Dimension.width30*8) ,
                child: Divider(color: Colors.orangeAccent,thickness: Dimension.height10/4,),),
              SizedBox(height: Dimension.height10,),


              Expanded(


                child: ListView.builder(
                    itemCount: productController.searchList.length,

                    itemBuilder: (context,index){
                      int marker = productController.searchList.length - index -1;
                      ProductModal product = productController.searchList[marker];
                      return ProductTile(product: product);
                    }),
              ),
              SizedBox(height: Dimension.height15,)
            ],
          ),
        ),
      ): NonLogInUserWidget();
    });
  }
}

