import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pos_mobile_f/controller/product_controller.dart';
import 'package:pos_mobile_f/modal/category_modal.dart';
import 'package:pos_mobile_f/utils/colors.dart';
import 'package:pos_mobile_f/utils/dimensions.dart';
import 'package:pos_mobile_f/widgets/app_text_field.dart';
import 'package:pos_mobile_f/widgets/big_text.dart';
import 'package:pos_mobile_f/widgets/category_item_tile.dart';
import 'package:pos_mobile_f/widgets/non_log_in_user.dart';

class MyCategories extends StatelessWidget {
  const MyCategories({super.key});

  @override
  Widget build(BuildContext context) {
    return GetBuilder<ProductController>(builder: (productController){
      return productController.adminPanelController.isAdminLogIn? Scaffold(
        floatingActionButton: productController.isAddModeForCat?Container(): FloatingActionButton(onPressed: (){
          productController.modeSetterForCat();
        },
          backgroundColor: AppColors.mainColor,
          child:  Icon(Icons.add) ,

        ),
        body: productController.isAddModeForCat?
        SingleChildScrollView(
          child: Center(
            child: Column(
              children: [

                SizedBox(height: Dimension.height30*4,),
                BigText(text: "Add Categories", color: AppColors.mainColor,size: Dimension.font26,),
                SizedBox(height: Dimension.height45,),
                AppTextField(textController: productController.categoryEditingController, hintText: "Enter Category",
                    icon: Icons.category),
                SizedBox(height: Dimension.height30,),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    TextButton(onPressed: (){
                      productController.cancelCategory();
                    }, child: BigText(text: 'Cancel')),
                   SizedBox(width: Dimension.width30*3,),
                   ElevatedButton(onPressed: () async {
                    await productController.saveCategory();
                   }, child: BigText(text: "Save",color: Colors.white,),)
                ],),

              ],
              
              
              
            ),
          ),
        ):
        Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [

            SizedBox(height: Dimension.height20,),

            BigText(text: "Categories", size: Dimension.font26*1.3,),
          SizedBox(height: Dimension.height10,),
          Expanded(child: ListView.builder(
              itemCount: productController.categoriesList.length,
              itemBuilder: (context, index){
                int marker = productController.categoriesList.length -index-1;
                CategoryModal category = productController.categoriesList[marker];
                  return CategoryItemTile(name: category.categoryName, index: category.key,);
          })),
            SizedBox(height: Dimension.height20,)
        ],),
      ):NonLogInUserWidget();
    });
  }
}
