
import 'package:blue_thermal_printer/blue_thermal_printer.dart';
import 'package:drago_usb_printer/drago_usb_printer.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:pos_mobile_f/controller/panel_controller.dart';
import 'package:pos_mobile_f/modal/usb_device_list_modal.dart';
import 'package:pos_mobile_f/pages/products/printerenum.dart';
import 'package:pos_mobile_f/pages/products/testprint.dart';
import 'package:pos_mobile_f/utils/dimensions.dart';
import 'package:pos_mobile_f/widgets/big_text.dart';

class MyPrintApp extends StatefulWidget {
  @override
  // ignore: library_private_types_in_public_api
  _MyPrintAppState createState() => _MyPrintAppState();
}

class _MyPrintAppState extends State<MyPrintApp> {
  BlueThermalPrinter bluetooth = BlueThermalPrinter.instance;

  List<BluetoothDevice> _devices = [];
  List<UsbDeviceListModal> usbDevices = [];
  BluetoothDevice? _device;
  UsbDeviceListModal? _usbDevice ;
  var panelController = Get.find<PanelController>();

  TestPrint testPrint = TestPrint();

  @override
  void initState() {
    super.initState();
    initPlatformState();
    getUSBDevicesList();
  }

  Future<void> initPlatformState() async {
    bool? isConnected = await bluetooth.isConnected;
    List<BluetoothDevice> devices = [];
    try {
      devices = await bluetooth.getBondedDevices();
    } on PlatformException {}

    bluetooth.onStateChanged().listen((state) {
      switch (state) {
        case BlueThermalPrinter.CONNECTED:
          setState(() {
             panelController.thermalConnection  = true;
            print("bluetooth device state: connected");
          });
          break;
        case BlueThermalPrinter.DISCONNECTED:
          setState(() {
             panelController.thermalConnection  = false;
            print("bluetooth device state: disconnected");
          });
          break;
        case BlueThermalPrinter.DISCONNECT_REQUESTED:
          setState(() {
             panelController.thermalConnection  = false;
            print("bluetooth device state: disconnect requested");
          });
          break;
        case BlueThermalPrinter.STATE_TURNING_OFF:
          setState(() {
             panelController.thermalConnection  = false;
            print("bluetooth device state: bluetooth turning off");
          });
          break;
        case BlueThermalPrinter.STATE_OFF:
          setState(() {
             panelController.thermalConnection  = false;
            print("bluetooth device state: bluetooth off");
          });
          break;
        case BlueThermalPrinter.STATE_ON:
          setState(() {
             panelController.thermalConnection  = false;
            print("bluetooth device state: bluetooth on");
          });
          break;
        case BlueThermalPrinter.STATE_TURNING_ON:
          setState(() {
             panelController.thermalConnection  = false;
            print("bluetooth device state: bluetooth turning on");
          });
          break;
        case BlueThermalPrinter.ERROR:
          setState(() {
             panelController.thermalConnection  = false;
            print("bluetooth device state: error");
          });
          break;
        default:
          print(state);
          break;
      }
    });

    if (!mounted) return;
    setState(() {
      _devices = devices;
    });

    if (isConnected == true) {
      setState(() {
         panelController.thermalConnection  = true;
      });
    }
  }

  getUSBDevicesList() async {
    usbDevices = [];
    List<Map<String,dynamic>> usbTemList = await DragoUsbPrinter.getUSBDeviceList();
    print("Devices"+ usbTemList.length.toString());
    if(usbTemList.length>0){

      usbTemList.forEach((element) {
        String temVId = element['vendorId'].toString().isNum ? element['vendorId'].toString():'0';
        String temPId = element['productId'].toString().isNum ? element['productId'].toString():'0';


       int vendorId = int.parse(temVId) ;
       int productId = int.parse(temPId);
       String productName = element['productName'].toString();
       usbDevices.add(UsbDeviceListModal(productId: productId, vendorId: vendorId, productName: productName));
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Connect Thermal Printer'),
      ),
      body: GetBuilder<PanelController>(builder: (panelController){
        return Padding(
          padding: const EdgeInsets.all(8.0),
          child: ListView(
            children: <Widget>[
              SizedBox(height: Dimension.height10,),
              Center(child: BigText(text: "Via Bluetooth", color: Colors.grey, size: Dimension.font26, ),),
              SizedBox(height: Dimension.height10,),
              Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[
                  const SizedBox(
                    width: 10,
                  ),
                  const Text(
                    'Device:',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(
                    width: 30,
                  ),
                  Expanded(
                    child: DropdownButton(
                      items: _getDeviceItems(),
                      onChanged: (BluetoothDevice? value) =>
                          setState(() => _device = value),
                      value: _device,
                    ),
                  ),
                ],
              ),
              const SizedBox(
                height: 10,
              ),
              Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.end,
                children: <Widget>[
                  ElevatedButton(

                    onPressed: () {
                      initPlatformState();
                    },
                    child: const Text(
                      'Refresh',
                      style: TextStyle(color: Colors.white),
                    ),
                  ),
                  const SizedBox(
                    width: 20,
                  ),
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                        primary:  panelController.thermalConnection  ? Colors.red : Colors.green),
                    onPressed:  panelController.thermalConnection  ? _disconnect : _connect,
                    child: Text(
                     panelController.thermalConnection  ? 'Disconnect' : 'Connect',
                      style: const TextStyle(color: Colors.white),
                    ),
                  ),
                ],
              ),

              SizedBox(height: Dimension.height45,),
              Center(child: BigText(text: "Via USB", color: Colors.grey, size: Dimension.font26, ),),
              SizedBox(height: Dimension.height10,),
              Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[
                  const SizedBox(
                    width: 10,
                  ),
                  const Text(
                    'Device:',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(
                    width: 30,
                  ),
                  Expanded(
                    child: DropdownButton(
                      items: _getUSBDeviceItems(),
                      onChanged: (UsbDeviceListModal? value){
                        setState(() {
                          _usbDevice = value;
                        });
                      },
                      value: _usbDevice,
                    ),
                  ),
                ],
              ),
              Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.end,
                children: <Widget>[
                  ElevatedButton(

                    onPressed: () async {
                      print("object");
                    await getUSBDevicesList();
                    },
                    child: const Text(
                      'Refresh',
                      style: TextStyle(color: Colors.white),
                    ),
                  ),
                  const SizedBox(
                    width: 20,
                  ),
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                        primary:  panelController.usbThermalConnection  ? Colors.red : Colors.green),
                    onPressed:  panelController.usbThermalConnection  ? _disconnectUSB : _connectUSB,
                    child: Text(
                      panelController.usbThermalConnection  ? 'Disconnect USB' : 'Connect USB',
                      style: const TextStyle(color: Colors.white),
                    ),
                  ),
                ],
              ),

            ],
          ),
        );
      })
    );
  }

  List<DropdownMenuItem<BluetoothDevice>> _getDeviceItems() {
    List<DropdownMenuItem<BluetoothDevice>> items = [];
    if (_devices.isEmpty) {
      items.add(const DropdownMenuItem(
        child: Text('NONE'),
      ));
    } else {
      _devices.forEach((device) {
        items.add(DropdownMenuItem(
          child: Text(device.name ?? ""),
          value: device,
        ));
      });
    }
    return items;
  }

  List<DropdownMenuItem<UsbDeviceListModal>> _getUSBDeviceItems() {
    List<DropdownMenuItem<UsbDeviceListModal>> items = [];
    if (usbDevices.isEmpty) {
      items.add(const DropdownMenuItem(
        child: Text('NONE'),
      ));
    } else {
      usbDevices.forEach((device) {
        items.add(DropdownMenuItem(
          child: Text(device.productName ?? ""),
          value: device,
        ));
      });
    }
    return items;
  }



  void _connect() {


    if (_device != null) {

      print("Device not null");
      bluetooth.isConnected.then((isConnected) {

        //print("Status:" + isConnected.toString());
        if(isConnected!){
          setState(() {
             panelController.thermalConnection  = isConnected;
          });
        }

        if (isConnected != true) {
          bluetooth.connect(_device!).catchError((error) {
            print("Error occured!");
            setState(() =>  panelController.thermalConnection  = false);
          });
          print("Success occured!");


          setState(() =>  panelController.thermalConnection  = true);

        }
      });
    } else {
      show('No device selected.');
    }
  }
  Future<void> _connectUSB() async {
    print("I am invoked USB");


    if (_usbDevice != null) {

   bool result =  await panelController.dragoUsbPrinter.connect(_usbDevice!.vendorId, _usbDevice!.productId ) ?? false;
     setState(() {
       panelController.usbThermalConnection = result;
     });
    } else {
      show('No device selected.');
    }
  }

  void _disconnect() {
    print("I am invoked");
    bluetooth.disconnect();
    setState(() =>  panelController.thermalConnection  = false);
  }
  Future<void> _disconnectUSB() async {
    print("I am invoked USB D");
    await panelController.dragoUsbPrinter.close();
    setState(() =>  panelController.usbThermalConnection  = false);
  }

  Future show(
      String message, {
        Duration duration = const Duration(seconds: 3),
      }) async {
    await new Future.delayed(new Duration(milliseconds: 100));
    ScaffoldMessenger.of(context).showSnackBar(
      new SnackBar(
        content: new Text(
          message,
          style: new TextStyle(
            color: Colors.white,
          ),
        ),
        duration: duration,
      ),
    );
  }
}




