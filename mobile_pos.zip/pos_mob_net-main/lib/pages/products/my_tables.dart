import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pos_mobile_f/controller/product_controller.dart';
import 'package:pos_mobile_f/modal/category_modal.dart';
import 'package:pos_mobile_f/utils/colors.dart';
import 'package:pos_mobile_f/utils/dimensions.dart';
import 'package:pos_mobile_f/widgets/app_text_field.dart';
import 'package:pos_mobile_f/widgets/big_text.dart';
import 'package:pos_mobile_f/widgets/category_item_tile.dart';
import 'package:pos_mobile_f/widgets/non_log_in_user.dart';
import 'package:pos_mobile_f/widgets/table_item_tile.dart';

class MyTables extends StatelessWidget {
  const MyTables({super.key});

  @override
  Widget build(BuildContext context) {
    return GetBuilder<ProductController>(builder: (productController){

      return productController.adminPanelController.isAdminLogIn? Scaffold(
        floatingActionButton: productController.isAddModeForTable?Container(): FloatingActionButton(onPressed: (){
          productController.modeSetterForTable();
        },
          backgroundColor: AppColors.mainColor,
          child:  Icon(Icons.add) ,

        ),
        body: productController.isAddModeForTable?
        SingleChildScrollView(
          child: Center(
            child: Column(
              children: [

                SizedBox(height: Dimension.height30*4,),
                BigText(text: "Add Tables", color: AppColors.mainColor,size: Dimension.font26,),
                SizedBox(height: Dimension.height45,),
                AppTextField(textController: productController.tableEditingController, hintText: "Enter Table",
                    icon: Icons.table_chart),
                SizedBox(height: Dimension.height30,),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    TextButton(onPressed: (){
                      productController.cancelTable();
                    }, child: BigText(text: 'Cancel')),
                    SizedBox(width: Dimension.width30*3,),
                    ElevatedButton(onPressed: () async {
                     await productController.saveTable();
                    }, child: BigText(text: "Save",color: Colors.white,),)
                  ],),

              ],



            ),
          ),
        ):
        Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [

            SizedBox(height: Dimension.height20,),

            BigText(text: "Tables", size: Dimension.font26*1.3,),
            SizedBox(height: Dimension.height10,),
            Expanded(child: ListView.builder(
                itemCount: productController.tableList.length,
                itemBuilder: (context, index){
                  int marker = productController.tableList.length -index-1;
                  CategoryModal table = productController.tableList[marker];
                  return TableItemTile(name: table.categoryName, index: table.key,);
                })),
            SizedBox(height: Dimension.height20,)
          ],),
      ):NonLogInUserWidget();
    });
  }
}
