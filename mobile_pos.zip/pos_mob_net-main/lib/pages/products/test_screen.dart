import 'dart:convert';

import 'package:drago_usb_printer/drago_usb_printer.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:pos_mobile_f/widgets/big_text.dart';

import '../../utils/dimensions.dart';

class TestScreen extends StatefulWidget {
  const TestScreen({super.key});

  @override
  State<TestScreen> createState() => _TestScreenState();
}

class _TestScreenState extends State<TestScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(child: ElevatedButton(onPressed: () async {
        DragoUsbPrinter dragoUsbPrinter = DragoUsbPrinter();


        List<Map<String,dynamic>> usbList = await DragoUsbPrinter.getUSBDeviceList();
        int vendorId = 0;
        int productId = 0;
        String productName = '';
        String modelName = '';

      //  print("Flutter Length:"+ usbList.length.toString());
       if(usbList.length>0){
         print("Flutter Length:"+ usbList[0]['productId'].toString());
         print("Flutter Length:"+ usbList[0]['vendorId'].toString());
         print("Flutter Length:"+ usbList[0]['manufacturer'].toString());
         print("Flutter Length:"+ usbList[0]['productName'].toString());
         vendorId = int.parse(usbList[0]['vendorId'].toString()) ;
         productId = int.parse(usbList[0]['productId'].toString());
         productName =usbList[0]['productName'].toString();
         modelName = usbList[0]['productName'].toString();
       }


        Get.snackbar("Result", 'vendorId$vendorId  ---  productId$productId -- $productName - $modelName',
            backgroundColor: Colors.redAccent , maxWidth: Dimension.width30*22,colorText: Colors.white);




        bool  connected = false;

          bool? returned = false;
          try {
            returned = await dragoUsbPrinter.connect(vendorId, productId);
          } on PlatformException {
            print("Result:" + connected.toString());
            //response = 'Failed to get platform version.';
          }
          if (returned!) {
            setState(() {
              connected = true;
            });
          }


          print("Result1:" + connected.toString());

          if(connected){
            try {
              var data = Uint8List.fromList(
                  utf8.encode(" Hello world Testing ESC POS printer..."));
              await dragoUsbPrinter.write(data);
              // await FlutterUsbPrinter.printRawData("text");
              // await FlutterUsbPrinter.printText("Testing ESC POS printer...");
            } on PlatformException {
              //response = 'Failed to get platform version.';
            }
          }

        await  dragoUsbPrinter.close();


       // print("Flutter Length:"+ usbList[0]['vendorId'].toString());

      }, child: BigText(text: "HIt"))),
    );
  }
}
