import 'package:flutter/material.dart';
import 'package:pos_mobile_f/main.dart';
import 'package:pos_mobile_f/modal/return_modal.dart';
import 'package:pos_mobile_f/utils/colors.dart';
import 'package:pos_mobile_f/utils/dimensions.dart';
import 'package:pos_mobile_f/widgets/big_text.dart';

class ReturnProductTile extends StatefulWidget {
  ReturnModal returnModal ;
  ReturnProductTile({super.key, required this.returnModal});


  @override
  State<ReturnProductTile> createState() => _ReturnProductTileState();
}

class _ReturnProductTileState extends State<ReturnProductTile> {
  @override
  bool isExpanded = false;
  
  Widget build(BuildContext context) {
    
    
    return Column(
      children: [
        SizedBox(height: Dimension.height30,),
        Row(children: [
          SizedBox(
              width: Dimension.width10*10,
              child: Divider(thickness: Dimension.width10/2, color: AppColors.mainColor,)),
          Expanded(child: Center(child: BigText(text:widget.returnModal.invoiceNumberAndTime+ ' --- D: '+ widget.returnModal.date )))
,
          SizedBox(
              width: Dimension.width10*10,
              child: Divider(thickness: Dimension.width10/2,  color: AppColors.mainColor,)),



        ],


          ),

        GestureDetector(
          onTap: (){
            setState(() {
              isExpanded = ! isExpanded;
            });
          },
          child: Padding(
            padding:  EdgeInsets.symmetric(horizontal: Dimension.width30, vertical: Dimension.height10),
            child: Container(
              decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(Dimension.radius15),
                  boxShadow: [
                    BoxShadow(
                        blurRadius: 3,
                        spreadRadius: 1,
                        offset: const Offset(1, 1),
                        color: Colors.grey.withOpacity(0.5))
                  ]

              ),
              child: Padding(
                padding:  EdgeInsets.symmetric(horizontal: Dimension.width20, vertical: Dimension.height10/2),
                child: Column(
                  children: [

                    Row(
                      children: [Expanded(child: Center(child: BigText(text: widget.returnModal.itemName)))],

                    ),
                    SizedBox(height: Dimension.height10/4,),
                    Row(children: [
                      Expanded(child: Center(child: BigText(text: 'RQ: '+(widget.returnModal.quantity *-1).toString(), color: Colors.red,))),
                      Expanded(child: Center(child: BigText(text: 'SQ: '+(widget.returnModal.remainingQuantity ).toString(), color: Colors.blue,))),



                    ],),
                     isExpanded ?Column(children: [
                      SizedBox(height: Dimension.height10/4,),
                      Row(children: [
                        Expanded(child: Center(child: BigText(text: 'P: '+(widget.returnModal.price ).toString(),))),
                        Expanded(child: Center(child: BigText(text: 'C: '+(widget.returnModal.cost ).toString(),))),
                        Expanded(child: Center(child: BigText(text: 'Dis: '+(widget.returnModal.discount ).toString(),))),



                      ],),
                      SizedBox(height: Dimension.height10/4,),
                      Row(children: [Expanded(child: BigText(text:'Rem: '+widget.returnModal.remarks))],)
                    ],):Container()
                  ],
                ),
              ),
            ),
          ),
        ),
        
      ],
    );
  }
}
