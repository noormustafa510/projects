import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pos_mobile_f/controller/admin_panel_controller.dart';
import 'package:pos_mobile_f/main.dart';
import 'package:pos_mobile_f/utils/colors.dart';
import 'package:pos_mobile_f/utils/dimensions.dart';
import 'package:pos_mobile_f/widgets/big_text.dart';
import 'package:pos_mobile_f/widgets/panel_text_field.dart';

class LogInPage extends StatefulWidget {
  const LogInPage({super.key});

  @override
  State<LogInPage> createState() => _LogInPageState();
}

class _LogInPageState extends State<LogInPage> {
  TextEditingController userNameEditingController= TextEditingController();
  TextEditingController passwordEditingController = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: GetBuilder<AdminPanelController>(builder: (adminPanelController){
        return adminPanelController.isLogIn?Center(
          child: ElevatedButton(onPressed: (){
            adminPanelController.loggingOut();
          }, child: BigText(text: "  Log Out  ", color: Colors.white, )),
        ):SingleChildScrollView(
          child: Column(children: [
            SizedBox(height: Dimension.height45*3,),
            Center(child: Icon(Icons.login, color: AppColors.mainColor, size: Dimension.iconSize24*7,)),
            SizedBox(height: Dimension.height45,),
            Padding(
              padding:  EdgeInsets.symmetric(horizontal: Dimension.width30*1.3),
              child: Column(
                children: [
                  PanelTextField(textController: userNameEditingController,
                      hintText: "Enter User Name", icon: Icons.person, onSubmit: (val){}),
                  SizedBox(height: Dimension.height20,),
                  PanelTextField(textController: passwordEditingController,
                      hintText: "Enter Password", icon: Icons.password, onSubmit: (val){}),

                  SizedBox(height: Dimension.height45,),
                  ElevatedButton(onPressed: () async {
                   await adminPanelController.loggingIn(userNameEditingController.text, passwordEditingController.text);

                  }, child: BigText(text: 'Log In' ,color: Colors.white,)),


                SizedBox(height: Dimension.height45*1.5,),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [  BigText(text: "Wrong Attempts: ", color: Colors.red,), BigText(text: adminPanelController.wrongInputs.toString() ) ],)

                ],
              ),
            )
          ],),
        );
      }),
    );
  }
}
