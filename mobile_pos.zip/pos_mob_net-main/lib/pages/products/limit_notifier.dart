import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pos_mobile_f/controller/limit_controller.dart';
import 'package:pos_mobile_f/controller/panel_controller.dart';
import 'package:pos_mobile_f/modal/product_modal.dart';
import 'package:pos_mobile_f/widgets/big_text.dart';
import 'package:pos_mobile_f/widgets/non_active_account_widget.dart';
import 'package:pos_mobile_f/widgets/non_log_in_user.dart';
import 'package:pos_mobile_f/widgets/product_entry_search_field.dart';
import 'package:pos_mobile_f/widgets/product_tile.dart';
import 'package:pos_mobile_f/widgets/short_product_search_field.dart';
import 'package:pos_mobile_f/widgets/short_product_tile.dart';

import '../../utils/dimensions.dart';

class LimitNotifier extends StatelessWidget {
  const LimitNotifier({super.key});


  @override
  Widget build(BuildContext context) {
    Get.find<LimitController>().initializedShortList();
    return Scaffold(
      body: GetBuilder<LimitController>(builder: (limitController){

        return 
          Get.find<PanelController>().isAccountActive?
          limitController.adminPanelController.isAdminLogIn?
          SizedBox(

          height: Dimension.height45*18,
          child: Column(
            children: [
              SizedBox(height: Dimension.height20,),

              ShortProductSearchField(textController: limitController.shortProductNameEditingController,
                  hintText: "Enter Product Name", icon: Icons.search),
              SizedBox(height: Dimension.height10,),
              Padding(padding: EdgeInsets.symmetric(horizontal: Dimension.width30*8) ,
                child: Divider(color: Colors.orangeAccent,thickness: Dimension.height10/4,),),
              SizedBox(height: Dimension.height10,),


              Expanded(


                child: ListView.builder(
                    itemCount: limitController.searchShortList.length,

                    itemBuilder: (context,index){
                      int marker = limitController.searchShortList.length - index -1;
                      ProductModal product = limitController.searchShortList[marker];
                      return ShortProductTile(product: product);
                    }),
              ),
              SizedBox(height: Dimension.height15,)
            ],
          ),
        ):NonLogInUserWidget() :NonActiveAccountWidget();
      }),
    );
  }
}
