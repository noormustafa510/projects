import 'package:flutter/material.dart';
import 'package:pos_mobile_f/main.dart';
import 'package:pos_mobile_f/modal/discount_model.dart';
import 'package:pos_mobile_f/modal/return_modal.dart';
import 'package:pos_mobile_f/utils/colors.dart';
import 'package:pos_mobile_f/utils/dimensions.dart';
import 'package:pos_mobile_f/widgets/big_text.dart';

class DiscountProductTile extends StatefulWidget {
  DiscountModel discountModel ;
  DiscountProductTile({super.key, required this.discountModel});


  @override
  State<DiscountProductTile> createState() => _DiscountProductTileState();
}

class _DiscountProductTileState extends State<DiscountProductTile> {
  @override
  bool isExpanded = false;

  Widget build(BuildContext context) {


    return Column(
      children: [
        SizedBox(height: Dimension.height30,),
        Row(children: [
          SizedBox(
              width: Dimension.width10*10,
              child: Divider(thickness: Dimension.width10/2, color: AppColors.mainColor,)),
          Expanded(child: Center(child: BigText(text:widget.discountModel.invoiceNumberAndTime+ ' --- D: '+ widget.discountModel.date )))
          ,
          SizedBox(
              width: Dimension.width10*10,
              child: Divider(thickness: Dimension.width10/2,  color: AppColors.mainColor,)),



        ],


        ),

        GestureDetector(
          onTap: (){
            setState(() {
              isExpanded = ! isExpanded;
            });
          },
          child: Padding(
            padding:  EdgeInsets.symmetric(horizontal: Dimension.width30, vertical: Dimension.height10),
            child: Container(
              decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(Dimension.radius15),
                  boxShadow: [
                    BoxShadow(
                        blurRadius: 3,
                        spreadRadius: 1,
                        offset: const Offset(1, 1),
                        color: Colors.grey.withOpacity(0.5))
                  ]

              ),
              child: Padding(
                padding:  EdgeInsets.symmetric(horizontal: Dimension.width20, vertical: Dimension.height10/2),
                child: Column(
                  children: [

                    Row(
                      children: [Expanded(child: Center(child: BigText(text:

                      (widget.discountModel.quantity== 0?'': widget.discountModel.quantity.toString()+' - ' )


                          +widget.discountModel.itemName)))],

                    ),
                    SizedBox(height: Dimension.height10/4,),
                   Row(
                     children: [
                       Expanded(child: Center(child: BigText(text: 'Dis%: '+(widget.discountModel.discount ).toString(),))),
                     ],
                   )
                   ,
                    isExpanded ?Column(children: [
                      SizedBox(height: Dimension.height10/4,),
                      Row(children: [
                        Expanded(child: Center(child: BigText(text: 'S.P: '+(widget.discountModel.price ).toString(),))),
                        Expanded(child: Center(child: BigText(text: 'A.P: '+(widget.discountModel.cost ).toString(),))),




                      ],),
                      SizedBox(height: Dimension.height10/4,),

                    ],):Container()
                  ],
                ),
              ),
            ),
          ),
        ),

      ],
    );
  }
}
