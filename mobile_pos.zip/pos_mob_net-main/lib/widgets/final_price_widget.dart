import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pos_mobile_f/controller/panel_controller.dart';
import 'package:pos_mobile_f/utils/colors.dart';

import '../utils/dimensions.dart';
import 'big_text.dart';

class FinalPriceWidget extends StatelessWidget {
  const FinalPriceWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return  GetBuilder<PanelController>(builder: (panelController){
      return Row(
        children: [
          BigText(text: "     Total: ", size: Dimension.font26,color: Colors.grey,),
          Expanded(
              child: BigText(
                text: panelController
                    .restProductDetailsMap[
                panelController.selectedTableString]
                    ?.totalSale
                    .toString() ??
                    0.toString(),
                size: Dimension.font26,
                color: AppColors.mainColor,
              )),
        ],
      );
    });
  }
}
