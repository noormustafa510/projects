import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pos_mobile_f/controller/product_controller.dart';
import 'package:pos_mobile_f/modal/product_modal.dart';
import 'package:pos_mobile_f/utils/colors.dart';

import '../utils/dimensions.dart';
import 'big_text.dart';

class ProductTile extends StatelessWidget {
  ProductModal product;

  ProductTile({super.key, required this.product});

  TextEditingController priceEditingController = TextEditingController();
  TextEditingController costEditingController = TextEditingController();
  TextEditingController numberEditingController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    priceEditingController.text = product.price.toString();
    costEditingController.text = product.cost.toString();
    numberEditingController.text = product.count.toString();
    String value = Get.find<ProductController>()
        .searchEditingController
        .text
        .toLowerCase();
    int start = product.name.toLowerCase().indexOf(value);
    int end = start + value.length;

    return GetBuilder<ProductController>(builder: (productController) {
      return GestureDetector(
        onTap: () {
          productController.editModeInit(product);
        },
        onLongPress: () {
          productController.deleteProduct(index: product.key);
          Get.snackbar("Deleted", '${product.name} has been deleted!',
              backgroundColor: Colors.redAccent,
              maxWidth: Dimension.width30 * 22,
              colorText: Colors.white);
        },
        child: SizedBox(
          height: Dimension.height45 * 2.7,
          child: Padding(
            padding: EdgeInsets.symmetric(
                horizontal: Dimension.width30,
                vertical: Dimension.height10 / 1.5),
            child: Container(
              decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(Dimension.radius15),
                  boxShadow: [
                    BoxShadow(
                        blurRadius: 3,
                        spreadRadius: 1,
                        offset: const Offset(1, 1),
                        color: Colors.grey.withOpacity(0.5))
                  ]),
              height: Dimension.height45,
              child: Padding(
                padding: EdgeInsets.only(
                  left: Dimension.width10,
                  right: Dimension.width10,
                  top: Dimension.width10,
                    ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        SizedBox(
                          width: Dimension.width10,
                        ),
                        Expanded(
                          child: start > -1
                              ? RichText(
                                  overflow: TextOverflow.ellipsis,
                                  text: TextSpan(
                                      text: product.name
                                          .substring(0, start)
                                          .toString(),
                                      style: TextStyle(
                                          color: Colors.grey,
                                          fontSize: Dimension.font20 * 1.2,
                                          fontWeight: FontWeight.w400),
                                      children: [
                                        TextSpan(
                                            text: product.name
                                                .substring(start, end),
                                            style: TextStyle(
                                                color: Colors.orangeAccent,
                                                fontSize:
                                                    Dimension.font20 * 1.4,
                                                fontWeight: FontWeight.w400)),
                                        TextSpan(
                                          text: product.name.substring(end),
                                          style: TextStyle(
                                              color: Colors.grey,
                                              fontSize: Dimension.font20 * 1.2,
                                              fontWeight: FontWeight.w400),
                                        )
                                      ]))
                              : BigText(
                                  text: product.name.toString(),
                                  size: Dimension.font20 * 1.2,
                                ),
                        ),
                      ],
                    ),
                    SizedBox(
                      height: Dimension.height10 / 2,
                    ),
                    Row(
                      children: [
                        Expanded(
                          child: Container(
                            height: Dimension.height45 * 1.4,
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.spaceAround,
                              children: [
                                Row(
                                  children: [
                                    Expanded(

                                        child: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      children: [
                                        Icon(
                                          CupertinoIcons.bitcoin,
                                          color: AppColors.mainColor,
                                          size: Dimension.iconSize24 ,
                                        ),

                                        Expanded(
                                          child: TextField(
                                            controller: priceEditingController,
                                            textAlignVertical:
                                                TextAlignVertical.top,
                                            keyboardType:
                                                const TextInputType.numberWithOptions(
                                                    decimal: true),
                                            style: TextStyle(
                                                textBaseline:
                                                    TextBaseline.ideographic,
                                                color: AppColors.mainColor,
                                                fontSize:
                                                    Dimension.font20 ),
                                            decoration: const InputDecoration(
                                                isCollapsed: true,
                                                border: InputBorder.none),
                                          ),
                                        ),

                                      ],
                                    )),
                                    Expanded(
                                        child: Row(
                                      children: [
                                        Icon(
                                          Icons.money,
                                          color: AppColors.mainColor,
                                          size: Dimension.iconSize24 ,
                                        ),

                                        Expanded(
                                          child: TextField(
                                            controller: costEditingController,
                                            textAlignVertical:
                                                TextAlignVertical.top,
                                            keyboardType:
                                                const TextInputType.numberWithOptions(
                                                    decimal: true),
                                            style: TextStyle(
                                                textBaseline:
                                                    TextBaseline.ideographic,
                                                color: AppColors.mainColor,
                                                fontSize:
                                                    Dimension.font20 ),
                                            decoration: const InputDecoration(
                                                isCollapsed: true,
                                                border: InputBorder.none),
                                          ),
                                        ),
                                        SizedBox(
                                          width: Dimension.width10,
                                        ),
                                      ],
                                    )),
                                    Expanded(
                                        child: Row(
                                      children: [
                                        Icon(
                                          Icons.numbers,
                                          color: AppColors.mainColor,
                                          size: Dimension.iconSize24 ,
                                        ),

                                        Expanded(
                                          child: TextField(
                                            controller: numberEditingController,
                                            textAlignVertical:
                                                TextAlignVertical.top,
                                            keyboardType:
                                                const TextInputType.numberWithOptions(
                                                    decimal: true),
                                            style: TextStyle(
                                                textBaseline:
                                                    TextBaseline.ideographic,
                                                color: AppColors.mainColor,
                                                fontSize:
                                                    Dimension.font20 ),
                                            decoration: const InputDecoration(
                                                isCollapsed: true,
                                                border: InputBorder.none),
                                          ),
                                        ),

                                      ],
                                    )),

                                  ],
                                ),
                               Row(
                                 children: [
                                   Expanded(

                                       child:  Row(
                                     mainAxisAlignment: MainAxisAlignment.start,
                                     children: [
                                       Icon(
                                         Icons.barcode_reader,
                                         color: AppColors.mainColor,
                                         size: Dimension.iconSize24 ,
                                       ),
                                       SizedBox(
                                         width: Dimension.width10,
                                       ),
                                       Expanded(

                                           child: BigText(
                                             text: product.code,
                                             color: AppColors.mainColor,
                                             size: Dimension.font20 ,
                                           )),
                                     ],
                                   )),

                                 ],
                               )
                              ],
                            ),
                          ),
                        ),
                        GestureDetector(
                          onTap: () async {
                            if (priceEditingController.text.isNum &&
                                costEditingController.text.isNum  && numberEditingController.text.isNum ) {
                              product.price =
                                  double.parse(priceEditingController.text);
                              product.cost =
                                  double.parse(costEditingController.text);
                              product.count = double.parse(numberEditingController.text);

                            await  productController.priceAndCostUpdater(
                                  product.key!, product);
                              Get.snackbar(product.name,
                                  'Price:  ${product.price} & Cost:  ${product.cost} & Count: ${product.count} has been set!',
                                  backgroundColor: Colors.green,
                                  maxWidth: Dimension.width30 * 22,
                                  colorText: Colors.white);
                            } else {
                              Get.snackbar(
                                  "Error", 'Price or Cost or Count is not number!',
                                  backgroundColor: Colors.redAccent,
                                  maxWidth: Dimension.width30 * 22,
                                  colorText: Colors.white);
                            }
                          },
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(
                                CupertinoIcons.up_arrow,
                                size: Dimension.iconSize24 * 2 * 1.2,
                                color: Colors.green,
                              ),
                            ],
                          ),
                        )
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      );
    });
  }
}
