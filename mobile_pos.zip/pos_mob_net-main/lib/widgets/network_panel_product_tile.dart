import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pos_mobile_f/controller/panel_controller.dart';
import 'package:pos_mobile_f/modal/invoice_modal.dart';
import 'package:pos_mobile_f/utils/colors.dart';

import '../utils/dimensions.dart';
import 'big_text.dart';


class NetworkPanelProductTile extends StatelessWidget {
  SubProductsModal subProductsModal;
  int index;
  NetworkPanelProductTile({super.key, required this.subProductsModal, required this.index});

  TextEditingController quantityEditingController = TextEditingController();
  TextEditingController discountEditingController = TextEditingController();
  TextEditingController totalEditingController = TextEditingController();


  @override
  Widget build(BuildContext context) {
    quantityEditingController.text = subProductsModal.quantity.toString();
    discountEditingController.text = subProductsModal.discount.toString();
    totalEditingController.text = subProductsModal.total.toString();
    return GetBuilder<PanelController>(builder: (panelController){return Material(
      child: InkWell(

        onTap: (){

          panelController.addASProductFromMainList(index, true);

        },

        onLongPress: (){
          panelController.removeItemsFromList(index);
        },

        child: Ink(

          child: Padding(

            padding:  EdgeInsets.only(bottom: Dimension.height15, ),
            child: Container(
              height: Dimension.height45*2,
              decoration: BoxDecoration(
                  color: index.isEven? Colors.white:Colors.grey,

                  boxShadow: [

                    BoxShadow(
                        blurRadius: 3,
                        spreadRadius: 1,
                        offset: const Offset(0, 2),
                        color: Colors.grey.withOpacity(0.5))
                  ]

              ),
              child: Padding(

                padding:  EdgeInsets.symmetric(horizontal: Dimension.width10),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [

                    Expanded(
                      child: Center(
                        child: Row(


                          children: [
                            Expanded(child: Text( subProductsModal.name, style: TextStyle(
                              fontSize: Dimension.font20, fontWeight: FontWeight.w500
                            ), )


                            ),
                         TextButton(onPressed: () async {

                         await  panelController.kSubPrinting(true, subProductsModal);
                         },
                           onLongPress: () async {
                             await  panelController.kSubPrinting(false, subProductsModal);
                           },

                           child: Icon(Icons.print_outlined , size: Dimension.iconSize24*2,), )

                          ],
                        ),
                      ),
                    ),

                    SizedBox(height: Dimension.height15,
                      child: Row(
                        children: [
                          Expanded(child: GestureDetector(onTap: (){
                            panelController.addASProductFromMainList(index, false);
                          },child: Container(),)),
                          Expanded(child: GestureDetector(onTap: (){
                            panelController.addASProductFromMainList(index, false);
                          },child: Container(),)),
                          Expanded(child: GestureDetector(onTap: (){
                            panelController.addASProductFromMainList(index, true);
                          },child: Container(),)),
                          Expanded(child: GestureDetector(onTap: (){
                            panelController.addASProductFromMainList(index, true);},
                            child: Container(
                            ),)),
                        ],
                      ),
                    ),

                    Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Expanded(child: GestureDetector(
                          onTap: (){ panelController.addASProductFromMainList(index, false);},
                          child: Center(child: BigText(text: subProductsModal.price.toString()
                            ,
                          )),
                        )),
                        Expanded(child: Row(

                          children: [

                            GestureDetector(

                              child: Container(

                                  width: Dimension.width30*3,
                                  child: Icon(CupertinoIcons.minus_circle_fill, color: Colors.red,)),
                              onTap: (){
                                panelController.addASProductFromMainList(index, false);
                              },
                            ),

                            Expanded(
                              child: TextField(
                                controller: quantityEditingController,
                                onSubmitted: (value){
                                  if(value.isNum){
                                    panelController.addASProductViaKeyFromMainList(index, double.parse(value));
                                  }
                                  else{
                                    quantityEditingController.text = 0.toString();
                                  }
                                },
                                textAlignVertical:
                                TextAlignVertical.top,
                                textAlign: TextAlign.center,
                                keyboardType:
                                const TextInputType.numberWithOptions(
                                    decimal: true),
                                style: TextStyle(
                                    textBaseline:
                                    TextBaseline.ideographic,
                                    color:   index.isEven? AppColors.mainColor:Colors.white,
                                    fontSize:
                                    Dimension.font20 ),
                                decoration: const InputDecoration(
                                    isCollapsed: true,
                                    border: InputBorder.none),
                              ),
                            ),
                          ],
                        ),),
                        Expanded(child: TextField(
                          controller: discountEditingController,
                          onSubmitted: (value){
                            if(value.isNum){
                              panelController.discountASProductViaKeyFromMainList(index, double.parse(value));
                            }
                            else{
                              discountEditingController.text = 0.toString();
                            }
                          },
                          textAlignVertical:
                          TextAlignVertical.top,
                          textAlign: TextAlign.center,
                          keyboardType:
                          const TextInputType.numberWithOptions(
                              decimal: true),
                          style: TextStyle(
                              textBaseline:
                              TextBaseline.ideographic,
                              color:   index.isEven? AppColors.mainColor:Colors.white,
                              fontSize:
                              Dimension.font20 ),
                          decoration: const InputDecoration(
                              isCollapsed: true,
                              border: InputBorder.none),
                        ),),
                        Expanded(child: TextField(
                          controller: totalEditingController,
                          onSubmitted: (value){
                            if(value.isNum){
                              panelController.totalCalculatorForProduct(index, double.parse(value));
                            }
                            else{
                              totalEditingController.text = 0.toString();
                            }
                          },
                          textAlignVertical:
                          TextAlignVertical.top,
                          textAlign: TextAlign.center,
                          keyboardType:
                          const TextInputType.numberWithOptions(
                              decimal: true),
                          style: TextStyle(
                              textBaseline:
                              TextBaseline.ideographic,
                              color:   index.isEven? AppColors.mainColor:Colors.white,
                              fontSize:
                              Dimension.font20 ),
                          decoration: const InputDecoration(
                              isCollapsed: true,
                              border: InputBorder.none),
                        ),),
                      ],
                    ),
                    SizedBox(height: Dimension.height10/4,)
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );});
  }
}
