import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_instance/get_instance.dart';
import 'package:pos_mobile_f/controller/admin_panel_controller.dart';
import 'package:pos_mobile_f/modal/log_in_modal.dart';
import 'package:pos_mobile_f/utils/colors.dart';
import 'package:pos_mobile_f/utils/dimensions.dart';
import 'package:pos_mobile_f/widgets/big_text.dart';
import 'package:pos_mobile_f/widgets/panel_text_field.dart';

class UserCredentialTile extends StatefulWidget {
  LogInModal logInModal;
   UserCredentialTile({super.key, required this.logInModal});

  @override
  State<UserCredentialTile> createState() => _UserCredentialTileState();
}

class _UserCredentialTileState extends State<UserCredentialTile> {

  bool showPassword = false;

  @override
  Widget build(BuildContext context) {

    return GestureDetector(
      onTap: (){

        Get.find<AdminPanelController>().enterInEditMode(widget.logInModal.username, widget.logInModal.password,
            widget.logInModal.isAdmin ,widget.logInModal.key! );
      },
      child: Padding(padding: EdgeInsets.symmetric(horizontal: Dimension.width30, vertical: Dimension.height10) ,
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
            borderRadius: BorderRadius.circular(Dimension.radius15),
            boxShadow: [


              BoxShadow(
                  blurRadius: 3,
                  spreadRadius: 1,
                  offset: const Offset(1, 1),
                  color: Colors.grey.withOpacity(0.5))
            ]
        ),
          child: Padding(
            padding:  EdgeInsets.symmetric(horizontal: Dimension.width10, vertical: Dimension.height10),
            child: Padding(
              padding:  EdgeInsets.only(left: Dimension.width10),
              child: Column(
                children: [


                 Row(children: [

                   BigText(text: "User Name: ", color: Colors.orangeAccent,)  ,
                   Expanded(child: BigText(text: widget.logInModal.username)),

                 ],),
                 Row(children: [

                   BigText(text: "Password: ", color: Colors.orangeAccent,),

                   Expanded(child: BigText(text: showPassword? widget.logInModal.password: '**********')),

                   IconButton(onPressed: (){
                     setState(() {
                       showPassword = ! showPassword;
                     });
                   }, icon: Icon(Icons.remove_red_eye, color: showPassword? Colors.red: AppColors.mainColor, ) )

                 ],),

                  Row(

                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [

                    BigText(text: "Admin:  " , color: AppColors.mainColor,) ,
                      widget.logInModal.isAdmin?Icon(Icons.check, color: Colors.green,):Icon(Icons.close, color: Colors.red,)
                    ],


                  )


                ],
              ),
            ),
          ),
      ),
      ),
    );
  }
}
