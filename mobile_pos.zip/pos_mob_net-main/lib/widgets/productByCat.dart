import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pos_mobile_f/controller/panel_controller.dart';
import 'package:pos_mobile_f/modal/invoice_modal.dart';
import 'package:pos_mobile_f/modal/product_modal.dart';
import 'package:pos_mobile_f/utils/colors.dart';
import 'package:pos_mobile_f/utils/dimensions.dart';
import 'package:pos_mobile_f/widgets/big_text.dart';

class ProductByCat extends StatelessWidget {
  List<ProductModal> productsList ;
   ProductByCat({super.key, required this.productsList});



  @override
  Widget build(BuildContext context) {
    //final controller =  Get.find<PanelController>();
  //  quantityEditingController.text = controller.bottomListQunatityMap[controller.selectedTableString];
    return GetBuilder<PanelController>(builder: (panelController){
      return Container(

        width: Dimension.screenWidth,
        height: Dimension.height45*5,

        child:

        Column(
          children: [
            SizedBox(height: Dimension.height10,),


            Expanded(
              child: ListView.builder(
                  itemCount: productsList.length,
                  itemBuilder: (context, index){
                    String name = productsList[index].name;
                    String quantity = (panelController.bottomListQuantityMap[panelController.selectedTableString]?[name]?? 0 ).toString();

                    return  Padding(
                      padding:  EdgeInsets.symmetric(vertical: Dimension.height10/1.5, horizontal: Dimension.width30),
                      child: GestureDetector(
                        onTap: (){
                          panelController.addProductFromPopUp(productsList[index], true);
                        },
                        child: Container(

                          decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(Dimension.radius15),
                              boxShadow: [
                                BoxShadow(
                                    blurRadius: 3,
                                    spreadRadius: 1,
                                    offset: const Offset(1, 1),
                                    color: Colors.grey.withOpacity(0.5))
                              ]

                          ),
                          child: Column(
                            children: [

                              Row(

                                children: [

                                  Expanded(child: Center(child:
                          panelController.shopDetailController.shopDetailModel.isNetwork?

                                  TextButton(onPressed: () async {

                                    await  panelController.kSubPrinting(true,
                                        SubProductsModal(key: 0, name: name, code: '', price: productsList[index].price,
                                            cost: 0, discount: 0, quantity: double.parse(quantity), total: 0));

                                  },
                                      onLongPress: () async {
                                        await  panelController.kSubPrinting(false,
                                            SubProductsModal(key: 0, name: name, code: '', price: productsList[index].price,
                                                cost: 0, discount: 0, quantity: double.parse(quantity), total: 0));

                                      },


                                      child: BigText(text: name, color: AppColors.mainColor,size: Dimension.font26, ))

                              :BigText(text: name, color: AppColors.mainColor,size: Dimension.font26, )


                                  )),
                                ],
                              ),
                              Padding(
                                padding:  EdgeInsets.symmetric(horizontal: Dimension.width30*1.2),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [

                                    Expanded(
                                      flex:2,
                                      child: Material(

                                        color: Colors.white,
                                        child: InkWell(



                                          onTap:(){
                                            panelController.addProductFromPopUp(productsList[index], false);


                                          },
                                          splashColor: Colors.grey.withOpacity(0.5),
                                        child: Icon(CupertinoIcons.minus, color: Colors.red, size: Dimension.iconSize24*1.3,),
                                      ),),
                                    ),




                                    Expanded(
                                      flex: 3,
                                      child: Center(child: BigText(text: quantity , color:  (panelController.bottomListQuantityMap[
                                      panelController.selectedTableString]?[name]?? 0)>= 0? Colors.green:Colors.red, size: Dimension.font26, )),




                                      // TextField(
                                      //   controller: quantityEditingController,
                                      //   onSubmitted: (value){
                                      //     if(value.isNum){
                                      //       panelController.addProductFromPopUpKey(productsList[index], double.parse(value));
                                      //     }
                                      //     else{
                                      //       quantityEditingController.text = 0.toString();
                                      //     }
                                      //   },
                                      //   textAlignVertical:
                                      //   TextAlignVertical.top,
                                      //   textAlign: TextAlign.center,
                                      //   keyboardType:
                                      //   const TextInputType.numberWithOptions(
                                      //       decimal: true),
                                      //   style: TextStyle(
                                      //       textBaseline:
                                      //       TextBaseline.ideographic,
                                      //       color:
                                      //       (panelController.bottomListQuantityMap[
                                      //       panelController.selectedTableString]?[name]?? 0)>= 0?
                                      //
                                      //       Colors.green:Colors.red,
                                      //       fontSize:
                                      //       Dimension.font26 ),
                                      //   decoration: const InputDecoration(
                                      //       isCollapsed: true,
                                      //       border: InputBorder.none),
                                      // ),
                                    ),

                                    Expanded(
                                      flex: 2,
                                      child: Material(
                                        color: Colors.white,
                                        child: InkWell(
                                        onTap: (){
                                          panelController.addProductFromPopUp(productsList[index], true);
                                        },
                                        splashColor: Colors.grey.withOpacity(0.5),
                                        child: Icon(CupertinoIcons.plus, color: Colors.green, size: Dimension.iconSize24*1.3,),
                                      ),),
                                    ),
                                      ],
                                ),
                              )
                            ],
                          ),

                        ),
                      ),
                    );

                  }),
            ),
          ],
        ),

      );
    });
  }
}

