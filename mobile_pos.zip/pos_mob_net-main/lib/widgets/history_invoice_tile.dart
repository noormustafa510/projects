import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pos_mobile_f/controller/history_controller.dart';
import 'package:pos_mobile_f/controller/panel_controller.dart';
import 'package:pos_mobile_f/modal/invoice_modal.dart';
import 'package:pos_mobile_f/utils/colors.dart';
import 'package:pos_mobile_f/utils/dimensions.dart';
import 'package:pos_mobile_f/widgets/big_text.dart';
import 'package:pos_mobile_f/widgets/history_product_item_tile.dart';

import '../pages/products/printing_class.dart';

class HistoryInvoiceTile extends StatefulWidget {

  MainInvoice mainInvoice;

  HistoryInvoiceTile({super.key, required this.mainInvoice});

  @override
  State<HistoryInvoiceTile> createState() => _HistoryInvoiceTileState();
}



class _HistoryInvoiceTileState extends State<HistoryInvoiceTile> {
  bool isExpanded = false;
  @override
  Widget build(BuildContext context) {
    return Padding(


      padding:  EdgeInsets.symmetric(horizontal: Dimension.width30, vertical: Dimension.height10/2),
      child: Container(

        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(Dimension.radius15),
          color: Colors.white,
            boxShadow: [
              BoxShadow(
                  blurRadius: 3,
                  spreadRadius: 1,
                  offset: const Offset(1, 1),
                  color: Colors.grey.withOpacity(0.5))
            ]
        ),
        child: GestureDetector(
          onTap: (){
            setState(() {
              isExpanded = ! isExpanded;
              
            }

            );
          },
          child:    Padding(
            padding: EdgeInsets.only(left: Dimension.width15, right: Dimension.width15, bottom: Dimension.height10, top: !isExpanded? Dimension.height10:0 ),
            child: isExpanded? SingleChildScrollView(
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      BigText(text: 'Products', color: Colors.orangeAccent,),
                      TextButton(onPressed: () async {
                       PanelController pController =    Get.find<PanelController>();
                        if (!pController.thermalConnection && !pController.usbThermalConnection && !pController.shopDetailController.shopDetailModel.isNetwork) {
                          await Get.to(() => MyPrintApp());
                        }

                        if (pController.thermalConnection || pController.usbThermalConnection || pController.shopDetailController.shopDetailModel.isNetwork) {
                          await Get.find<HistoryController>().printDupModule(widget.mainInvoice);
                        }

                      }, child: const Icon(Icons.print))
                      
              ],
                  ),
                  SizedBox(

                    height: Dimension.height45*5,
                    child: ListView.builder(
                        itemCount: widget.mainInvoice.subProductsList.length,
                        itemBuilder: (context, index){

                      return Padding(
                        padding:  EdgeInsets.symmetric(vertical: Dimension.height10/3),
                        child: HistoryProductItemTile(subProductsModal: widget.mainInvoice.subProductsList[index] , index: index,),
                      ) ;
                    }),
                  ),
                  Divider(
                    thickness: Dimension.height10/4,
                    indent: Dimension.width30*5,
                    endIndent: Dimension.width30*5,
                  ),
                  Row(children: [
                    Expanded(

                        child: BigText(text: "Cashier:", color: AppColors.mainColor, )),
                    Expanded(
                        flex: 2,
                        child: BigText(text: widget.mainInvoice.cashier.toString()))

                  ],),
                  Row(children: [
                    Expanded(

                        child: BigText(text: "Tb:", color: AppColors.mainColor, )),
                    Expanded(
                        flex: 2,
                        child: BigText(text: widget.mainInvoice.tb.toString()))

                  ],),
                  Row(children: [
                    Expanded(

                        child: BigText(text: "Remarks:", color: AppColors.mainColor, )),
                    Expanded(
                        flex: 2,
                        child: BigText(text: widget.mainInvoice.remarks.toString()))

                  ],),
                  Row(children: [
                    Expanded(

                        child: BigText(text: "Sub. Total:", color: AppColors.mainColor, )),
                  Expanded(
                      flex: 2,
                      child: BigText(text: widget.mainInvoice.restInvoice.pSale.toString()))

                  ],),
                  Row(children: [
                    Expanded(

                        child: BigText(text: "Discount :", color: AppColors.mainColor, )),
                  Expanded(
                      flex: 2,
                      child: BigText(text: widget.mainInvoice.restInvoice.wDiscount.toString()))

                  ],),
                  Row(children: [
                    Expanded(

                        child: BigText(text: "Tax:", color: AppColors.mainColor, )),
                  Expanded(
                      flex: 2,
                      child: BigText(text: widget.mainInvoice.restInvoice.wTax.toString()))

                  ],),
                  Row(children: [
                    Expanded(

                        child: BigText(text: "Net Total:", color: AppColors.mainColor, )),
                  Expanded(
                      flex: 2,
                      child: BigText(text: widget.mainInvoice.restInvoice.totalSale.toString()))

                  ],),
                  Row(children: [
                    Expanded(

                        child: BigText(text: "Balance:", color: AppColors.mainColor, )),
                  Expanded(
                      flex: 2,
                      child: BigText(text: widget.mainInvoice.restInvoice.balance.toString()))

                  ],),

                  SizedBox(height: Dimension.height10/3,)


                ],
              ),
            ) :Column(
              children: [
                Row(children: [Expanded(child: Center(child: BigText(text: 'Date: ' + widget.mainInvoice.date , color: Colors.orangeAccent ,) ))],),
                Row(
                  children: [

                    Expanded(
                      flex: 3,
                        child: BigText(text: widget.mainInvoice.invoiceNumber)),
                    Expanded(
                        flex: 2,
                        child: Text(Get.find<PanelController>().myDoubleRounder(widget.mainInvoice.restInvoice.totalSale,3),
                           textAlign: TextAlign.right,
                          style: TextStyle(fontSize: Dimension.font20,),)),

                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
