import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pos_mobile_f/controller/product_controller.dart';

import '../utils/colors.dart';
import '../utils/dimensions.dart';

class ProductEntrySearchField extends StatelessWidget {
  final TextEditingController textController;
  final String hintText;
  final IconData icon;
  bool maxLines;
  bool isObscure;
  bool editingStatus;
  bool isNumber;

  final Color color;

  ProductEntrySearchField({Key? key,
    required this.textController,
    required this.hintText,
    required this.icon,
    this.isObscure = false,
    this.maxLines = false,
    this.editingStatus = false,
    this.isNumber = false,
    this.color = const Color(0xFFffd379)})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin:
      EdgeInsets.only(left: Dimension.height20, right: Dimension.height20),
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(Dimension.radius15),
          color: Colors.white,
          boxShadow: [
            BoxShadow(
                blurRadius: 3,
                spreadRadius: 1,
                offset: Offset(1, 1),
                color: Colors.grey.withOpacity(0.2))
          ]),
      child: GetBuilder<ProductController>(builder: (productController){
        return TextField(

          onChanged: (value){

            productController.searchListProducer();
            productController.update();

          },

          onSubmitted: (submittedString) {
            // if (editingStatus) {
            //   Get
            //       .find<LocationController>()
            //       .address = submittedString;
            // }
          },
          keyboardType: isNumber?TextInputType.numberWithOptions(decimal: true):TextInputType.text,
          maxLines: maxLines ? 4 : 1,
          obscureText: isObscure,
          controller: textController,
          decoration: InputDecoration(
            prefixIcon: Icon(icon, color: color),
            hintText: hintText,
            focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(Dimension.radius15),
                borderSide: BorderSide(
                  width: 1.0,
                  color: Colors.white,
                )),
            //Enabled Border
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(Dimension.radius15),
              borderSide: BorderSide(
                width: 1.0,
                color: Colors.white,
              ),
            ),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(Dimension.radius15),
            ),
          ),
        );
      }),
    );
  }
}
