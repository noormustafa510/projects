import 'package:flutter/material.dart';
import 'package:pos_mobile_f/modal/invoice_modal.dart';
import 'package:pos_mobile_f/utils/dimensions.dart';
import 'package:pos_mobile_f/widgets/big_text.dart';

class HistoryProductItemTile extends StatelessWidget {
  SubProductsModal subProductsModal;
  int index;
   HistoryProductItemTile({super.key, required this.subProductsModal, required this.index});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: index.isEven?Colors.white: Colors.grey,

      ),
  
      child: Padding(
        padding:  EdgeInsets.symmetric(horizontal: Dimension.width10),
        child: Column(
          children: [
            Row(
              children: [
                Expanded(child: BigText(text: subProductsModal.name, color: index.isEven?Colors.black: Colors.white )),

              ],
            ),
            Row(
              children: [
                Expanded(child: Center(child: BigText(text: subProductsModal.price.toString(), color: index.isEven?Colors.black: Colors.white,  ))),
                Expanded(child: Center(child: BigText(text: subProductsModal.quantity.toString(), color: index.isEven?Colors.black: Colors.white))),
                Expanded(child: Center(child: BigText(text: subProductsModal.discount.toString(), color: index.isEven?Colors.black: Colors.white))),
                Expanded(child: Center(child: BigText(text: subProductsModal.total.toString(), color: index.isEven?Colors.black: Colors.white))),

              ],
            ),

          ],
        ),
      ),
    );
  }
}
