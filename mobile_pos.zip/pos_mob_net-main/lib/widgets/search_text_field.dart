import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pos_mobile_f/controller/panel_controller.dart';
import 'package:pos_mobile_f/modal/product_modal.dart';



import '../utils/dimensions.dart';
import 'big_text.dart';










class SearchTextFieldForHome extends StatelessWidget {
  final TextEditingController textController;
  final String hintText;
  final IconData icon;
  bool maxLines;
  bool isObscure;
  final Color color;

  SearchTextFieldForHome(
      {Key? key,
        required this.textController,
        required this.hintText,
        required this.icon,
        this.isObscure = false,
        this.maxLines = false,
        this.color = const Color(0xFFffd379)})
      : super(key: key);

  @override
  String valueToColor = '';
  Widget build(BuildContext context) {
    return GetBuilder<PanelController>(builder: (panelController){
      return Row(
        children: [
          Expanded(
            child: Container(
              
              margin:
              EdgeInsets.only(left: Dimension.width30, right: Dimension.width30),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(Dimension.radius15),
                // color: Colors.white,
                // boxShadow: [
                //   BoxShadow(
                //       blurRadius: 3,
                //       spreadRadius: 1,
                //       offset: Offset(1, 1),
                //       color: Colors.grey.withOpacity(0.2))
                // ]
              ),
              child:   Autocomplete<ProductModal>(
                optionsBuilder: (TextEditingValue textEditingValue) {
                  valueToColor = textEditingValue.text;
                  return panelController.productController.productList
                      .where((ProductModal productModal) => productModal.name.toLowerCase()
                      .contains(textEditingValue.text.toLowerCase())
                  )
                      .toList();
                },
                displayStringForOption: (ProductModal option) => option.name,
                fieldViewBuilder: (
                    BuildContext context,
                    TextEditingController fieldTextEditingController,
                    FocusNode fieldFocusNode,
                    VoidCallback onFieldSubmitted
                    ) {
                  return
                    SubTextField(textController: fieldTextEditingController, hintText: hintText, icon: icon,focusNode: fieldFocusNode,);

                  //   TextField(
                  //   controller: fieldTextEditingController,
                  //   focusNode: fieldFocusNode,
                  //   style: const TextStyle(fontWeight: FontWeight.bold),
                  // );
                },


                onSelected: (ProductModal selection) {

                },
                optionsViewBuilder: (
                    BuildContext context,
                    AutocompleteOnSelected<ProductModal> onSelected,
                    Iterable<ProductModal> options
                    ) {
                  return Align(
                    alignment: Alignment.topCenter,
                    child: Material(
                      color: Colors.transparent,
                      child: Padding(
                        padding: EdgeInsets.only(top: Dimension.height10, right: Dimension.width30*2),
                        child: Row(
                          children: [
                            Expanded(
                              child: Container(
                               // width: Dimension.width30*2,
                                height: Dimension.height45*6,
                                decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(Dimension.radius15),
                                    color: Colors.white,
                                    boxShadow: [
                                      BoxShadow(
                                          blurRadius: 3,
                                          spreadRadius: 1,
                                          offset: Offset(1, 1),
                                          color: Colors.grey.withOpacity(1))
                                    ]
                                ),
                                child: ListView.builder(
                                  padding: EdgeInsets.all(10.0),
                                  itemCount: options.length,
                                  itemBuilder: (BuildContext context, int index) {
                                    final ProductModal option = options.elementAt(index);

                                    int start = 0;
                                    int end = 0;




                                    if(valueToColor != '' )
                                    {
                                     start = option.name.toLowerCase().indexOf(valueToColor.toLowerCase());
                                      end = start + valueToColor.length;
                                    } else{
                                      start = -1;
                                    }
                                    


                                    return GestureDetector(
                                      onTap: (){
                                        panelController.addProductFromPopUp(option, true);
                                      },
                                      child: Container(

                                        child: Column(
                                          children: [

                                            Row(

                                              children: [


                                                Expanded(
                                                  child: start > -1
                                                      ? Center(
                                                        child: RichText(
                                                        overflow: TextOverflow.ellipsis,
                                                        text: TextSpan(
                                                            text: option.name
                                                                .substring(0, start)
                                                                .toString(),
                                                            style: TextStyle(
                                                                color: Colors.grey,
                                                                fontSize: Dimension.font20 * 1.2,
                                                                fontWeight: FontWeight.w400),
                                                            children: [
                                                              TextSpan(
                                                                  text: option.name
                                                                      .substring(start, end),
                                                                  style: TextStyle(
                                                                      color: Colors.orangeAccent,
                                                                      fontSize:
                                                                      Dimension.font20 * 1.4,
                                                                      fontWeight: FontWeight.w400)),
                                                              TextSpan(
                                                                text: option.name.substring(end),
                                                                style: TextStyle(
                                                                    color: Colors.grey,
                                                                    fontSize: Dimension.font20 * 1.2,
                                                                    fontWeight: FontWeight.w400),
                                                              )
                                                            ])),
                                                      )
                                                      : Center(
                                                        child: BigText(
                                                    text: option.name.toString(),
                                                    size: Dimension.font20 * 1.2,
                                                  ),
                                                      ),
                                                ),
                                              ],
                                            ),
                                            Padding(
                                              padding:  EdgeInsets.symmetric(horizontal: Dimension.width30*1.2),
                                              child: Row(
                                                mainAxisAlignment: MainAxisAlignment.center,
                                                children: [

                                                  Expanded(
                                                    child: Material(

                                                      color: Colors.white,
                                                      child: InkWell(



                                                        onTap:(){
                                                          panelController.addProductFromPopUp(
                                                              option, false);


                                                        },
                                                        splashColor: Colors.grey.withOpacity(0.5),
                                                        child: Icon(CupertinoIcons.minus, color: Colors.red, size: Dimension.iconSize24*1.3, ),
                                                      ),),
                                                  ),




                                                  Expanded(
                                                    flex: 2,
                                                    child: Center(
                                                      child: BigText(text: (panelController.bottomListQuantityMap[
                                                      panelController.selectedTableString]?[option.name]?? 0).toString() , color:
                                                      (panelController.bottomListQuantityMap[
                                                      panelController.selectedTableString]?[option.name]?? 0)>= 0?

                                                      Colors.green:Colors.red, size: Dimension.font26, ),
                                                    ),
                                                  ),

                                                  Expanded(
                                                    child: Material(
                                                      color: Colors.white,
                                                      child: InkWell(
                                                        onTap: (){
                                                          panelController.addProductFromPopUp(option, true);


                                                        },
                                                        splashColor: Colors.grey.withOpacity(0.5),
                                                        child: Icon(CupertinoIcons.plus, color: Colors.green, size: Dimension.iconSize24*1.3,),
                                                      ),),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            Divider(
                                              thickness: Dimension.height10/5,
                                            )
                                          ],
                                        ),
                                      ),
                                    );
                                  },
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  );
                },
              ),


            ),
          ),
        ],
      );
    });
  }
}

class SubTextField extends StatelessWidget {
  final TextEditingController textController;
  final String hintText;
  final IconData icon;
  bool maxLines;
  bool isObscure;
  final Color color;
  final FocusNode focusNode;

  SubTextField(
      {Key? key,
        required this.textController,
        required this.hintText,
        required this.icon,
        required this.focusNode,
        this.isObscure = false,
        this.maxLines = false,
        this.color = const Color(0xFFffd379)})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GetBuilder<PanelController>(builder: (panelController){
      return Container(
        width: Dimension.width30*7,

        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(Dimension.radius15),
            color: Colors.white,
            boxShadow: [
              BoxShadow(
                  blurRadius: 3,
                  spreadRadius: 1,
                  offset: Offset(1, 1),
                  color: Colors.grey.withOpacity(0.2))
            ]

        ),
        child: TextField(
          focusNode: focusNode,
          maxLines: maxLines ? 4 : 1,
          obscureText: isObscure,
          controller: textController,
          onChanged: (value){
            if(value.isNum){


              for(int i = 0; i<panelController.productController.productList.length ; i++){
                if(panelController.productController.productList[i].code == value.toString() ){
                  panelController.addProductFromPopUp(panelController.productController.productList[i], true);
                  textController.text = '';
                }
              }



            }
          },

          decoration: InputDecoration(
            prefixIcon: Icon(icon, color: color),
            hintText: hintText,
            focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(Dimension.radius15),
                borderSide: BorderSide(
                  width: 1.0,
                  color: Colors.white,
                )),

            //Enabled Border
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(Dimension.radius15),
              borderSide: BorderSide(
                width: 1.0,
                color: Colors.white,
              ),
            ),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(Dimension.radius15),
            ),
          ),
        ),
      );
    });
  }
}
