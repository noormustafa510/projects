import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pos_mobile_f/controller/shop_detail_controller.dart';
import 'package:pos_mobile_f/utils/constants.dart';
import 'package:pos_mobile_f/utils/dimensions.dart';

import 'big_text.dart';

class SoundDropDown extends StatefulWidget {
  const SoundDropDown({super.key});

  @override
  State<SoundDropDown> createState() => _SoundDropDownState();
}

class _SoundDropDownState extends State<SoundDropDown> {
  @override
  Widget build(BuildContext context) {
    final shopDetailController = Get.find<ShopDetailController>();
    return SizedBox(
      width: Dimension.width30*5,
      child: DropdownButton(
          isExpanded: true,
          value: shopDetailController.soundLevel,

          items: List.generate(
              soundLevelList.length,
                  (index) => DropdownMenuItem(
                  value: soundLevelList[index],
                  child: BigText(
                      text: soundLevelList[index].toString()))),
          onChanged: (value) {
            setState(() {
              shopDetailController.soundLevel = value ?? 0;
            });


            //shopDetailController.update();
            //dayT = historyController.dayTListIndex.toString();

            // historyController.update();
          }),
    );
  }
}
