import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pos_mobile_f/controller/shop_detail_controller.dart';
import 'package:pos_mobile_f/utils/dimensions.dart';
import 'package:pos_mobile_f/widgets/big_text.dart';

import 'panel_text_field.dart';


















class PrinterSetter extends StatefulWidget {
   PrinterSetter({super.key,

     required this.mainIpEditingController, required this.mainPortEditingController, required this.kIpEditingController,
     required this.kPortEditingController, required this.isNetwork , required this.isDecimal});
TextEditingController mainIpEditingController;
TextEditingController mainPortEditingController;
TextEditingController kIpEditingController;
TextEditingController kPortEditingController;
bool isNetwork;
bool isDecimal ;

  @override
  State<PrinterSetter> createState() => _PrinterSetterState();
}

class _PrinterSetterState extends State<PrinterSetter> {
  bool light = false;
  bool fDecimalStatus = false;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    light = widget.isNetwork;
    fDecimalStatus = widget.isDecimal;
    //fDecimalStatus =
  }

  @override
  Widget build(BuildContext context) {

    final MaterialStateProperty<Color?> trackColor =
    MaterialStateProperty.resolveWith<Color?>(
          (Set<MaterialState> states) {
        // Track color when the switch is selected.
        if (states.contains(MaterialState.selected)) {
          return Colors.amber;
        }
        // Otherwise return null to set default track color
        // for remaining states such as when the switch is
        // hovered, focused, or disabled.
        return null;
      },
    );
    final MaterialStateProperty<Color?> overlayColor =
    MaterialStateProperty.resolveWith<Color?>(
          (Set<MaterialState> states) {
        // Material color when switch is selected.
        if (states.contains(MaterialState.selected)) {
          return Colors.amber.withOpacity(0.54);
        }
        // Material color when switch is disabled.
        if (states.contains(MaterialState.disabled)) {
          return Colors.grey.shade400;
        }
        // Otherwise return null to set default material color
        // for remaining states such as when the switch is
        // hovered, or focused.
        return null;
      },
    );

    return GetBuilder<ShopDetailController>(builder: (shopDetailController){
      return Column(
        children: [
          SizedBox(height: Dimension.height10,),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              BigText(text: "WDFV"),
              Switch(
                // This bool value toggles the switch.
                value: fDecimalStatus,
                overlayColor: overlayColor,
                trackColor: trackColor,
                thumbColor: const MaterialStatePropertyAll<Color>(Colors.black),
                onChanged: (bool value) {
                  // This is called when the user toggles the switch.
                  setState(() {
                    shopDetailController.isDecimal = value;

                    fDecimalStatus = value;
                  });
                },
              ),
              SizedBox(width: Dimension.width15,),
              BigText(text: "N. Print    "),
              Switch(
                // This bool value toggles the switch.
                value: light,
                overlayColor: overlayColor,
                trackColor: trackColor,
                thumbColor: const MaterialStatePropertyAll<Color>(Colors.black),
                onChanged: (bool value) {
                  // This is called when the user toggles the switch.
                  setState(() {
                    shopDetailController.isNetwork = value;

                    light = value;
                  });
                },
              ),
            ],
          ),

         SizedBox(
         height: Dimension.height45*6.2,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [

              PanelTextField(
                textController: widget.mainIpEditingController,
                hintText: "Enter Main Ip Address",
                icon: Icons.abc,
                onSubmit: (value) {},
                isNumber: true,
              ),
              PanelTextField(
                textController: widget.mainPortEditingController,
                hintText: "Enter Main Port Number",
                icon: Icons.numbers,
                onSubmit: (value) {},
                isNumber: true,
              ),
              PanelTextField(
                textController: widget.kIpEditingController,
                hintText: "Enter K Ip Address",
                icon: Icons.abc,
                onSubmit: (value) {},
                isNumber: true,
              ),
              PanelTextField(
                textController: widget.kPortEditingController,
                hintText: "Enter K Port",
                icon: Icons.numbers,
                onSubmit: (value) {},
                isNumber: true,
              ),
            ],),
        )
        ],
      );
    });
  }
}
