import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pos_mobile_f/controller/product_controller.dart';


import '../utils/dimensions.dart';
import 'big_text.dart';

class RawItemTile extends StatelessWidget {

  String name;
  int index;

  RawItemTile({super.key , required this.name, required this.index});

  @override
  Widget build(BuildContext context) {
    return  GetBuilder<ProductController>(builder: (productController){
      return Padding(
        padding:  EdgeInsets.only(top: Dimension.height10/1.3,bottom: Dimension.height10/1.3, left: Dimension.width30*1.3,right: index==0?Dimension.width30*1.3:0  ),
        child: Container(
          width: Dimension.width30*23,



          decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(Dimension.radius15),



              color: Colors.white,
              boxShadow: [
                BoxShadow(
                    blurRadius: 3,
                    spreadRadius: 1,
                    offset: Offset(1, 1),
                    color: Colors.grey.withOpacity(0.2))
              ]),



          child:   Padding(

            padding:  EdgeInsets.symmetric(horizontal: Dimension.width10, vertical: Dimension.height10/4),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(child: BigText(text: name,size: Dimension.font26, color: Colors.black,)),
             IconButton(onPressed: (){

                  //dataEntryController.deleteItemsFromCategoryList(index);

                 productController.rawItems.removeAt(index);
                 productController.update();

                }, icon: Icon(Icons.delete,color: Colors.red,size: Dimension.iconSize24*1.2,))

              ],
            ),
          ),



        ),
      );
    });
  }
}
