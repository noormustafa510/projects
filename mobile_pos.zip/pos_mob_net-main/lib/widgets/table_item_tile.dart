import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pos_mobile_f/controller/product_controller.dart';


import '../utils/dimensions.dart';
import 'big_text.dart';

class TableItemTile extends StatelessWidget {

  String name;
  int index;

  TableItemTile({super.key , required this.name, required this.index});

  @override
  Widget build(BuildContext context) {
    return  GetBuilder<ProductController>(builder: (productController){
      return Padding(
        padding:  EdgeInsets.symmetric(horizontal: Dimension.width30*2, vertical: Dimension.height10/1.3),
        child: Container(



          decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(Dimension.radius15),



              color: Colors.white,
              boxShadow: [
                BoxShadow(
                    blurRadius: 3,
                    spreadRadius: 1,
                    offset: Offset(1, 1),
                    color: Colors.grey.withOpacity(0.2))
              ]),



          child:   Padding(

            padding:  EdgeInsets.symmetric(horizontal: Dimension.width10, vertical: Dimension.height10/4),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(child: BigText(text: name,size: Dimension.font26, color: Colors.black,)),
                index>1? IconButton(onPressed: () async {

                  //dataEntryController.deleteItemsFromCategoryList(index);

                await  productController.deleteTable(index);

                }, icon: Icon(Icons.delete,color: Colors.red,size: Dimension.iconSize24*1.2,)):
                IconButton(onPressed: (){

                  Get.snackbar("Restriction", 'This item can not be deleted',
                      backgroundColor: Colors.redAccent , maxWidth: Dimension.width30*22,colorText: Colors.white);




                }, icon: Icon(Icons.circle,color: Colors.green,size: Dimension.iconSize24*1.2,))

              ],
            ),
          ),



        ),
      );
    });
  }
}
