import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pos_mobile_f/controller/panel_controller.dart';

import '../utils/dimensions.dart';
import 'big_text.dart';

class NonActiveAccountWidget extends StatelessWidget {
  const NonActiveAccountWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.spaceAround,
      children: [
        Center(child: BigText(text: "Your Account is not active", color: Colors.red, size: Dimension.font26,)),
        Column(
          children: [
            BigText(text: "Contact on WhatsApp for Activation", color: Colors.lightBlueAccent,),
            SizedBox(height: Dimension.height20,),
            ElevatedButton(onPressed: () async {
              await Get.find<PanelController>().goToWhatsApp("I want to active my account");
            }, style: ButtonStyle(
                backgroundColor: MaterialStateProperty.all(Colors.green)
            ),
                child:BigText(text: "     +92-305-4509104     ", color: Colors.white,) ),
          ],
        )
      ],
    );
  }
}
