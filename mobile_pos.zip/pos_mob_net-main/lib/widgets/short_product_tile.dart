import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pos_mobile_f/controller/limit_controller.dart';
import 'package:pos_mobile_f/controller/product_controller.dart';
import 'package:pos_mobile_f/modal/product_modal.dart';
import 'package:pos_mobile_f/utils/colors.dart';

import '../utils/dimensions.dart';
import 'big_text.dart';

class ShortProductTile extends StatelessWidget {
  ProductModal product;

  ShortProductTile({super.key, required this.product});

  TextEditingController limitEditingController = TextEditingController();
  TextEditingController numberEditingController = TextEditingController();

  @override
  Widget build(BuildContext context) {

    limitEditingController.text = product.warLimit.toString();
    numberEditingController.text = product.count.toString();
    String value = Get.find<LimitController>()
        .shortProductNameEditingController
        .text
        .toLowerCase();
    int start = product.name.toLowerCase().indexOf(value);
    int end = start + value.length;

    return GetBuilder<ProductController>(builder: (productController) {
      return GestureDetector(
        onTap: () {

        },

        child: SizedBox(
          height: Dimension.height45 * 2.5,
          child: Padding(
            padding: EdgeInsets.symmetric(
                horizontal: Dimension.width30,
                vertical: Dimension.height10 / 1.5),
            child: Container(
              decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(Dimension.radius15),
                  boxShadow: [
                    BoxShadow(
                        blurRadius: 3,
                        spreadRadius: 1,
                        offset: const Offset(1, 1),
                        color: Colors.grey.withOpacity(0.5))
                  ]),
              height: Dimension.height45,
              child: Padding(
                padding: EdgeInsets.only(
                  left: Dimension.width10,
                  right: Dimension.width10,
                  top: Dimension.width10,
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        SizedBox(
                          width: Dimension.width10,
                        ),
                        Expanded(
                          child: start > -1
                              ? RichText(
                              overflow: TextOverflow.ellipsis,
                              text: TextSpan(
                                  text: product.name
                                      .substring(0, start)
                                      .toString(),
                                  style: TextStyle(
                                      color: Colors.grey,
                                      fontSize: Dimension.font20 * 1.2,
                                      fontWeight: FontWeight.w400),
                                  children: [
                                    TextSpan(
                                        text: product.name
                                            .substring(start, end),
                                        style: TextStyle(
                                            color: Colors.orangeAccent,
                                            fontSize:
                                            Dimension.font20 * 1.4,
                                            fontWeight: FontWeight.w400)),
                                    TextSpan(
                                      text: product.name.substring(end),
                                      style: TextStyle(
                                          color: Colors.grey,
                                          fontSize: Dimension.font20 * 1.2,
                                          fontWeight: FontWeight.w400),
                                    )
                                  ]))
                              : BigText(
                            text: product.name.toString(),
                            size: Dimension.font20 * 1.2,
                          ),
                        ),
                      ],
                    ),
                    SizedBox(
                      height: Dimension.height10 / 2,
                    ),
                    Row(
                      children: [

                        Expanded(
                          child: Row(
                            children: [

                              Expanded(
                                  child: Row(
                                    children: [
                                      Icon(
                                        Icons.numbers,
                                        color: AppColors.mainColor,
                                        size: Dimension.iconSize24*1.5 ,
                                      ),

                                      SizedBox(width: Dimension.width10,),
                                      Expanded(
                                        child: TextField(
                                          controller: numberEditingController,
                                          textAlignVertical:
                                          TextAlignVertical.top,
                                          keyboardType:
                                          const TextInputType.numberWithOptions(
                                              decimal: true),
                                          style: TextStyle(
                                              textBaseline:
                                              TextBaseline.ideographic,
                                              color: AppColors.mainColor,
                                              fontSize:
                                              Dimension.font26*1.1 ),
                                          decoration: const InputDecoration(
                                              isCollapsed: true,
                                              border: InputBorder.none),
                                        ),
                                      ),

                                    ],
                                  )),

                            ],
                          ),
                        ),
                        Expanded(
                          child: Row(
                            children: [

                              Expanded(
                                  child: Row(
                                    children: [
                                      Icon(
                                        Icons.warning,
                                        color: Colors.red,
                                        size: Dimension.iconSize24*1.5 ,
                                      ),

                                      SizedBox(width: Dimension.width10,),
                                      Expanded(
                                        child: TextField(
                                          controller: limitEditingController,
                                          textAlignVertical:
                                          TextAlignVertical.top,
                                          keyboardType:
                                          const TextInputType.numberWithOptions(
                                              decimal: true),
                                          style: TextStyle(
                                              textBaseline:
                                              TextBaseline.ideographic,
                                              color: AppColors.mainColor,
                                              fontSize:
                                              Dimension.font26*1.1 ),
                                          decoration: const InputDecoration(
                                              isCollapsed: true,
                                              border: InputBorder.none),
                                        ),
                                      ),

                                    ],
                                  )),

                            ],
                          ),
                        ),
                        GestureDetector(
                          onTap: () async {
                            if (
                                limitEditingController.text.isNum  && numberEditingController.text.isNum ) {

                              product.warLimit =
                                  double.parse(limitEditingController.text);
                              product.count = double.parse(numberEditingController.text);

                              await  productController.priceAndCostUpdater(
                                  product.key!, product);
                              Get.snackbar(product.name,
                                  'Count: ${product.count} & Limit:  ${product.warLimit} has been set!',
                                  backgroundColor: Colors.green,
                                  maxWidth: Dimension.width30 * 22,
                                  colorText: Colors.white);
                            } else {
                              Get.snackbar(
                                  "Error", 'Count or Limit is not number!',
                                  backgroundColor: Colors.redAccent,
                                  maxWidth: Dimension.width30 * 22,
                                  colorText: Colors.white);
                            }
                          },
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(
                                CupertinoIcons.up_arrow,
                                size: Dimension.iconSize24 * 2 * 1.1,
                                color: Colors.green,
                              ),
                            ],
                          ),
                        )
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      );
    });
  }
}
