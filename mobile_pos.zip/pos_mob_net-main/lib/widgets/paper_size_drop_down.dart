import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pos_mobile_f/controller/shop_detail_controller.dart';
import 'package:pos_mobile_f/utils/constants.dart';
import 'package:pos_mobile_f/utils/dimensions.dart';

import 'big_text.dart';

class PaperSizeDropDown extends StatefulWidget {
  const PaperSizeDropDown({super.key});

  @override
  State<PaperSizeDropDown> createState() => _PaperSizeDropDownState();
}

class _PaperSizeDropDownState extends State<PaperSizeDropDown> {
  @override
  Widget build(BuildContext context) {
    final shopDetailController = Get.find<ShopDetailController>();
    return SizedBox(
      width: Dimension.width30*7,
      child: DropdownButton(
          isExpanded: true,
          value: shopDetailController.paperSize,

          items: List.generate(
              paperSizeList.length,
                  (index) => DropdownMenuItem(
                  value: paperSizeList[index],
                  child: BigText(
                      text: paperSizeList[index]))),
          onChanged: (value) {
            setState(() {
              shopDetailController.paperSize = value ?? '58mm';
            });


            //shopDetailController.update();
            //dayT = historyController.dayTListIndex.toString();

            // historyController.update();
          }),
    );
  }
}
