import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pos_mobile_f/controller/panel_controller.dart';

import '../utils/dimensions.dart';
import 'big_text.dart';

class NonLogInUserWidget extends StatelessWidget {
  const NonLogInUserWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.spaceAround,
      children: [
        Center(child: BigText(text: "You are not Authorized", color: Colors.red, size: Dimension.font26,)),

      ],
    );
  }
}
