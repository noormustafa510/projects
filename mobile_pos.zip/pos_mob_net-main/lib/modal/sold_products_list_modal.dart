class SoldProductListModal{
  String name;
  double counter;

  SoldProductListModal({required this.name, required this.counter});
}