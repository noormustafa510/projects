import 'package:cloud_firestore/cloud_firestore.dart';

class FireKeyModal{
  List<String> fireKeyList ;

  FireKeyModal({required  this.fireKeyList});

  Map<String, dynamic> toJson() {
    return {
      'fireKeyList': this.fireKeyList,
    };
  }

  factory FireKeyModal.fromJson(Map<String, dynamic> map) {
    return FireKeyModal(
        fireKeyList : map['fireKeyList'].cast<String>(),
    );
  }
}

//
//
// factory FireKeyModal.fromFirestore(
// DocumentSnapshot<Map<String, dynamic>> snapshot,
// SnapshotOptions? options,
// ) {
// final data = snapshot.data();
// return FireKeyModal(
// fireKeyList :
// data?['fireKeyList'] is Iterable ? List.from(data?['fireKeyList']) : null,
// );
// }
//
// Map<String, dynamic> toFireStore() {
// return {
// 'fireKeyList': this.fireKeyList,
// };
// }