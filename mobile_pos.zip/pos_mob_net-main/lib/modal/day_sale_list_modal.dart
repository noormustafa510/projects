class DaySaleListModal{
  String day;
  double sale;

  DaySaleListModal({required this.sale , required this.day});
}