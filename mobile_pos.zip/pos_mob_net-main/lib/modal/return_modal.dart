class ReturnModal{
  String invoiceNumberAndTime;
  String date;
  String itemName;
  double quantity;
  double remainingQuantity;
  String remarks;
  double discount;
  double price;
  double cost;

  ReturnModal({required this.invoiceNumberAndTime, required this.date, required this.itemName
  , required this.quantity , required this.remainingQuantity, required this.remarks, required this.discount,
    required this.price, required this.cost

  });


  factory ReturnModal.fromJson(Map<String, dynamic> map) {
    return ReturnModal(
      invoiceNumberAndTime: map['invoiceNumberAndTime'] as String,
      date: map['date'] as String,
      itemName: map['itemName'] as String,
      quantity: map['quantity'] as double,
      remainingQuantity: map['remainingQuantity'] as double,
      remarks: map['remarks'] as String,
      discount: map['discount'] as double,
      price: map['price'] as double,
      cost: map['cost'] as double,
    );
  }


  Map<String, dynamic> toJson() {
    return {
      'invoiceNumberAndTime': this.invoiceNumberAndTime,
      'date': this.date,
      'itemName': this.itemName,
      'quantity': this.quantity,
      'remainingQuantity': this.remainingQuantity,
      'remarks': this.remarks,
      'discount': this.discount,
      'price': this.price,
      'cost': this.cost,
    };
  }


}