class UsbDeviceListModal{
  int vendorId;
  int productId;

  String productName;

  UsbDeviceListModal({required this.productId, required this.vendorId, required this.productName});

}