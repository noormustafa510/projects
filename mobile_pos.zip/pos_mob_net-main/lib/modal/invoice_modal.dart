class MainInvoice {
  MainInvoice({
    required this.restInvoice,
    required this.subProductsList,
    required this.remarks,
    required this.invoiceNumber,
    required this.date,
    required this.tb,
    required this.cashier
  });
  late final RestInvoiceModal restInvoice;
  late final List<SubProductsModal> subProductsList;
  late final String remarks;
  late final String cashier;
  late final String tb;
  late final String invoiceNumber;
  late final String date;

  MainInvoice.fromJson(Map<String, dynamic> json){
    restInvoice = RestInvoiceModal.fromJson(json['restInvoice']);
    subProductsList = List.from(json['subProductsList']).map((e)=>SubProductsModal.fromJson(e)).toList();
    remarks = json['remarks'];
    cashier = json['cashier'];
    tb = json['tb'];
    date = json['date'];
    invoiceNumber = json['invoiceNumber'];
  }

  Map<String, dynamic> toJson() {
    final _data = <String, dynamic>{};
    _data['restInvoice'] = restInvoice.toJson();
    _data['subProductsList'] = subProductsList.map((e)=>e.toJson()).toList();
    _data['remarks'] = remarks;
    _data['cashier'] = cashier;
    _data['tb'] = tb;
    _data['date'] = date;
    _data['invoiceNumber'] = invoiceNumber;
    return _data;
  }
}









class RestInvoiceModal{

  double pSale;
  double wDiscount;
  double wTax;
  double totalSale;
  double balance;

  RestInvoiceModal({ required this.pSale, required this.wDiscount, required this.wTax, required this.totalSale, required this.balance});

  factory RestInvoiceModal.fromJson(Map<String, dynamic> map) {
    return RestInvoiceModal(

      pSale: map['pSale'] as double,
      wDiscount: map['wDiscout'] as double,
      wTax: map['wTax'] as double,
      totalSale: map['totalSale'] as double,
      balance: map['balance'] as double,
    );
  }

  Map<String, dynamic> toJson() {
    return {

      'pSale': this.pSale,
      'wDiscout': this.wDiscount,
      'wTax': this.wTax,
      'totalSale': this.totalSale,
      'balance': this.balance,
    };
  }
}

class SubProductsModal{

  int? key;
  String name;
  String code;
  double price;
  double cost;
  double discount;
  double total;
  double quantity;

  SubProductsModal({required this.key, required this.name, required this.code, required this.price, required this.cost
  , required this.discount, required this.quantity, required this.total
  });

  Map<String, dynamic> toJson() {
    return {
      'key': this.key,
      'name': this.name,
      'code': this.code,
      'price': this.price,
      'cost': this.cost,
      'discount': this.discount,
      'total': this.total,
      'quantity': this.quantity,
    };
  }

  factory SubProductsModal.fromJson(Map<String, dynamic> map) {
    return SubProductsModal(
      key: map['key'] as int,
      name: map['name'] as String,
      code: map['code'] as String,
      price: map['price'] as double,
      cost: map['cost'] as double,
      discount: map['discount'] as double,
      total: map['total'] as double,
      quantity: map['quantity'] as double,
    );
  }
}