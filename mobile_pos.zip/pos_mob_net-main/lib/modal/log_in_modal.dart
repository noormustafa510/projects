class LogInModal{
  int? key;
  String username;
  String password;
  bool isAdmin;

  LogInModal({this.key, required this.username, required this.password, required this.isAdmin});

  Map<String, dynamic> toJson() {
    return {
      'username': this.username,
      'password': this.password,
      'isAdmin': this.isAdmin,
    };
  }

  factory LogInModal.fromJson(Map<String, dynamic> map) {
    return LogInModal(
      username: map['username'] as String,
      password: map['password'] as String,
      isAdmin: map['isAdmin'] as bool,
    );
  }
}