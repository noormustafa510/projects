class ShopDetailModel {
  String shopMoto;
  String shopAddress;
  String shopPhone;
  String currency;
  int copies;
  int kCopies;
  double shopDiscount;
  double shopTax;
  int delay;
  int spaces;
  int soundLevel;
bool isNetwork;
bool isFinalDecimal;
String mainIp;
String mainPort;
String kIp;
String kPort;
String paperSize;

  ShopDetailModel(
      {required this.shopMoto,
      required this.shopAddress,
      required this.shopPhone,
      required this.shopDiscount,
      required this.currency,
      required this.shopTax
      ,required this.copies,
        required this.kCopies,
        required this.delay,
        required this.spaces,
        required this.soundLevel,
        required this.isNetwork,
        required this.isFinalDecimal,
        required this.mainIp,
        required this.mainPort,
        required this.kIp,
        required this.kPort,
        required this.paperSize
      });

  Map<String, dynamic> toJson() {
    return {
      'shopMoto': this.shopMoto,
      'shopAddress': this.shopAddress,
      'shopPhone': this.shopPhone,
      'currency': this.currency,
      'copies': this.copies,
      'kCopies': this.kCopies,
      'shopDiscount': this.shopDiscount,
      'shopTax': this.shopTax,
      'delay': this.delay,
      'spaces': this.spaces,
      'soundLevel': this.soundLevel,
      'isNetwork': this.isNetwork,
      'isFinalDecimal': this.isFinalDecimal,
      'mainIp': this.mainIp,
      'mainPort': this.mainPort,
      'kIp': this.kIp,
      'kPort': this.kPort,
      'paperSize': this.paperSize,
    };
  }

  factory ShopDetailModel.fromJson(Map<String, dynamic> map) {
    return ShopDetailModel(
      shopMoto: map['shopMoto'] as String,
      shopAddress: map['shopAddress'] as String,
      shopPhone: map['shopPhone'] as String,
      currency: map['currency'] as String,
      copies: map['copies'] as int,
      kCopies: map['kCopies'] as int,
      shopDiscount: map['shopDiscount'] as double,
      shopTax: map['shopTax'] as double,
      delay: map['delay'] as int,
      spaces: map['spaces'] as int,
      soundLevel: map['soundLevel'] as int,
      isNetwork: map['isNetwork'] as bool,
      isFinalDecimal: map['isFinalDecimal'] ?? false as bool ,

      mainIp: map['mainIp'] as String,
      mainPort: map['mainPort'] as String,
      kIp: map['kIp'] as String,
      kPort: map['kPort'] as String,
      paperSize: map['paperSize'] as String,
    );
  }
}
