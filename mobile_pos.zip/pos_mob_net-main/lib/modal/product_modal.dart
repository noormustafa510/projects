class ProductModal{
  int? key;
  String name;
  String code;
  double price;
  double cost;
  double discount;
  double count;
  double warLimit;
  String category;
  String expiryRange;
  List<String> rawItems ;

  ProductModal({
     this.key,
    required this.name,
    required this.code,
    required this.price,
    required this.cost,
    required this.count,
    required this.discount,
    required this.warLimit,
    required this.category,
    required this.expiryRange,
    required this.rawItems,
  });

  Map<String, dynamic> toJson() {
    return {
      'name': this.name,
      'code': this.code,
      'price': this.price,
      'cost': this.cost,
      'discount': this.discount,
      'count': this.count,
      'warLimit': this.warLimit,
      'category': this.category,
      'expiryRange': this.expiryRange,
      'rawItems': this.rawItems,
    };
  }

  factory ProductModal.fromJson(Map<String, dynamic> map) {
    return ProductModal(

      name: map['name'] as String,
      code: map['code'] as String,
      price: map['price'] as double,
      cost: map['cost'] as double,
      discount: map['discount'] as double,
      count: map['count'] as double,
      warLimit: map['warLimit'] as double,
      category: map['category'] as String,
      expiryRange: map['expiryRange'] as String,
        rawItems: List.castFrom<dynamic, String>(map['rawItems'])
    );
  }
}