class CategoryModal {
  int key;
  String categoryName;

  CategoryModal({required this.key, required this.categoryName});



  factory CategoryModal.fromMap(Map<String, dynamic> map) {
    return CategoryModal(
      key: map['key'] as int,
      categoryName: map['categoryName'] as String,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'key': key,
      'categoryName': categoryName,
    };
  }
}
