class DiscountModel {
  String invoiceNumberAndTime;
  String date;
  String itemName;
  double quantity;
  double remainingQuantity;

  double discount;
  double price;
  double cost;

  DiscountModel({
    required this.invoiceNumberAndTime,
    required this.date,
    required this.itemName,
    required this.quantity,
    required this.remainingQuantity,
    required this.discount,
    required this.price,
    required this.cost,
  });

  Map<String, dynamic> toJson() {
    return {
      'invoiceNumberAndTime': this.invoiceNumberAndTime,
      'date': this.date,
      'itemName': this.itemName,
      'quantity': this.quantity,
      'remainingQuantity': this.remainingQuantity,
      'discount': this.discount,
      'price': this.price,
      'cost': this.cost,
    };
  }

  factory DiscountModel.fromJson(Map<String, dynamic> map) {
    return DiscountModel(
      invoiceNumberAndTime: map['invoiceNumberAndTime'] as String,
      date: map['date'] as String,
      itemName: map['itemName'] as String,
      quantity: map['quantity'] as double,
      remainingQuantity: map['remainingQuantity'] as double,
      discount: map['discount'] as double,
      price: map['price'] as double,
      cost: map['cost'] as double,
    );
  }
}