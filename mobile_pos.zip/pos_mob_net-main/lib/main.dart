import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:get/get_navigation/src/root/get_material_app.dart';
import 'package:hive/hive.dart';
import 'package:pos_mobile_f/firebase_options.dart';
import 'package:pos_mobile_f/pages/home/home_page.dart';
import 'package:pos_mobile_f/pages/home/splash_screen.dart';
import 'package:pos_mobile_f/utils/dimensions.dart';

import 'utils/colors.dart';

late Box<String> categoryBoxPointer;
late Box<String>  productBoxPointer;
late Box<String>  tableBoxPointer;
late Box<String> resNameBoxPointer;
late LazyBox<String> saleSaveBoxPointer;

late Box<double> saleTotalListPointer ;

late Box<String> resIdBoxPointer;

late Box<String> setDateTimeBoxPointer;

late Box<int> invoiceNumberPointer;
late Box<int> triedLimitPointer;
late Box<String> shopDetailPointer;
late Box<int> usedMonthPointer;
late Box<int> usedYearPointer;
late Box<String> backUpKeyPointer;
late Box<String> fireListCheckPointer;
late Box<String> storeBackUpSingleKeyPointer;
late Box<String> pushBackUpDatePointer;
late Box<String> pullBackUpDatePointer;
late Box<String> returnDataPointer;
late Box<String> discountDataPointer;
late Box<String> usersListPointer;
late Box<int> wrongAttemptPointer;
late Box<String> lastBarCodeGenPointer;



Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'A NPOS',


       home: SplashScreen(),

      theme: ThemeData(

        primaryColor: AppColors.mainColor,
        secondaryHeaderColor: AppColors.yellowColor,
        primaryColorLight: AppColors.mainColor,
        primaryColorDark: AppColors.mainColor,
        colorScheme: ColorScheme.highContrastLight(
          primary: AppColors.mainColor
        ),

        datePickerTheme: DatePickerThemeData(

          surfaceTintColor: AppColors.mainColor,
          headerBackgroundColor: AppColors.mainColor,
          dayBackgroundColor: MaterialStateProperty.all(AppColors.mainColor),
          dayOverlayColor: MaterialStateProperty.all(AppColors.mainColor),
          todayBackgroundColor: MaterialStateProperty.all(AppColors.mainColor),
          yearBackgroundColor: MaterialStateProperty.all(AppColors.mainColor),
          //rangePickerBackgroundColor: AppColors.mainColor
          rangePickerHeaderBackgroundColor: AppColors.mainColor,
         // rangeSelectionBackgroundColor: AppColors.mainColor
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(style: ButtonStyle(
          backgroundColor: MaterialStateProperty.all(AppColors.mainColor),

        )),
      ),





    );
  }
}


